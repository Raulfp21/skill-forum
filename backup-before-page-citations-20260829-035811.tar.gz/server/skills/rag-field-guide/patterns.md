# Patterns & Rules of Thumb

- [Retrieval-Augmented Generation: A Field Guide] ground language model answers in a knowledge base, cite their sources, and avoid
- [Chapter 1. Why Grounded Answers Matter] Large language models produce fluent text but they do not remember facts reliably.
- [Chapter 1. Why Grounded Answers Matter] Retrieval-augmented generation is a technique that couples a retriever with a
- [Chapter 2. Indexing Documents] Overlap is used to avoid cutting sentences in half. When chunks overlap by 10 to
- [Chapter 4. Generation with Citations] do not contain the answer, the model must say so instead of guessing.
- [Chapter 5. Evaluation] set should include questions the model will face in production, including
- [Chapter 7. Practical Recipes] and a stable identifier so citations survive re-indexing. Always render the
- [Chapter 7. Practical Recipes] reference list from the retrieved metadata, never from model-generated text.

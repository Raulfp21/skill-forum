# Glossary

- **This failure mode** — called
- **Retrieval-augmented generation** — a technique that couples a retriever with a
- **RAG system** — that the knowledge base can be updated
- **Indexing** — the offline phase that prepares a corpus for retrieval
- **Chunk size** — a key design decision
- **Overlap** — used to avoid cutting sentences in half
- **Embeddings** — dense vector representations of text
- **BM25** — the most common sparse algorithm: it weights a term by how rare it is in
- **Retrieval quality** — measured by recall at K
- **Citation** — the mechanism that turns retrieval into trust
- **Answer faithfulness** — the fraction of answer sentences that are entailed by the
- **Common causes** — chunking that splits the answer, queries that use jargon not in
- **Stale knowledge** — a silent failure: the corpus is correct at index time but wrong
- **This recipe** — cheap and covers most document collections

# Rag Field Guide

# Retrieval-Augmented Generation: A Field Guide

This guide explains how to build retrieval-augmented generation (RAG) systems that
ground language model answers in a knowledge base, cite their sources, and avoid
hallucination. Why Grounded Answers Matter

Large language models produce fluent text but they do not remember facts reliably.

## Overview

- **Slug:** `rag-field-guide`
- **Words:** 1125
- **Chapters:** 8
- **Chunks:** 8

## Chapter index (loaded on demand)

- Retrieval-Augmented Generation: A Field Guide ``chapters/ch01-retrieval-augmented-generation-a-field-guide.md``
- Chapter 1. Why Grounded Answers Matter ``chapters/ch02-chapter-1-why-grounded-answers-matter.md``
- Chapter 2. Indexing Documents ``chapters/ch03-chapter-2-indexing-documents.md``
- Chapter 3. Retrieval ``chapters/ch04-chapter-3-retrieval.md``
- Chapter 4. Generation with Citations ``chapters/ch05-chapter-4-generation-with-citations.md``
- Chapter 5. Evaluation ``chapters/ch06-chapter-5-evaluation.md``
- Chapter 6. Failure Modes ``chapters/ch07-chapter-6-failure-modes.md``
- Chapter 7. Practical Recipes ``chapters/ch08-chapter-7-practical-recipes.md``

## How to use

Ask questions about Rag Field Guide. The agent retrieves the most relevant chapter
and answers from the real content with references — no hallucination.

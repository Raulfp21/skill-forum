# Cheatsheet — key facts

- [Chapter 2. Indexing Documents] Small chunks around 200 to 400 tokens improve
precision because each chunk addresses a narrow topic.
- [Chapter 2. Indexing Documents] Large chunks around 800 to
1200 tokens preserve more context and reduce the number of lookups.
- [Chapter 2. Indexing Documents] When chunks overlap by 10 to
20 percent, a sentence that spans a boundary still appears intact in at least one
chunk.
- [Chapter 5. Evaluation] A faithfulness score below 0.8 usually indicates the model is
ignoring context or the retriever is missing passages.
- [Chapter 7. Practical Recipes] For a first deployment, use hybrid retrieval with BM25 and a small embedding model,
chunk at 400 tokens with 10 percent overlap, and add a cross-encoder reranker for
the top 50 candidates.

# Chapter 5. Evaluation

## Chapter 5. Evaluation

Evaluate a RAG system on three dimensions: retrieval, generation, and grounding.
Retrieval evaluation measures whether the right passages are found. Generation
evaluation measures whether the answer is correct and fluent. Grounding evaluation
measures whether every claim in the answer is supported by a retrieved passage.

Answer faithfulness is the fraction of answer sentences that are entailed by the
source passages. A faithfulness score below 0.8 usually indicates the model is
ignoring context or the retriever is missing passages. Citation precision measures
whether the cited passage actually supports the claim next to it.

Use a golden set of question-answer pairs with labeled relevant passages. The test
set should include questions the model will face in production, including
adversarial questions that are plausible but unanswerable from the corpus.


# Chapter 7. Practical Recipes

## Chapter 7. Practical Recipes

For a first deployment, use hybrid retrieval with BM25 and a small embedding model,
chunk at 400 tokens with 10 percent overlap, and add a cross-encoder reranker for
the top 50 candidates. This recipe is cheap and covers most document collections.

Store metadata in every vector record. Include the source title, section, page,
and a stable identifier so citations survive re-indexing. Always render the
reference list from the retrieved metadata, never from model-generated text.

Monitor retrieval hit rate in production by logging the top passage scores for
every query. A sudden drop in hit rate predicts bad answers before users complain.
Set an alert on maximum retrieval score so ungrounded responses are caught early.

Batch embeddings with a GPU when the corpus grows beyond a few million chunks.
Re-embedding the entire corpus on every document change is wasteful; use
incremental indexing for the changed files only.


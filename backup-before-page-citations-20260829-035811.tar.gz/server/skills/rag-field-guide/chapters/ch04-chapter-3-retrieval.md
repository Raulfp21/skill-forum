# Chapter 3. Retrieval

## Chapter 3. Retrieval

At query time the retriever scores every chunk against the user question and
returns the highest scoring passages. Sparse retrieval uses keyword statistics.
BM25 is the most common sparse algorithm: it weights a term by how rare it is in
the corpus and normalizes by document length. BM25 is fast, explainable, and works
well for factual questions.

Dense retrieval embeds the query and finds the nearest vectors using approximate
nearest neighbor search. Dense retrieval captures synonyms and paraphrases that
keyword search misses. Hybrid retrieval combines BM25 and dense scores with a
weighted sum, which usually beats either alone.

Retrieval quality is measured by recall at K. Recall@K counts how many relevant
passages appear in the top K results. A retriever that misses the relevant passage
forces the generator to answer without evidence, so recall is more important than
top-one precision for RAG.


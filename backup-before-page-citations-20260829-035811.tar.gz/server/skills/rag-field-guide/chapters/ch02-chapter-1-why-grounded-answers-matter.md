# Chapter 1. Why Grounded Answers Matter

## Chapter 1. Why Grounded Answers Matter

Large language models produce fluent text but they do not remember facts reliably.
When a model answers from its weights alone it can invent citations, mix up dates,
and confidently state things that are false. This failure mode is called
hallucination.

Retrieval-augmented generation is a technique that couples a retriever with a
generator. The retriever fetches relevant passages from a corpus the operator
controls, and the generator produces an answer using only those passages as
context. Grounding answers in a trusted corpus reduces hallucination and makes
every claim verifiable.

The primary benefit of a RAG system is that the knowledge base can be updated
without retraining the model. When new documents arrive, the operator re-indexes
the corpus and the system immediately answers from the new material.


# Chapter 2. Indexing Documents

## Chapter 2. Indexing Documents

Indexing is the offline phase that prepares a corpus for retrieval. The operator
first extracts plain text from each source document, then splits that text into
chunks. A chunk is a contiguous block of text that is small enough to embed or
score but large enough to carry meaning.

Chunk size is a key design decision. Small chunks around 200 to 400 tokens improve
precision because each chunk addresses a narrow topic. Large chunks around 800 to
1200 tokens preserve more context and reduce the number of lookups. The optimal
size depends on the answer granularity you need.

Overlap is used to avoid cutting sentences in half. When chunks overlap by 10 to
20 percent, a sentence that spans a boundary still appears intact in at least one
chunk. Semantic chunkers split on paragraph or section boundaries instead of fixed
token counts, which produces more coherent chunks.

Embeddings are dense vector representations of text. An embedding model maps each
chunk to a vector such that similar meanings sit close together in vector space.
The operator stores the vectors in a vector database together with metadata such as
the source name, section title, and page number. That metadata later becomes the
citation.


# Chapter 6. Failure Modes

## Chapter 6. Failure Modes

Retrieval failure happens when the right passage exists but is not retrieved.
Common causes are chunking that splits the answer, queries that use jargon not in
the document, and embedding models that do not understand the domain. Fix
retrieval before touching the generator.

Context overflow happens when the retrieved passages exceed the model context
window. Rank passages by score and truncate, or rerank with a cross-encoder that
scores query-passage pairs jointly. Reranking usually improves the final answer
more than adding more passages.

Stale knowledge is a silent failure: the corpus is correct at index time but wrong
after a source document changes. Re-index changed documents and record the index
timestamp so the system can warn when evidence is older than a threshold.

Hallucination persists when the model is asked to answer a question the corpus
cannot answer. A refusal path that detects low maximum retrieval score and replies
"not found in the knowledge base" is more useful than a confident wrong answer.


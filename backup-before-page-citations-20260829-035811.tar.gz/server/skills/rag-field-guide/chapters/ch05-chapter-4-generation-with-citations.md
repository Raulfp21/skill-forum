# Chapter 4. Generation with Citations

## Chapter 4. Generation with Citations

The generator receives the question and the retrieved passages, then writes an
answer. The system prompt instructs the model to answer only from the supplied
passages and to mark each claim with a bracketed reference number. If the passages
do not contain the answer, the model must say so instead of guessing.

Citation is the mechanism that turns retrieval into trust. Each sentence in the
answer maps to one or more source passages. The UI renders the references as
numbered markers that the user can click to see the original passage, its chapter,
and its page.

Multi-hop questions require more than one passage. The system retrieves passages
for the first hop, then uses them to find follow-up passages. Iterative retrieval
improves answers to questions such as "which paper introduced the loss used by
this model?" that span several documents.


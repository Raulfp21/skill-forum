# 62bbe222 9bd6 4202 85ee 99a2513f8f8b

Section 100 to 146, BNS Describe offences against human 
body; (299 10 377 1.P.C) Section 100 of The BNS Act 45 of 2023 (S.

## Overview

- **Slug:** `62bbe222-9bd6-4202-85ee-99a2513f8f8b`
- **Words:** 8521
- **Chapters:** 33
- **Chunks:** 44

## Chapter index (loaded on demand)

- Section 100 to 146, BNS Describe offences against human ``chapters/ch01-section-100-to-146-bns-describe-offences-against-human.md``
- Section 100 of The BNS Act 45 of 2023 (S. 299 1.P.C.) ``chapters/ch02-section-100-of-the-bns-act-45-of-2023-s-299-1-p-c.md``
- Section 103 of BNS act 45 0£2023, (S. 302, 1.P.C.): Punishment ``chapters/ch03-section-103-of-bns-act-45-0-2023-s-302-1-p-c-punishment.md``
- Section 106 of BNS 45 of 2023, (S. 304-A, [.LP.C.) Causing ``chapters/ch04-section-106-of-bns-45-of-2023-s-304-a-lp-c-causing.md``
- Section 107, BNS (S. 305, I.P.C.:) Abetment of suicide of ``chapters/ch05-section-107-bns-s-305-i-p-c-abetment-of-suicide-of.md``
- Section 108, BNS (S. 306, 1.P.C.) Abetment of suicide: ``chapters/ch06-section-108-bns-s-306-1-p-c-abetment-of-suicide.md``
- Section 109 of BNS 45 0f2023, (S. 307, .LP.C.) Attempt to ``chapters/ch07-section-109-of-bns-45-0f2023-s-307-lp-c-attempt-to.md``
- Section 110 of BNS 45 of 2023, (S. 308, I.P.C.) Attempt to ``chapters/ch08-section-110-of-bns-45-of-2023-s-308-i-p-c-attempt-to.md``
- Section 226 of BNS 45 of 2023, S. 309, I.P.C.: Attempt to ``chapters/ch09-section-226-of-bns-45-of-2023-s-309-i-p-c-attempt-to.md``
- Section 114 of BNS 45 of 2023, S. 319, I.P.C.: HURT: ``chapters/ch10-section-114-of-bns-45-of-2023-s-319-i-p-c-hurt.md``
- Section 88 to 123, of BNS 45 of 2023, (S. 312 to 328 of ``chapters/ch11-section-88-to-123-of-bns-45-of-2023-s-312-to-328-of.md``
- Section 116 of BNS act 45 of 2023, (S. 320, LP.C.:) ``chapters/ch12-section-116-of-bns-act-45-of-2023-s-320-lp-c.md``
- CHAPTER 10: Medicolegal Aspects of Wounds ``chapters/ch13-chapter-10-medicolegal-aspects-of-wounds.md``
- SECTION 1: Forensic Medicine ``chapters/ch14-section-1-forensic-medicine.md``
- Section 115, BNS (S. 321, I.P.C.): Voluntarily causing ``chapters/ch15-section-115-bns-s-321-i-p-c-voluntarily-causing.md``
- Section 117, BNS (S. 322, I.P.C.): Voluntarily causing ``chapters/ch16-section-117-bns-s-322-i-p-c-voluntarily-causing.md``
- Section 115 (2) of the BNS Act 45 of 2023, S. 323, .LP.C.: ``chapters/ch17-section-115-2-of-the-bns-act-45-of-2023-s-323-lp-c.md``
- Section 118, BNS (S. 324, I.P.C.): Voluntarily causing hurt ``chapters/ch18-section-118-bns-s-324-i-p-c-voluntarily-causing-hurt.md``
- Section 117 (2) of BNS Act 45 of 2023, S. 325, .P.C.: ``chapters/ch19-section-117-2-of-bns-act-45-of-2023-s-325-p-c.md``
- Section 123, BNS (S. 328, 1.P.C.): Administering ``chapters/ch20-section-123-bns-s-328-1-p-c-administering.md``
- Section 127, BNS (S. 340, I.P.C.): Wrongful confinement ``chapters/ch21-section-127-bns-s-340-i-p-c-wrongful-confinement.md``
- Section 130, BNS (S. 351, L.P.C.): An assault is an offer ``chapters/ch22-section-130-bns-s-351-l-p-c-an-assault-is-an-offer.md``
- Section 131, BNS (8. 352, 1.P.C.): Punishment for various ``chapters/ch23-section-131-bns-8-352-1-p-c-punishment-for-various.md``
- Section 138,(S. 362, I.P.C.): ABDUCTION: Whoever by ``chapters/ch24-section-138-s-362-i-p-c-abduction-whoever-by.md``
- CHAPTER 10: Medicolegal Aspects of Wounds ``chapters/ch25-chapter-10-medicolegal-aspects-of-wounds.md``
- Section 80 of BNS act 45 of 2023, (S.304-B.,.P.C.) Dowry ``chapters/ch26-section-80-of-bns-act-45-of-2023-s-304-b-p-c-dowry.md``
- Section 85, BNS (S. 498 A, 1.P.C.) Whoever being the ``chapters/ch27-section-85-bns-s-498-a-1-p-c-whoever-being-the.md``
- Section 117 & 118 BSA Act 47 0£2023. (S.113A and 113B, ``chapters/ch28-section-117-118-bsa-act-47-0-2023-s-113a-and-113b.md``
- Section 194 BNSS Act 46 of 2023. (S. 174 (3) Cr.P.C.) ``chapters/ch29-section-194-bnss-act-46-of-2023-s-174-3-cr-p-c.md``
- SECTION 1: Forensic Medicine ``chapters/ch30-section-1-forensic-medicine.md``
- SECTION 1: Forensic Medicine ``chapters/ch31-section-1-forensic-medicine.md``
- Section 84, BNS (S. 498A, I.P.C). Faulk has categorized these ``chapters/ch32-section-84-bns-s-498a-i-p-c-faulk-has-categorized-these.md``
- CHAPTER 18: Sexual Offences ``chapters/ch33-chapter-18-sexual-offences.md``

## How to use

Ask questions about 62bbe222 9bd6 4202 85ee 99a2513f8f8b. The agent retrieves the most relevant chapter
and answers from the real content with references — no hallucination.

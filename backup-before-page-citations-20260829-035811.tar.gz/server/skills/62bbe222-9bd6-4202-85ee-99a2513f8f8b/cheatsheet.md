# Cheatsheet — key facts

- [Section 100 to 146, BNS Describe offences against human] Section 100 to 146, BNS Describe offences against human 
body; (299 10 377 1.P.C)
- [Section 100 of The BNS Act 45 of 2023 (S. 299 1.P.C.)] Section 100 of The BNS Act 45 of 2023 (S.
- [Section 100 of The BNS Act 45 of 2023 (S. 299 1.P.C.)] 299 1.P.C.) 
Define Homicide.
- [Section 100 of The BNS Act 45 of 2023 (S. 299 1.P.C.)] (2) 
Culpable 
homicide 
not 
amounting 
to 
Murder—Punishment 
for 
causing 
death 
of 
person 
other 
than 
intended 
Sectlon 
102 
of 
The 
BNS 
Act 
45 
0f 
2023 
(S, 
301, 
LP.C.).
- [Section 100 of The BNS Act 45 of 2023 (S. 299 1.P.C.)] (3) 
Punishment 
for 
Murder 
S.
- [Section 100 of The BNS Act 45 of 2023 (S. 299 1.P.C.)] 103 
of 
The 
BNS 
Act 
45 
of 
2023 
(S, 
308, 
1L.1.C.).
- [Section 100 of The BNS Act 45 of 2023 (S. 299 1.P.C.)] (4) 
Punishment 
for 
Murder 
by 
life 
convict 
Section 
104 
of 
BNS 
Act 
45 
of 
2023 
(S.
- [Section 100 of The BNS Act 45 of 2023 (S. 299 1.P.C.)] (5) 
Punishment 
for 
culpable 
MedicolegaliAspectsiofiWounds 
homicide not amounting to murder.
- [Section 100 of The BNS Act 45 of 2023 (S. 299 1.P.C.)] Section 105 of BNS Act 
45 of 2023 (8.
- [Section 100 of The BNS Act 45 of 2023 (S. 299 1.P.C.)] (6) Punishment causing death by 
Negligence Section 106 of BNS Act 45 0f 2023 (S.
- [Section 100 of The BNS Act 45 of 2023 (S. 299 1.P.C.)] (7) Dowry Death; Section 80 of BNS Act 45 of 2023 (S.
- [Section 100 of The BNS Act 45 of 2023 (S. 299 1.P.C.)] (8) Abatement of Suicide Section 108 of The BNS 
Act 45 of 2023 (S.
- [Section 100 of The BNS Act 45 of 2023 (S. 299 1.P.C.)] Attempt to commit culpable 
Homicide Section 109 of BNS Act 45 0f 2023 (S.
- [Section 100 of The BNS Act 45 of 2023 (S. 299 1.P.C.)] (9) 
Attempt to murder Section 109 of BNS Act 45 of 2023 (S.
- [Section 100 of The BNS Act 45 of 2023 (S. 299 1.P.C.)] (10) Attempt to commit Suicide to compel or restraint 
exercise 10) Attemptpower Section 226 of The BNS Act 45 of 
2023 (S.
- [Section 100 of The BNS Act 45 of 2023 (S. 299 1.P.C.)] (11) Rash or negligent homicide Section 
281.
- [Section 100 of The BNS Act 45 of 2023 (S. 299 1.P.C.)] of BNS Act 45 of 2023 (S.
- [Section 100 of The BNS Act 45 of 2023 (S. 299 1.P.C.)] INJURY: Section 2 (14) of BNS Act 45 of 2023 Any harm 
whatever illegally caused (o any person in body, mind, 
reputation or property (S.
- [Section 100 of The BNS Act 45 of 2023 (S. 299 1.P.C.)] CULPABLE HOMICIDE: Section 100 of BNS Act 45 of 
2023 (5.
- [Section 100 of The BNS Act 45 of 2023 (S. 299 1.P.C.)] (3) The 
causing of the death of a child in the mother's womb is not 
homicide.
- [Section 103 of BNS act 45 0£2023, (S. 302, 1.P.C.): Punishment] Section 103 of BNS act 45 0£2023, (S.
- [Section 103 of BNS act 45 0£2023, (S. 302, 1.P.C.): Punishment] 302, 1.P.C.): Punishment 
for murder: Death, or imprisonment for life, and also line.
- [Section 103 of BNS act 45 0£2023, (S. 302, 1.P.C.): Punishment] Secton 104 of BNS 45 0£2023, (S.
- [Section 103 of BNS act 45 0£2023, (S. 302, 1.P.C.): Punishment] 303, 1.2.C.): Punishiment 
for murder by life convict (death).
- [Section 103 of BNS act 45 0£2023, (S. 302, 1.P.C.): Punishment] Section 105 of BNS 45 of 

2023, (S.
- [Section 103 of BNS act 45 0£2023, (S. 302, 1.P.C.): Punishment] 304, 1..C).: Punishment for culpable homicide 
not amounting to murder: Imprisonment for life, or up to 
10 vears and also fine.
- [Section 106 of BNS 45 of 2023, (S. 304-A, [.LP.C.) Causing] Section 106 of BNS 45 of 2023, (S.
- [Section 107, BNS (S. 305, I.P.C.:) Abetment of suicide of] Section 107, BNS (S.
- [Section 107, BNS (S. 305, I.P.C.:) Abetment of suicide of] 305, I.P.C.:) Abetment of suicide of 
child or insane person (10 years imprisonment).
- [Section 108, BNS (S. 306, 1.P.C.) Abetment of suicide:] Section 108, BNS (S.
- [Section 108, BNS (S. 306, 1.P.C.) Abetment of suicide:] 306, 1.P.C.) Abetment of suicide: 
Suicide is the act of taking one's own life voluntarily.
- [Section 108, BNS (S. 306, 1.P.C.) Abetment of suicide:] If any 
person commits suicide, whoever abets the commission of 
such suicide, shall be punished with imprisonment for a 
term which may extend to 10 years, and shall also be liable 
to fine.
- [Section 109 of BNS 45 0f2023, (S. 307, .LP.C.) Attempt to] Section 109 of BNS 45 0f2023, (S.
- [Section 109 of BNS 45 0f2023, (S. 307, .LP.C.) Attempt to] 307, .LP.C.) Attempt to 
maurder is punishable with 10 years imprisonment.
- [Section 110 of BNS 45 of 2023, (S. 308, I.P.C.) Attempt to] Section 110 of BNS 45 of 2023, (S.
- [Section 110 of BNS 45 of 2023, (S. 308, I.P.C.) Attempt to] 308, I.P.C.) Attempt to 
commit culpable homicide is punishable with imprisonment 
up to 7 years orwith fine or both.
- [Section 226 of BNS 45 of 2023, S. 309, I.P.C.: Attempt to] Section 226 of BNS 45 of 2023, S.
- [Section 114 of BNS 45 of 2023, S. 319, I.P.C.: HURT:] Section 114 of BNS 45 of 2023, S.
- [Section 114 of BNS 45 of 2023, S. 319, I.P.C.: HURT:] 319, I.P.C.: HURT: 
Hurt means bodily pain, disease or infirmity caused to any 
person.
- [Section 88 to 123, of BNS 45 of 2023, (S. 312 to 328 of] Section 88 to 123, of BNS 45 of 2023, (S.
- [Section 88 to 123, of BNS 45 of 2023, (S. 312 to 328 of] 312 to 328 of 
LP.C.) deal with causing hurt and their punishments.
- [Section 116 of BNS act 45 of 2023, (S. 320, LP.C.:)] Section 116 of BNS act 45 of 2023, (S.
- [Section 116 of BNS act 45 of 2023, (S. 320, LP.C.:)] 320, LP.C.:) 
GRIEVOUS HURT: Any of the following injuries are 
grievous.
- [CHAPTER 10: Medicolegal Aspects of Wounds] (1) Emasculation: It means depriving a male of masculine 
vigor.
- [CHAPTER 10: Medicolegal Aspects of Wounds] (3) Permanent privation of the hearing of either ear: It 
deprives a man of his sense of hearing.
- [CHAPTER 10: Medicolegal Aspects of Wounds] (4) Privation of any member or joint: The term ‘member’ 
means an organ or a limb being part of man capable of 
performing a distinct function.
- [CHAPTER 10: Medicolegal Aspects of Wounds] (7) Fracture or dislocation of a bone or tooth (Fig.
- [CHAPTER 10: Medicolegal Aspects of Wounds] 10.1): Fracture of either outer or inner table of the skull is 
considered a fracture.
- [SECTION 1: Forensic Medicine] SECTION 1: Forensic Medicine 
Fig.
- [SECTION 1: Forensic Medicine] 10.1: Disarticulation of canine teeth.
- [SECTION 1: Forensic Medicine] Further Explanations for Section 116 clause 8 of BNS 
act 45 of 2023.
- [SECTION 1: Forensic Medicine] A mere stay of 15 days in the hospital does 
not make injury grievous, unless the injured person was in 
severe bodily pain, or unable to follow his ordinary pursuits 
for a period of 20 days.
- [SECTION 1: Forensic Medicine] An injury which endangerslife 
may cause severe bodily pain for 15 days, but an injury which 
causes such pain may not be dangerous to life, butitis still a 
grievous hurt under this clause.
- [SECTION 1: Forensic Medicine] ILLUSTRATIONS: (1) “A woman was confined to a hospital 
for 17 days due to certain injuries inflicted on her, but her life 

was in danger for 3 days only.
- [Section 115, BNS (S. 321, I.P.C.): Voluntarily causing] Section 115, BNS (S.
- [Section 115, BNS (S. 321, I.P.C.): Voluntarily causing] 321, I.P.C.): Voluntarily causing 
hurt.
- [Section 117, BNS (S. 322, I.P.C.): Voluntarily causing] Section 117, BNS (S.
- [Section 117, BNS (S. 322, I.P.C.): Voluntarily causing] 322, I.P.C.): Voluntarily causing 
grievous hurt.
- [Section 115 (2) of the BNS Act 45 of 2023, S. 323, .LP.C.:] Section 115 (2) of the BNS Act 45 of 2023, S.
- [Section 115 (2) of the BNS Act 45 of 2023, S. 323, .LP.C.:] 323, .LP.C.: 
Punishment for voluntarily causing hurt: Imprisonment up 
to 1 year, or with fine up to one thousand rupees or both.

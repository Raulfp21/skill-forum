# Section 80 of BNS act 45 of 2023, (S.304-B.,.P.C.) Dowry

## Introduction

Section 80 of BNS act 45 of 2023, (S.304-B.,.P.C.) Dowry 
Death—Definition: 1. Where the death of awoman is caused 
by anyburn or bodily injury or occurs otherwise than under 
normal circumstances within 7 years of her marriage and 
it is shown that soon before her death she was subjected to 
cruelty or harassment by her husband or any relative of her 
husband for, or in connection with, any demand for dowry, 
such death shall be called “dowry death’; and such husband 
or relative shall be deemed to have caused her death. 
2. Whoever commits dowry death shall be punished with 
imprisonment of not less than 7 years, but which may extend 
to life imprisonment.


# Section 106 of BNS 45 of 2023, (S. 304-A, [.LP.C.) Causing

## Introduction

Section 106 of BNS 45 of 2023, (S. 304-A, [.LP.C.) Causing 
death by negligence: “Whoever causes the death of any 
person, by doing any rash or negligent act not amounting to 
culpable homicide shall be punished with imprisonment for 
a term which may extend to 2 vears or with fine, or with both.


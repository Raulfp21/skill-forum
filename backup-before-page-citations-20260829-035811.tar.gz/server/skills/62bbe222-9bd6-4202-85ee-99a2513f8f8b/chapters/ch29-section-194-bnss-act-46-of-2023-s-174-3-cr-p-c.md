# Section 194 BNSS Act 46 of 2023. (S. 174 (3) Cr.P.C.)

## Introduction

Section 194 BNSS Act 46 of 2023. (S. 174 (3) Cr.P.C.) 
Procedure in dowry death (suicide, suspected murder, 
request by a relative; doubt of cause of death, police 
consider necessary). Police has to enquire and report. 
AB0]021X0] 
pue 
3UIP3\ 
JISUII0S 
JO 
S|enudss3 
3y 
5,Appay 
uekeleN 
SH

| 
4 
KS 
Narayan 
Reddy’s 
The 
Essentials 
of 
Forensic 
Medicine 
and 
Toxicology


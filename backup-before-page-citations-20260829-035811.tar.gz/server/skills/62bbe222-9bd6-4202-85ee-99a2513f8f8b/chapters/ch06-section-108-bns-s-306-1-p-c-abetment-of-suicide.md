# Section 108, BNS (S. 306, 1.P.C.) Abetment of suicide:

## Introduction

Section 108, BNS (S. 306, 1.P.C.) Abetment of suicide: 
Suicide is the act of taking one's own life voluntarily. If any 
person commits suicide, whoever abets the commission of 
such suicide, shall be punished with imprisonment for a 
term which may extend to 10 years, and shall also be liable 
to fine. There must be instigation, cooperation or intentional 
assistance given to the would be suicide. 
Dyadic death: A person killing someone and then 
commitdng suicide.


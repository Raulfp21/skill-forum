# Section 131, BNS (8. 352, 1.P.C.): Punishment for various

## Introduction

Section 131, BNS (8. 352, 1.P.C.): Punishment for various 
types of assault (imprison up to 3 months or fine)


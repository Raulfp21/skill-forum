# Section 84, BNS (S. 498A, I.P.C). Faulk has categorized these

## Introduction

Section 84, BNS (S. 498A, I.P.C). Faulk has categorized these 
men into five groups: (1) Dependent passive. (2) Dependent 
suspicious. (3) Violent and bullying. (4) Dominating. (5) 
Normal, stable and affectionate. 
CHILD SEXUAL ABUSE: Pedophilia is a psychological 
disorder in which an adult experiences a sexual preference 
for prepubescent children. Pedophilia crimes may be 
committed within a family or among acquaintance group, 
or by strangers. It includes: (1) sexual assault, (2) sexual 
molestation (nonpenetrative activity with a minor, such 
as exposing to pornography or to sexual acts of others), 
(3) sexual grooming, such as making a minor accepting of 
their advances. The effects of child sexual abuse include 
depression, post-traumatic stress syndrome, anxiety, physical 
injury, transmission of venereal disease. 
PROTECTION OF CHILDREN FROM SEXUAL OFFENCES 
ACT, 2012 (POCSO): It is an Act to protect children from 
offences of sexual assault, sexual harassment and pornography 
and provides for establishment of special session courts for 
trial of such offences. It recognizes forms of penetration other 
than penovaginal penetration, criminalizes act ofimmodesty, 
watching or collecting of pornographic content involving


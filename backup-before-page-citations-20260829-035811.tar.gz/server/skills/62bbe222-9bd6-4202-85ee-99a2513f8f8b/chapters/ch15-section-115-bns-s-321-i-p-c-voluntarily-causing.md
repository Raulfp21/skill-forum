# Section 115, BNS (S. 321, I.P.C.): Voluntarily causing

## Introduction

Section 115, BNS (S. 321, I.P.C.): Voluntarily causing 
hurt.


# Section 127, BNS (S. 340, I.P.C.): Wrongful confinement

## Introduction

Section 127, BNS (S. 340, I.P.C.): Wrongful confinement 
(imprisonment up to 1 year or fine or both, S. 342, .P.C.).


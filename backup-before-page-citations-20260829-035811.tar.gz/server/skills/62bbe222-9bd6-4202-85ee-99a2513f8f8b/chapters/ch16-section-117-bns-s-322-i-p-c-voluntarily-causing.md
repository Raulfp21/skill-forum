# Section 117, BNS (S. 322, I.P.C.): Voluntarily causing

## Introduction

Section 117, BNS (S. 322, I.P.C.): Voluntarily causing 
grievous hurt.


# Section 123, BNS (S. 328, 1.P.C.): Administering

## Introduction

Section 123, BNS (S. 328, 1.P.C.): Administering 
stupefying drug with intention to cause hurt, etc.


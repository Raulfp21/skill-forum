# SECTION 1: Forensic Medicine

## Introduction

SECTION 1: Forensic Medicine 
EXAMINATION OEHEACCUSEL) i 
General Procedure: The procedure of examination of 
the accused is similar to the victim. It is better to examine 
the accused after the victim, and to look specilically for any 
injuries, which she says she has inflicted. Il possible, the 
accused should be examined by the same doctor who has 
examined the victim, for better correlation between the 
injuries found on the female, such as bite marks, fingertip 
bruises, comparison of size and build and the physical features 
of the accused. 
Procedure: (1) The consent of the accused should be 
taken, and it should be explained to him that the report will 
be furnished to the police and courts, which may go against 
him, and that he has right to refuse consent. Accused can 
be examined without the consent as per Section 52, BNSS (S. 
53(A) Cr.P.C.) on the request of police officer. (2) He should be 
identfied by the escorting police constable, and identification 
marks should be recorded. (3) The examination must be 
begun without delay as the signs of the act disappear rapidly. 
(4) A general medical history should include details of all past 
illnesses, surgical operations, serious accidents, medication, 
and consumption of alcoholic drinks. No attempt should be 
made to obtain any history of the specific incident. It should 
be found out whether the accused had consenting intercourse 
with any person within the previous 24 hours; when did he 
had the last bath; when was the last change of clothing and his 
explanations for the injuries found on his body. (5) The exact 
time, date, month and place of examination should be noted. 
GENERAL EXAMINATION: (1) The age, development 
of genital organs and physical power of the accused should 
be noted and compared with that of female to determine 
the possibility of his overpowering her. (2) His mental state 
and general behavior (dazed or shocked, distressed or calm, 
co-operative or aggressive) should be observed. (3) If he 
appears to be under the influence of alcohol or drugs, it must 
be recorded. (4) The clothes should be examined for: (a) 
tears and loss of buttons, (b) hair, fibers and foreign matter, 
(c) cosmetic contact traces, e.g,, face powder or lipstick stains, 
(d) blood stains, (e) mud and other stains, grass, etc., and (f) 
seminal stains. Particles of earth or fibers trapped between the 
uppers and soles at the welt of shoes will identify the suspect 
with the scene. Trousers will often show soiling at the knees 
from grass and earth. Loose hair from the victim may be 
caughtin the zip fly. Blood and seminal stains may be present 
on the inside of the trouser fly and the inside of the underwear. 
The clothing may have physiological fluids or hairs from the 
woman on its surface. (1) Nail scrapings should be examined 
for blood, epithelial cells, fibers, etc. (2) Marks of struggle, 
such as bruises, scratches and teeth-bite marks on the face, 
neck, hands, chest, trunk, buttocks, upper limbs, thighs 
and genitals should be noted, caused during struggle from 
the resistance offered by the victim. The age of the injuries 
should be determined. (3) Note the matting of pubic hair due 
to emission of semen. (4) Female hair on the face, body or 
clothes of accused or of feminine pubic hair in his prepucial 
fold indicates commission of the offence. The hair should be 
preserved. (5) Existence of venereal disease must be looked for. 
Examination of the genitals: (1) Note the development of 
genital organs with special reference to the potency. (2) Note 
any scratches or abrasions and bruising on genitals caused 
by the victim during struggle for prevention of intercourse. 
Forceful penetration against the resistance into a virgin 
hymen, may produce tears or bruising of the frenulum of the 
prepuce in the uncircumcised, and abrasion of the glans 
penis in both the uncircumcised and the circumcised. Such 
injuries are more common in sexual assault involving very 
young children, because of the disparity in the size between 
the penis and the vagina. Reddening of the glans especially 
the rim, often patchy is more common. Dried blood stains 
may be found on the shaft of the penis, the scrotum and the 
adjoining skin. (3) Suspect’s penis is washed with saline, and 
the material is stained with Papanicolaou’s stain. Vaginal and 
cervical cells and Barr body identification suggest recent 
intercourse. (4) examine the glans for vaginal cells. This is 
done by cleaning the organ with filter-paper and exposing the 
paper to vapors of Lugol’s iodine. The paper becomes brown 
if vaginal epithelial cells are present, because of the glycogen. 
The test is positive up to fourth day. (5) Smegma: If accused is 
not circumcised, foreskin may be retracted and the presence 
or absence of smegma (cheesy secretion of sebaceous glands, 
consisting mainly of desquamated epithelial cells) on corona 
glandis should be noted. The absence of smegma may 
indicate that intercourse might have been performed 
but presence of smegma rules out possibility of complete 
penetration because smegma gets rubbed off during 
intercourse. Even after complete penetration of Penis in 
her genitalia the smegma not necessarily washes away 
completely. Hence its absence or presence is not conclusive 
either way. Smegma be removed by bathing or washing. 
Smegma usually requires about 24 hours to collect. 
DNA of the victim can be recovered from the swabs of 
the penis using STR DNA profiling technique up to 24 hours 
after intercourse if the individual did not bathe. Analysis 
identifies X chromosome and 8 STR loci. 
Specimens to be collected from accused: (1) Swab 
from coronal sulcus (after retracting the prepuce), prepuce, 
penile shaft and urethral orifice, for they may reveal infecting 
organisms or blood that may also be present on the victim'’s 
swabs. (2) Blood for grouping. (3) Pubic hair combings and 
avulsed pubic hair. (4) Matted pubic hair. (5) Head hair. (6) 
Loose hair found anywhere on the body. (7) Nail scrapings. 
Priapism is persistent abnormal erection of the penis, 
usually without sexual desire, and accompanied by pain and 
tenderness. It is seen in diseases and injuries of the spinal cord 
and certain injuries to the penis. 
Formication is voluntary sexual intercourse of the 
unmarried. 
INDECENT ASSAULT: Is any offence committed on 
a female with the intention or knowledge to outrage her 
modesty. Outrage means gross violation of decency, morality 
or feelings. Usually, the act involves the sexual parts of 
either or is sexually flavored. In such assaults, a man may try 
to kiss a woman, press or fondle her breasts, touch or expose 
the genitalia or thighs, try to put a finger in her vagina, play 
with vulva, etc. This is usually committed against children,

or adolescent girls and rarely on adult or old women. Men 
may encourage children to handle or masturbate their 
sexual organs. Indecent offences between two or more 
male persons include such offences as friction of penis 
on the gluteal folds, handling of the male genitalia, mutual 
masturbation, etc. or intercrural connection (penile friction 
between the inner thighs and external genitalia). Stripping 
naked a female patient for medical examinationis regarded 
as an assault. Such assaults are punishable under Section 
74, BNS (S. 354, .P.C.), up to one to 5 years imprisonment 
and fine. In such cases, medical examination is of little 
value. Abrasions or bruises may sometimes be present due 
to struggle. 
Modesty is an attribute associated with female human 
beings as a class. It is a virtue which attaches (to) a female 
owing to her sex. Knowledge that modesty is likely to be 
outraged is sufficient to constitute the offence without any 
deliberate intention of having such outrage alone for its object. 
The culpable intention of the accused is the crux of the matter. 
The reaction of the woman is very relevant, but its absence is 
not always decisive. 
SEXUAL HARASSMENT: It is an unwelcome sexual 
gesture or behavior whether directly or indirectly as: 
(1) Sexually colored remarks. (2) Physical contact and 
advances. (3) Showing pornography, (4) A demand 
or request for sexual favors. (5) Any other unwelcome 
physical, verbal, nonverbal conducts being sexual in 
nature. [SECTION 74, BNS (S. 354A, 1.P.C)] (imprisonment 
up to 3 years). 
WIFE BATTERING: A battered wife is a woman who has 
received a deliberate, severe and repeated demonstrable 
physical injuries from her husband. The involved men below 
the age of forty suffer from personality or neurotic disorders, 
while those over forty suffer from psychiatric disorder. 
Domestic discord, often in families with numerous children, 
drunkenness and demands for dowry are usually responsible


# Section 109 of BNS 45 0f2023, (S. 307, .LP.C.) Attempt to

## Introduction

Section 109 of BNS 45 0f2023, (S. 307, .LP.C.) Attempt to 
maurder is punishable with 10 years imprisonment.


# Section 226 of BNS 45 of 2023, S. 309, I.P.C.: Attempt to

## Introduction

Section 226 of BNS 45 of 2023, S. 309, I.P.C.: Attempt to 
Commit Suicide: Whoever attempts to commit suicide and 
does any act towards the commission of such offence, shall 
be punished with simple imprisonment for a term which may 
extend to 1year, orwith fine, or with both. 
Shooting, hanging and stabbing are a ‘hard’ way of 
committing suicide and typically a male choice; poisoning 
and drowning are ‘soft’ ways of committing suicide.


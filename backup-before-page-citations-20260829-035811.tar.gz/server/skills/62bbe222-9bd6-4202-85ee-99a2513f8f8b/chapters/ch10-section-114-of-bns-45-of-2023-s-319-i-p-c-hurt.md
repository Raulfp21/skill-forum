# Section 114 of BNS 45 of 2023, S. 319, I.P.C.: HURT:

## Introduction

Section 114 of BNS 45 of 2023, S. 319, I.P.C.: HURT: 
Hurt means bodily pain, disease or infirmity caused to any 
person. It does not include mental pain.


# CHAPTER 18: Sexual Offences

## Introduction

CHAPTER 18: Sexual Offences 
children and makes abetment of sexual abuse an offence. It is 
mandatory for everyone whoever comes to know about crimes 
under this act to inform the police. However Supreme Court 
Bench headed by Justice DY Chandrachude, AS Bopanna, and 
JB Pardiwala in 2023 under 19(1) of POCSO Act, 2012 RMP no 
binding to report or disclose to police as pregnancy of minor 
glrl durlng termination. 
Incest means sexual intercourse by a man with a woman 
who is closely related to him by blood (prohibited degrees of 
relationship), e.g., a daughter, granddaughter, sister, stepsister, 
aunt or mother. Incest between father and daughter and 
brothers and sisters are common. These cases usually have 
psychological features. In India, incest as such, is not an 
offence unless complaint lodged by either party or any 
third person. 
Incest occurs (1) Between mental defectives who are 
unable to understand the prohibitions against it, or whose 
feelings are too strong to inhibit them behaving in this way; 
(2) Where alcohol removes the natural inhibitions; (3) In case 
of cerebral disease, such as general paralysis, senile cerebral 
degeneration, etc. (4) Where a brother and sister have been 
separated since childhood or for a long period and meet later 
as strangers; (5) Where close relations have to live in intimacy. 
Adultery: Sexual intercourse with the wife of another man, 
without the consent or connivance of that man constitutes 
adultery. In such case, the wife shall not be punishable as an 
abettor. It has decriminalized. It can be a ground for divorce. 
[BNS DELETED (S. 497, I.P.C)]. 
UNNATURALEOEEENCGES 
Voluntary sexual intercourse against the order of nature 
with any man, or woman, or animal is an unnatural 
sex offence BNS DELETED (S. 377, [.P.C.). Explanation: 
Penetration is sufficient to constitute the offence. These 
offences are punishable with imprisonment for life or up to 
10 years and also with fine. Homosexuality means persistent 
emotional and physical attraction to members of the same 
sex. 
SODOMY: Sodomy is the anal intercourse between 
two males, or between a male and female. This used to be 
practiced in a town called Sodom. It is also called buggery. It 
is called gerontophilia when the passive agentis an adult, and 
pederasty, when the passive agent is a child, who is known as 
catamite. A pedophile is an adult who repeatedly engages 
in sexual activities with children. Aggression and sadism 
are inherent components of pedophilia. The Greeks of the 
“Golden Age” also practiced it, and it is sometimes referred 
to as Greek love. It can be heterosexual or homosexual. 
When practiced between two men, they may alternately act 
as active and passive agents. Any degree of penetration or 
any attempt at penetration just into the anal margin, are 
punishable. Proof of emission is not necessary. Sodomy 
between two adult males or a male and female in private 
with consent is not an offence, if the consent is free, voluntary 
in nature and devoid of any duress or coercion. Anal sex 
g 
AB60]0d1X0] 
pue 
aUIP3N 
JISUII0H 
JO 
S|eIIUISST 
3Y 
) 
s,AppaYy 
uekeleN 
S)


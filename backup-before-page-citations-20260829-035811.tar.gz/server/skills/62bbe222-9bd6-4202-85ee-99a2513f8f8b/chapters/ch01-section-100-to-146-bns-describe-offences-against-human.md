# Section 100 to 146, BNS Describe offences against human

## Introduction

Section 100 to 146, BNS Describe offences against human 
body; (299 10 377 1.P.C)


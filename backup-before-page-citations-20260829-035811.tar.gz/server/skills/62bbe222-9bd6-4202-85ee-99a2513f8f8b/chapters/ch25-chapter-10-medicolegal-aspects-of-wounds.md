# CHAPTER 10: Medicolegal Aspects of Wounds

## Introduction

CHAPTER 10: Medicolegal Aspects of Wounds 
person to go from any place, is said to abduct that person. 
Abduction may take place against any person of any age. 
For abducting a person force, compulsion or deceitful 
means are used. Free and voluntary consent of the person 
abducted condones abduction. Intention of the abductor 
is an important factor in determining guilt of the accused. 
1t is not a substantive offence and is punishable only when 
done with some other intent under Section 140, 87,96, 141, 
140,142,97 of BNS Act of 45 of 2023. (S. 364 to 369 I.P.C.) 
The offence continues as long as the abducted person is 
removed from one place to another. 
The Dowry Prohibition Act of 1961, defines ‘dowry’ to mean 
any property or valuable security given to or agreed to be 
given either directly or indirectly: (a) by one party to marriage 
to the other party to the marriage, or (b) by the parents of 
either party to marriage or by any other person to either party 
to the marriage in connection with the marriage of the said 
parties, but does not include dower or mahr in the case of 
persons whom the Muslim Personal Law applies to. It excludes 
presents in the form of clothes, ornaments, etc., which are 
customary at marriages. 
S. 3 of the Act provides for penalty for giving or taking 
dowry and S.4 penalty for demanding dowry. 
In some cases newly married girls are abused, harassed, 
cruelly treated and tortured by the husband, in-laws and their 
relatives for or in connection with any demand for dowry. In 
extreme cases, the woman is killed by burning or some other 
method.


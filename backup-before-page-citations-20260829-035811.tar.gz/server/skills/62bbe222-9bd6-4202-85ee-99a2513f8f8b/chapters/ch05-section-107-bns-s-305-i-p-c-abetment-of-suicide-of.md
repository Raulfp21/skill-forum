# Section 107, BNS (S. 305, I.P.C.:) Abetment of suicide of

## Introduction

Section 107, BNS (S. 305, I.P.C.:) Abetment of suicide of 
child or insane person (10 years imprisonment).


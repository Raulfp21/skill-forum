# SECTION 1: Forensic Medicine

## Introduction

SECTION 1: Forensic Medicine 
Dowry deaths occur cither by murder of a married 
woman or she hersellf committing suicide being unable to 
bear harassment or cruelty for not fulfilling the promises 
by her parents or her relatives or of those interested in 
her marriage. Ovarian steroidogenic activity in women 
reaches peak during luteal and premenstrual period, 
which causes physical and psychological tension in 
women. Suicidal tendency is more in some females in 
luteal and premenstrual phase. Look for signs of neglect, 
malnutrition, physical injuries, poisoning, infertility, 
pregnancy and menstrual phase. Such murders are 
invariably committed secretly either in the house or at a 
place where outsiders may not witness it. The bride may be 
burnt or Killed by various methods. The usual defense in 
all dowry death cases is that cither the woman committed 
suicide, or death occurred accidentally due to burns while 
cooking food. 
In premenstrual and menstrual phase, due to hormonal 
imbalance many females become oversensitive and depressive 
even on trivial issue and may commit suicide. Hypothyroidism 
is associated with paranoid and depressive behavior due to 
which she may commit suicide. 
The doctor should make a record of the history of the 
injuries and the persons responsible for it, when the victim 
is brought to the hospital, noting the time and the name of 
the person who gave the history. The condition of the victim 
should be recorded at frequent intervals. Care should be 
taken that no person has discussion with the victim before 
doctor records the statement of the victim to avoid any 
undue influence being exerted on her. A Magistrate may 
be called torecord the dying declaration. Visit to the scene 
of crime by the doctor and other forensic scientists is very 
helpful in determining the manner of death. 
Inquest should be conducted by a Magistrate or police 
officer not below the rank of deputy superintendent of 
police, and autopsy should be carried out by two doctors 
in case of dowry death. 
WOUND CERTIFICATE: The casualty medical officer or 
any other registered medical practitioner may be called upon 
to examine injured person. Medicolegal injury cases should 
be examined without delay at any time of day or night. All 
details of examination of injured person, whether admitted 
into hospital or treated as outpatients have to be entered in 
an Accident Register, maintained in all hospitals inclusive 
of clinic’s or Nursing homes. This register is a confidential 
record and should be in safe custody of the medical officer. 
It has to be produced in a Court of law if asked for. A detailed 
and accurate record should be made by the doctor at the time 
of the examination. The doctor is required to fill in a printed 
form of injury or wound certificate, one copy of which is sent 
to the investigating police officer in a sealed cover, and the 
other is retained for future reference. 
If an injured person is brought to hospital, and labelled 
as M.L.C. the doctor should inform the local police station 
over telephone or by a letter of intimation. All the cases of 
wounds or poisoning should be entered in accident register 
irrespective of whether information 1o police is sent or not. 
Preliminary particulars: The lollowing particulars shoulg 
be noted. (1) Serial number of case (2) Name, age and sex of 
the njured person and address. (3) Father's or guardian’y 
name. (4) Date, time and place of examination. (5) Name ang 
number of the accompanying police constable and the poljce 
station to which he belongs. (6) Names of the persons wihy, 
had accompanied the injured person with their address, (7) 
A brief statement ol the injured person about the exact nature 
ol incident, where the Incident took place, time and date of 
incident, detalls ol physical force used In assault. This is to be 
recorded as “alleged by the patient”. (8) Two identification 
marks, (9) The slze of the victm, Le, stature, body weight and 
development. (10) The consentof the person for examination 
should be taken. Il the conditon of the patient is serious, dying 
declaration should be recorded. 
The following are the various entries in the wound 
certificate: 
(1) Type of each injury: All injuries observed, however 
insignificant they may appear should be noted. The nature 
of each injury, i.e., abrasion, contusion, incised wound, 
lacerated wound, stab wound, burns, fracture, dislocation, etc., 
should be noted. It may be convenient to deal with multiple 
injuries by grouping them according to their kind and severity, 
Alternatively, it may be better to group them anatomically, 
e.g., injuries of the head, of the trunk or of a limb. A lens 
should be used to get an accurate idea of the nature of the 
edges, ends and floor of a wound. Note whether the edges 
are smooth, ragged, abraded, contused, inverted or everted, 
and the ends sharp, blunt, square, split or show tailing. The 
presence of any foreign material in the wound, e.g., metal, 
glass, splinter of wood, broken point of a knife, pellet, bullet or 
wad of a firearm, hair, dirt, etc., should be noted, preserved and 
handed over to police. Photographs are useful. The position of 
injuries can also be shown on body sketch. 
(2) Size, shape and direction of each injury: All injuries 
should be measured with a tape and never guessed, and 
the amount of blood extravasated should be measured and 
photographs or sketches, showing the position and size 
of the wounds is desirable. The shape of the wound, e.g,, 
circular, oval, triangular, elliptical, etc., should be noted and 
also the beveling of the edges. The direction of the wound, 
i.e., horizontal, vertical, oblique, etc., should be noted with 
regard to the anatomical position of the body. In case of stab 
and firearm wounds, direction of the wound should be noted. 
The pattern of the wound if any should be noted. 
(3) On what part of body inflicted: The exact situation 
of wound with reference to some anatomical landmark, 
e.g., the middle line, a bony structure, a joint, the navel or 
the nipple should be mentioned. Technical terms should 
be avoided as far as possible. Photographs are useful. The 
position of injuries can also be shown on body sketch. 
(4) Simple, grievous or dangerous injury: Against each 
injury, it should be noted whether it is simple, grievous 
or dangerous, The injured person must be kept under 
observation, if the nature of a particular injury cannot be 
made out at the time of examination, e.g., in head injury 
where the symptoms are obscure or abdominal injuries with 
vague symptoms. In all injuries, when a fracture of a bone

> 
o 
S 
o 
i 
5 
‘_ 
o 
c 
[} 
] 
£ 
= 
S 
[} 
= 
(2 
n 
c 
@ 
e 
< 
L 
N 
o 
-~ 
1] 
2 
c 
@ 
(%] 
w 
w 
o 
£ 
- 
o 
> 
S 
o 
1 
3 
c 
(1] 
> 
[ 
- 
1} 
r= 
(%] 
X


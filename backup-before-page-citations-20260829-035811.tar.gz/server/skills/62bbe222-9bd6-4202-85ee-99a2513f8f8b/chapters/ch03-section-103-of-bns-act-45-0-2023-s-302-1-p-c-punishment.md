# Section 103 of BNS act 45 0£2023, (S. 302, 1.P.C.): Punishment

## Introduction

Section 103 of BNS act 45 0£2023, (S. 302, 1.P.C.): Punishment 
for murder: Death, or imprisonment for life, and also line. 
Secton 104 of BNS 45 0£2023, (S. 303, 1.2.C.): Punishiment 
for murder by life convict (death). Section 105 of BNS 45 of 

2023, (S. 304, 1..C).: Punishment for culpable homicide 
not amounting to murder: Imprisonment for life, or up to 
10 vears and also fine. “Provided that if death is caused to 
a girl or awoman, the accused committing such homicide 
shall be punished with imprisonment for whole life and 
shall also be liable for fine which may extend to two lakh 
rupees.”


# Section 116 of BNS act 45 of 2023, (S. 320, LP.C.:)

## Introduction

Section 116 of BNS act 45 of 2023, (S. 320, LP.C.:) 
GRIEVOUS HURT: Any of the following injuries are 
grievous. (1) Emasculation, (2) Permanent privation of sight 
of either eye, (3) Permanent privation of hearing of either 
ear, (4) Privation of any member or joint (5) Destruction or 
permanent impairing of the power of any member or joint, (G) 
Permanent disfiguration of the head or face, (7) Fracture or 
dislocation of a bone or tooth, (8) Any hurt which endangers 
life, or which causes the victim to be in severe bodily pain, or 
unable to follow his ordinary pursuits for a period of 15 days. 
COMMENT: Grievous hurt is hurt of a more serious nature. 
It is very difficult to draw a line between those bodily hurts 
which are serious and those which are slight. To make out the


# SECTION 1: Forensic Medicine

## Introduction

SECTION 1: Forensic Medicine 
Fig. 10.1: Disarticulation of canine teeth. A case of grievous Injury. 
the bone. If there is a break by cutting or splintering of the 
bone, or there is a rupture or fissure in it, it would amount 
to a fracture. Dislocation means displacement (Fig. 10.1). 
Mere looseness of teeth will not amount to dislocation. It 
has to be proved that the tooth was originally not loose, and 
that there was fracture or dislocation by the injury. Fracture or 
dislocation of a bone or tooth causes great pain and suffering 
to the injured person and is considered grievous hurt. 
(8) Any hurt which endangers life, or which causes the 
victim to be in severe bodily pain, or unable to follow his 
ordinary pursuits for a period of 15 days: Some hurts which 
are not like those kinds of hurts which are mentioned in the 
first seven clauses, may be most serious. A wound may cause 
intense pain, prolonged disease, or lasting injury, but does not 
fall within any of seven clauses. A beating may not mutilate 
the sufferer or fracture his bones, but may be so cruel as to 
bring him to the point of death. The eighth clause provides 
for such hurts. Under this, three different clauses of hurt are 
included. They are: (1) any hurt which endangers life, (2) any 
hurt which causes the victim to be in severe bodily pain for a 
period of 20 days, and (3) any hurt which prevents the victim 
from following his ordinary pursuits for a period of 15 days. 
The three clauses are independent of each other, and a hurt 
of any of the three clauses would be a grievous hurt. 
Further Explanations for Section 116 clause 8 of BNS 
act 45 of 2023. Any hurt which endangers life: An injury 
can be said to endanger life, if it is itself such that it may 
put the life of the injured in danger. An injury caused on a 
vital part of the body cannot be called grievous hurt, unless 
the nature and dimensions of the injury or its effects are such 
that the doctor is of the opinion that it actually endangers the 
life of the victim. Administration of harmful drug to a person 
to make him unconscious is not grievous hurt, even though in 
some cases death may be caused if the drug is given in large 
dose. Ifthe life of the person is not endangered, itis not a case 
of grievous hurt. To designate an injury as grievous hurt, 
danger to life should be imminent. 
Dangerous injuries are those which cause imminent 
danger to life, either by involvement of important organs 
or structures, or extensive area of the body. If no surgical 
aid 
is 
available, 
such 
injuries 
may 
prove 
fatal. 
The 
concept 
of injury dangerous to life is not very precise. As such, it g 
not enough if the medical witness makes simple statemen, 
that injury in a particular part is dangerous to human life, He 
should place all relevant data, namely the nature and exten, 
ofinjury, the kind of weapon used, the part of the body struck, 
whether the injury caused hemorrhage or shock, affecteq 
fmportant structures or organs, or was very extensive, or 
otherwise caused imminent danger, and should also state 
the varlous grounds on which he considers the injury to be 3 
dangerous 
one, 
Some 
examples 
of 
injuries 
which 
endanger 
life 
are: stab on the abdomen or head or vital part, hurt causing 
rupture of spleen, squeezing testicles, incised wound on the 
neck, 
compound 
fracture 
of 
the 
skull, 
rupture 
of 
an 
internal 
organ, injury of a large blood vessel. Any hurt which causes 
the victim to be in severe bodily pain, or unable to follow his 
ordinary 
pursuits 
for 
a 
period 
of 
20 
days: 
The 
length 
of 
time 
during 
which 
a 
sufferer 
is 
in 
pain, 
disease 
or 
incapacitated 
from pursuing his ordinary occupation is a defective criterion 
of 
the 
severity 
of 
a 
hurt. 
Itis 
employed 
not 
only 
in 
cases 
where 
violence 
has 
been 
used, 
but 
also 
in 
cases 
where 
hurt 
been 
caused without any assault, e.g., by the administration of 
drugs, 
the 
setting 
of 
traps, 
the 
digging 
of 
pitfalls, 
the 
placing 
of 
ropes across aroad, etc. The extent of hurt and the intention 
of the offender are considered for giving punishment. It is 
difficult 
to 
prove 
that 
an 
injured 
person 
was 
in 
severe 
bodily 
pain 
for 
20 
days, 
butitis 
easier 
to 
prove 
that 
he 
was 
unable 
1o 
follow 
his 
ordinary 
pursuits 
due 
to 
the 
hurt. 
The 
opinion 
of 
the doctor attending on the patientis important, on the point 
of his disability. A mere stay of 15 days in the hospital does 
not make injury grievous, unless the injured person was in 
severe bodily pain, or unable to follow his ordinary pursuits 
for a period of 20 days. Ordinary pursuits include acts of 
daily routine of a person, such as eating food, taking bath, 
going 
to 
the 
toilet, 
etc., 
but 
do 
not 
refer 
to 
the 
duties 
that 
constitute the job of a person. An injury which endangerslife 
may cause severe bodily pain for 15 days, but an injury which 
causes such pain may not be dangerous to life, butitis still a 
grievous hurt under this clause. 
The 
possibility 
of 
correction 
of 
any 
of 
the 
above 
through 
surgery 
should 
not 
be 
a 
factor 
while 
assessing 
such 
injury. 
The line between culpable homicide not amounting to 
murder 
and 
grievous 
hurt 
is 
very 
thin. 
In 
the 
former, 
the 
injuries must be such as are likely to cause death, in the latter 
the injuries must be such as to endanger life. The likelihood of 
death resulting from an injury will depend upon severity of 
injury, 
the 
structures 
involved, 
age 
of 
the 
individual, 
and 
the 
state 
of 
health 
of 
the 
injured. 
Where 
there 
is 
no.intention 
(e 
cause 
death, 
or 
no 
knowledge 
that 
death 
is 
likely 
to 
be 
caused 
from 
the 
harm 
inflicted 
and 
death 
is 
caused, 
the 
accused 
would 
be guilty of grievous hurt if the injury caused was of serious 
nature, but not of culpable homicide. 
In case of hurt, the duty of the medical witness is only t0 
describe the facts. It is the Court that must decide whether it 
is simple or grievous. The entry made in the wound certificate 
as simple or grievous is only meant to guide the investigating 
officer. 
ILLUSTRATIONS: (1) “A woman was confined to a hospital 
for 17 days due to certain injuries inflicted on her, but her life 

was in danger for 3 days only. It was held that the injuries 
were grievous”. (2) “The thrusting of a lathi into the anus of a 
man has been held to be the causing of grievous hurt which 
endangers life” (3) ‘During an altercation, the victim was 
stabbed on the left forearm with a knife, due to which the 
radial artery was injured and the victim died soon after due 
to hemorrhage. It was held that the offence is neither murder, 
nor culpable homicide not amounting to murder, as the 
forearm is not a vital part. The accused was held to be guilty 
of voluntarily causing grievous hurt with a deadly weapon” 
(4) “In case of injury to the abdomen, where intestines had 
come out of the wound, it was held to be grievous hurt’} (5) “A 
deep injury which may be deep to the bone, but withouta cut 
in the bone or fracture is not grievous hurt’) (6) “Where death 
is caused as the result of an injury which is not intended to 
cause death, and was notin normal conditions likely to cause 
death, it is neither grievous hurt nor culpable homicide not 
amounting to murder’, (7) Coma of any duration due to head 
injury constitutes grievous injury., 
SIMPLE INJURY: Simple injury is one which is neither 
extensive nor serious and which heals rapidly. 
Some of Legal definitions that may be remembered by 
medical Practitioner


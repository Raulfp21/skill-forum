# Section 100 of The BNS Act 45 of 2023 (S. 299 1.P.C.)

## Introduction

Section 100 of The BNS Act 45 of 2023 (S. 299 1.P.C.) 
Define Homicide. 
HOMICIDE: Homicide is killing of a human being by 
another human being, 
Who ever causes death by doing an act with: 
(1) Intension of causing death, or 
(2) With intention of causing such bodily injury as 
likely, to cause death or 
(3) With the knowledge that he/she Is likely by such 
act 1o cause death commit’s offence of culpable homicide 
Types of Homiclde: (1) Culpable homicide amounting to 
Murder Section 101 of BNS Act 45 0f 2023 (S. 300, 1.2.C.). (2) 
Culpable 
homicide 
not 
amounting 
to 
Murder—Punishment 
for 
causing 
death 
of 
person 
other 
than 
intended 
Sectlon 
102 
of 
The 
BNS 
Act 
45 
0f 
2023 
(S, 
301, 
LP.C.). 
(3) 
Punishment 
for 
Murder 
S. 
103 
of 
The 
BNS 
Act 
45 
of 
2023 
(S, 
308, 
1L.1.C.). 
(4) 
Punishment 
for 
Murder 
by 
life 
convict 
Section 
104 
of 
BNS 
Act 
45 
of 
2023 
(S. 
300, 
1P.C.). 
(5) 
Punishment 
for 
culpable 
MedicolegaliAspectsiofiWounds 
homicide not amounting to murder. Section 105 of BNS Act 
45 of 2023 (8. 304, L.P.C). (6) Punishment causing death by 
Negligence Section 106 of BNS Act 45 0f 2023 (S. 304A 1.P.C). 
(7) Dowry Death; Section 80 of BNS Act 45 of 2023 (S. 304. 
B [.P.C). (8) Abatement of Suicide Section 108 of The BNS 
Act 45 of 2023 (S. 306 1.P.C). Attempt to commit culpable 
Homicide Section 109 of BNS Act 45 0f 2023 (S. 307 I.P.C). (9) 
Attempt to murder Section 109 of BNS Act 45 of 2023 (S. 307 
1.P.C). (10) Attempt to commit Suicide to compel or restraint 
exercise 10) Attemptpower Section 226 of The BNS Act 45 of 
2023 (S. 309 1.2.C). (11) Rash or negligent homicide Section 
281. of BNS Act 45 of 2023 (S. 279, .2.C). 
Justifiable Homicide: This is the homicide which is 
justified in the circumstances which led to the killing of a 
person. This may occur (1) In the administration of justice, 
like execution of sentence of death, (2) The maintenance of 
justice, e.g., in suppressing riots, or executing arrest, or killing 
in course of violent crime, e.g., a woman who kills a person 
who attempts to rape her. 
Excusable Homicide: This is the homicide caused 
unintentionally by an act done in good faith. This includes 
(1) Killing in sell-defense when attacked, provided there is 
no other means of defense, (2) Causing death by accident 
or misadventure, (3) Death following a lawful operation, 
(4) Homicide committed by an insane person. The terms 
justifiable and excusable homicide are not used in Indian 
law. 
INJURY: Section 2 (14) of BNS Act 45 of 2023 Any harm 
whatever illegally caused (o any person in body, mind, 
reputation or property (S. 44, LP.C.). 
CULPABLE HOMICIDE: Section 100 of BNS Act 45 of 
2023 (5. 299 1.P.C.) Define Homicide 
Culpable homicide is causing death by dolng an act (1) 
with the intention of causing death, ov (2) with the intention 
of causing such bodily injury as is likely to cause death, ov (3) 
with the knowledge that such act is likely to cause death 
(Sec. 299, LP.C.). 
Explanatlons: (1) A person who causes bodily injury to 
another who is sulfering from a disorder, disease ov bodily 
infirmity which accelerates the death of the person, shall be 
deemed (o have caused his death, (2) Where death is caused 
by bodily injury, the person who caused such bodily injury

l SECTION 1: Forensic Medicine 
L4 
KS 
Narayan 
Reddy’s 
The 
Essentials 
of 
Forensic 
Medicine 
and 
Toxicology 
shall be deemed to have caused death, although by skill(ul 
treatment, the death might have been prevented. (3) The 
causing of the death of a child in the mother's womb is not 
homicide. But it may amount to culpable homicide to cause 
the death of a living child, if any part of that child has been 
brought forth, though the child may not have breathed or 
been completely born. 
CULPABLE HOMICIDE IS MURDER under Section 101 
of BNS Act 45 0f 2023 (S.300 1.2.C.) 
MURDER: Culpable homicide is murder (1) If the act by 
which the death is caused is done with the intention of causing 
death, or (2) If it is done with the intention of causing such 
bodily injury as the offender knows to be likely to cause death, 
or (3) Ifitis done with the intention of causing bodily injury 
whichis sufficient in the ordinary course of nature to cause 
death, or (4) If the person committing the act knows that it is 
so immediately dangerous, that it must in all probability cause 
death, or such bodily injury as is likely to cause death and 
commits such act without any excuse (S. 101 BNS.). 
Exceptions: Culpable homicide does not amount to 
murder, if the act by which death is caused is done: (1) 
Under grave and sudden provocation, (2) In good faith of the 
right of private defense of person or property (5.96 to 106, 
1.P.C.), (3) for the advancement of public justice, (4) without 
premeditation, and (5) when the person above the age of 18 
years takes the risk of death with his own consent. 
COMMENT: During a quarrel, death may occur from 
rupture of the heart, the bursting of an aneurysm, cerebral or 
subarachnoid hemorrhage, hypertension or any other natural 
disease. If it can be proved from autopsy that death resulted 
from a natural cause, and that the infliction of the injury did 
not operate in any way either immediately or remotely, the 
assailant will not be responsible for the death of his victim. 
In these cases, death might have taken place about the same 
time and in the same circumstances whether there was a 
quarrel or not. Death may occur from a slight injury inflicted 
on a previously diseased organ, e.g., miliary aneurysms, fatty 
degeneration of the heart, duodenal ulcer, ulcerative colitis, 
enlarged spleen especially due to malaria, amoebic abscess, 
hydatid cyst, tuberculosis, disseminated sclerosis, Parkinson- 
ism, etc. Dissemination of a neoplasm might be accelerated by 
direct injury. Acceleration of the progress of an already fatal 
illness may also occur following injury. In law, a causal relation 
is established if trauma aggravates, hastens or precipitates a 
disease condition. It is not necessary that the trauma be an 
aetiologic cause, In such cases, if injury accelerates the process 
of dying or precipitates death, the assailant is not guilty of 
culpable homicide, but he can be charged of simple or griev- 
ous hurt, if it can be proved: (1) that he had no intention to 
kill his victim, (2) that he could not have possibly known the 
existence of that disease, and (3) that the same injury would 
not have caused death when inflicted on a healthy person. A 
person can be convicted of culpable homicide, if he causes 
bodily injury to another who is suffering from disease, disorder 
or physical weakness and thereby accelerates the death of the 
other person, if he had intention to kill or had the knowledge 
that such injury is sufficient or likely to cause death. 
To substantiate a charge of murder or culpable homicide, 
itis necessary (o prove that the injury inflicted on the deceased 
was the cause ol death, and the act was committed with 
the intention of causing such bodily injury as the offender 
knew that it was lkely, or sufficlent in the ordinary course of 
nature (o cause death. If these conditions are not satisfied, 
the assailant may be convicted under the offence of culpable 
homicide not amounting to murder, or grievous or simple 
hurt, according to the circumstances of the case, including 
the kind of weapons and the site of the violence. 
ABODILY 
INJURY 
WHICH 
IS 
LIKELY 
TO 
CAUSE 
DEATH 
is one in which death is not merely possible but is likely. It 
constitutes a grave danger to the life of the affected person 
due 
to 
its 
severity 
or 
of 
the 
structures 
involved. 
It 
applies 
in 
special 
cases 
where 
person 
injured 
is 
in 
such 
a 
condition 
or 
state 
of 
health, 
that 
his 
or 
her 
death 
is 
likely 
to 
be 
caused 
by 
an 
injury 
which 
would 
not 
ordinarily 
cause 
the 
death 
of 
a 
person 
in 
sound 
health, 
and 
where 
the 
person 
inflicting 
the 
injury 
knows 
that 
owing 
to 
such 
condition 
or 
state 
of 
health, 
it 
is 
likely 
to 
cause 
the 
death 
of 
the 
person 
injured. 
A 
BODILY 
INJURY 
WHICH 
IS 
SUFFICIENT 
IN 
THE 
ORDINARY 
COURSE 
OF 
NATURE 
TO 
CAUSE 
DEATH 
is 
one 
as 
a 
result 
of 
which 
death 
is 
very 
probable. 
Death 
must 
be 
the 
result 
of 
the 
direct 
effects 
of 
the 
injury. 
If 
there 
was 
a 
lesser 
probability 
of 
death 
resulting 
from 
the 
act 
committed, 
the 
finding 
will 
be 
that 
accused 
intended 
to 
cause 
injury 
likely 
to 
cause 
death. 
An 
injury 
sufficient 
in 
the 
ordinary 
course 
of 
nature 
to 
cause 
death, 
need 
not 
cause 
death 
inevitably 
and 
in 
all 
circumstances. 
The 
sufficiency 
is 
the 
high 
probability 
of 
death 
in 
the 
ordinary 
way 
of 
nature. 
It 
is 
not 
always 
easy 
to 
decide 
whether 
or 
not 
an 
injury 
is 
one 
that 
is 
sufficient 
in 
the 
ordinary 
course 
of 
nature 
to 
cause 
death. 
Some 
examples 
are: 
stab 
injuries 
or 
rupture 
of 
the 
heart; 
injury 
to 
the 
large 
blood 
vessels; 
stab 
on 
the 
abdomen, 
chest 
or 
other 
parts 
of 
the body injuring an internal organ or a large blood vessel; 
hurt causing rupture of spleen, liver or an internal organ; 
severe injuries of the brain and spinal cord; incised wound 
on the neck; compound fracture of the skull; squeezing of the 
testicles; 
penetrating 
wounds 
or 
rupture 
of 
the 
gastrointestinal 
canal; extensive burns and scalds; hanging or strangulating 
a 
person; 
smothering 
or 
gagging; 
drowning; 
failure 
to 
tie 
the 
cord after it is cut in a newborn; administering large dose of 
poison, 
etc. 
A 
number 
of 
injuries, 
none 
of 
which 
is 
sufficient 
initsell 
to 
cause 
death 
may 
together 
by 
their 
cumulative 
eftect 
be sufficient to cause death. 
The offence is culpable homicide, if the body injury 
intended to be inflicted is likely to cause death. It is murder, 
if such injury is sufficient in the ordinary course of nature 
to cause death. The distinction is fine but appreciable. The 
nature of the weapon has to be considered. A blow from the fist 
or a stick on a vital part may be likely lo cause death; a wound 
Jrom a knife in a vital part is sufficient in the ordinary course 
of nature to cause death. 
Punishments for various offences described as under:


# Section 115 (2) of the BNS Act 45 of 2023, S. 323, .LP.C.:

## Introduction

Section 115 (2) of the BNS Act 45 of 2023, S. 323, .LP.C.: 
Punishment for voluntarily causing hurt: Imprisonment up 
to 1 year, or with fine up to one thousand rupees or both.


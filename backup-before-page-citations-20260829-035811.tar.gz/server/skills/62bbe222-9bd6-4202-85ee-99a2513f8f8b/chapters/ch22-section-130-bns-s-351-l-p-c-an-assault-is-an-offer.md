# Section 130, BNS (S. 351, L.P.C.): An assault is an offer

## Introduction

Section 130, BNS (S. 351, L.P.C.): An assault is an offer 
or threat or attempt to apply force to body of another in 
a hostile manner. It may be a common assault or with an 
intent to murder.


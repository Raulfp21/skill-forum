# Section 117 (2) of BNS Act 45 of 2023, S. 325, .P.C.:

## Introduction

Section 117 (2) of BNS Act 45 of 2023, S. 325, .P.C.: 
Punishment for voluntarily causing grievous hurt: 
Imprisonment for a term extending to 7 years and fine. 
Séction 118 0f BNS Act45 0f2023, S. 326, .P.C.: Voluntarily 
causing grievous hurt by dangerous weapons or means: 
Imprisonment for life or up to 10 years and also fine. 
Dangerous weapons or means include any instrument 
for shooting, stabbing or cutting or any instrument, which 
used as a weapon of offence, is likely to cause death; fire or 
any heated substance; poison or any corrosive substance; 
explosive substance or any substance which is harmful to 
the human body to inhale, to swallow, or to receive into the 
blood or by means of any animal.


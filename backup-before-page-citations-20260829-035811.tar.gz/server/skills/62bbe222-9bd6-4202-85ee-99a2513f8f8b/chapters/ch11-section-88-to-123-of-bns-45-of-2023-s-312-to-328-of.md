# Section 88 to 123, of BNS 45 of 2023, (S. 312 to 328 of

## Introduction

Section 88 to 123, of BNS 45 of 2023, (S. 312 to 328 of 
LP.C.) deal with causing hurt and their punishments. 
Infirmity is any inability of an organ to perform 
usual function, which may be temporary or permanent. A 
temporary mental impairment or terror would constitute 
infirmity.


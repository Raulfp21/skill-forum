# Section 85, BNS (S. 498 A, 1.P.C.) Whoever being the

## Introduction

Section 85, BNS (S. 498 A, 1.P.C.) Whoever being the 
husband or the relatives of the husband of the woman, 
subjects such woman to cruelty shall be punished with 
imprisonment for a term which may extend to 3 years and 
shall also be liable to fine. 
Cruelty has been defined as any willful conduct which 
drives the woman to commit suicide or grave mental or 
physical injury to her or harassment of the woman with a 
view to coerce her for dowry.


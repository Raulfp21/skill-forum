# Section 118, BNS (S. 324, I.P.C.): Voluntarily causing hurt

## Introduction

Section 118, BNS (S. 324, I.P.C.): Voluntarily causing hurt 
by dangerous weapons or means (3 years imprisonment) 
or with fine or both.


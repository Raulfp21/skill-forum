# Section 138,(S. 362, I.P.C.): ABDUCTION: Whoever by

## Introduction

Section 138,(S. 362, I.P.C.): ABDUCTION: Whoever by 
force compels, or by any deceitful means induces, any


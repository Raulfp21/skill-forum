# Section 110 of BNS 45 of 2023, (S. 308, I.P.C.) Attempt to

## Introduction

Section 110 of BNS 45 of 2023, (S. 308, I.P.C.) Attempt to 
commit culpable homicide is punishable with imprisonment 
up to 7 years orwith fine or both.


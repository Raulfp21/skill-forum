# CHAPTER 10: Medicolegal Aspects of Wounds

## Introduction

CHAPTER 10: Medicolegal Aspects of Wounds 
offence of voluntarily causing grievous hurt, there must be 
some specific hurt, voluntarily inflicted, and coming within 
any of the eight kinds enumerated in this section. 
(1) Emasculation: It means depriving a male of masculine 
vigor. Amputation of penis, injuries to the genitals or head, 
fracture pelvis with injury to parasympathetics, fracture spine 
at thelevel of lumbar 4 and 5 with injury to sacral segments of 
spinal cord (erigentes nerve, genital branch of genito-urinary 
nerve) can result in impotence. If the testes are removed 
before puberty, impotence s the rule, butif they are removed 
after puberty potency is retained. 
(2) 
Permanent 
privation 
(loss) 
of 
sight 
of 
either 
eye: 
The gravity of such injury lies in its permanency because it 
deprives a person of the use of the organ of sight and also 
disfigures him. It can be caused by gouging out of eyes, poking 
eyes, chemicals, etc. Pmanent loss does not mean that it 
should be incurable, e.g, loss of sight occurring due to corneal 
opacity resulting from injury to the cornea may be curable by 
corneoplasty. It constitutes grievous injury. 
(3) Permanent privation of the hearing of either ear: It 
deprives a man of his sense of hearing. Such injuries may be 
caused by a blow on the head or the ear, or by blows which 
injure the tympanum or auditory nerves or by thrusting 
something or pouring hot liquid into the ear or by a blast 
which causes deafness. 
(4) Privation of any member or joint: The term ‘member’ 
means an organ or a limb being part of man capable of 
performing a distinct function. It includes eyes, ears, nose, 
mouth, hands, feet, etc. If the joint becomes permanently stiff, 
so that normal function is not possible, it is grievous injury. 
(5) Destruction or permanent impairing of the powers 
of any member or joint: In ordinary course of life, the use of 
limbs and joints of the body are very essential to the discharge 
ofthe normal functions of the body. Their deprivation causes 
lifelong crippling and makes the person defenceless and 
miserable. It causes great hardship to human body by its 
retention without normal function which is like amputation. 
Stricture due to burns, corrosives or any other injury, damage 
to tendons due to blunt or sharp force injury, leading to 
permanent impairment of powers of joints, muscles constitute 
grievous injury. 
(6) Permanent disfiguration of the head or face: The 
word ‘disfigure’ in this section means to cause some external 
injuries which detracts from his personal appearance, 
but does not weaken him, e.g., cutting off a man’s nose or 
ears. Branding a girl's cheeks which leaves permanent scars 
amounts to disfigurement. 
“A cut on the bridge of the nose of a girl caused by 
a sharp weapon like razor or knife has been held to be 
permanent disfigurement even though the internal wall 
separating the nostrils was intact’. 
(7) Fracture or dislocation of a bone or tooth (Fig. 
10.1): Fracture of either outer or inner table of the skull is 
considered a fracture. If a cut resulted only in a scratch or 
cut, and did not go deep to any length into the bone, it will 
not be fracture, otherwise it should be deemed to be one. ltis 
notnecessary thatabone should be cut through and through, 
or that there should be any displacement of any fragments of 
AB60]031x0] 
pue 
3UIDIP3 
ISUIL0A 
JO 
s|eiuUISS] 
3Y 
] 
S,Appay 
ueeseN 
Sy

Py 
o 
- 
(o] 
- 
s 
[ 
T 
c 
< 
@ 
& 
& 
© 
Y 
= 
L 
k) 
c 
(Y 
L 
(<] 
'8 
o 
o 
A 
c 
= 
c 
Y 
w 
v 
w 
Y 
£ 
= 
K 
b 
K} 
< 
Q 
& 
c 
@ 
) 
() 
T 
© 
P 
v 
x


# Cheatsheet — key facts

- [Unit to (R)FSL.] I-
30(a) label shall be bearing the Name, Age, Sex of deceased, Crime number, P.M.
- [Unit to (R)FSL.] I-30(d), pertaining to the case details, in charge constable 
carrying it, nature of sample and number of sample envelopes with relevant post 
mortem examination findings.
- [Unit to (R)FSL.] All request documents (Form – Medl I-30(d), case history 
& F.I.R.
- [section is available).] In Dead: 
10 cm shaft of femur from dead body, clavicles and permanent molars preserved in 
common salt; 
in absence of femur, any long bone in common salt.
- [section is available).] I-30(a) label – bearing the Name, Age, Sex of deceased, Crime 
number, P.M.
- [section is available).] I-30(d) pertaining to the case details, in charge constable 
carrying it, nature of sample and number of sample envelopes with relevant post 
mortem examination findings.
- [section is available).] All request documents (Form – Medl I-30(d), case history 
& F.I.R.
- [section is available).] I-30(a), all Label shall be bearing the Name, 
Age, Sex of deceased, Crime number, P.M.
- [section is available).] 60 
 
Legibly filled Form – Medl.
- [section is available).] I-30(d), pertaining to the case details, in charge constable 
carrying it, nature of sample and number of sample envelopes with relevant post 
mortem examination findings.
- [section is available).] All request documents (Form – Medl I-30(d), case history 
& F.I.R.
- [section is available).] Results are more useful if the cotton ball swabs are taken within 03 hours of death, 
between 03 to 06 hours results are less useful.
- [section is available).] Form – Medl I-30(b) is to be filled in duplicate; of which duplicate copy is to be 
acknowledged and returned back by Professor of Pathology.
- [section is available).] (Tamilnadu Medical Code – Para 272) 
 
70.
- [section is available).] Sample in culture medium for virus / 80 % glycerol in buffered saline can be sent to 
King’s Institute, Guindy, Chennai for virological examination.
- [section is available).] (Police Standing Order 151 A (2) (g)) 
Notification of District Health Authorities shall be made through Head of the Institution, 
in case of Notifiable diseases / Maternal deaths (S.
- [section is available).] 64 of Tamilnadu Public Health Act) 
  
72.
- [section is available).] For Medical Officers who got superannuation, the concerned Head of Department 
through the Head of Institution can communicate to the Medical Officer regarding her / 

63 
 
his pendency.
- [section is available).] (Para 263 – The Criminal Rules of Practice, 2019, High Court, Madras.) 
 
75.
- [section is available).] (Tamilnadu Medical Code – Para 630) 
 
76.
- [section is available).] (Tamilnadu Medical Code – Para 283).
- [section is available).] 65 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
DNA TESTING CASES 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 

66 
 
DNA TESTING CASES:  
1.
- [section is available).] (Model of Form I is in annexure) 
6.
- [section is available).] 39824 / 2020 / F1 / P.
- [section is available).] 92 / 2020; 28.12.2020;  
Tamilnadu, DGP – Circular memorandum No.
- [section is available).] Crime I / 181716 / 2011, dated: 09.08.2011) 
 
7.
- [section is available).] (Police Standing Order – 381 (B)) 
 
8.
- [section is available).] 69 
 
 
 
 
 
 
 
 
 
 
 
 
DRUNKENNESS CERTIFICATION 
 
 
 
 
 
 
 
 
 
 
 
 

70 
 
DRUNKENNESS CERTIFICATION:  
1.
- [section is available).] Scheme of examination for ascertaining drunkenness in an individual is to be done 
in the Proforma given in annexure (Medl I 66 C) to withstand legal scrutiny and be 
acceptable in Courts of Law.
- [section is available).] (Tamilnadu Medical Code, Para – 634) 
10 ml of blood from ante – cubital vein after cleaning the area and allowing it to air 
dry; Midstream Urine sample are sent.
- [section is available).] 100 mg of Sodium Fluoride + 20 mg of Potassium oxalate are added as preservative 
in a glass container; with label – Medl.
- [section is available).] I-30(a), sealing wax impression and sent 
through in charge Police constable.
- [section is available).] Ideally, collection of two samples of Blood & Urine in 30 minutes interval is 
scientifically more useful for interpretation of quantitative analysis & intoxication levels.
- [section is available).] (Tamilnadu Medical 
Code, Para – 635) 
 

71 
 
7.
- [section is available).] I-30(a), History & F.I.R.
- [section is available).] (Tamilnadu Medical Code – Para 636 & 427) 
But the above examination & certification is prohibited for homeopathic practitioners 
(Tamilnadu medical Code, Para - 637) 
 
10.
- [section is available).] (Tamilnadu 
Medical Code, Para – 639; Indian Railway Medical Manual, Section – G, Para 565 - 567).
- [section is available).] 72 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
EXPERT OPINION 
 
 
 
 
 
 
 
 
 
 
 
 

73 
 
EXPERT OPINION certificates:  
1.
- [section is available).] (Tamilnadu Medical Code, 
Para 624, 625) 
 
2.
- [section is available).] (Tamilnadu Medical Code, Para 652) 
 
 
3.
- [section is available).] 10053 / FW / D7 / D& E 
/ 2023; 8-1-25; HCP No.
- [section is available).] 2182 of 2022, High Court of Madras, Madras).
- [section is available).] Hospital shall give free treatment of child victims (penetrative sexual assault & sexual 
assault, under 18 years), rape survivors, vitriolage victims (G.O.
- [section is available).] Female adult victim can be examined with consent by doctor of any gender; 
In Child: 
< 18 years female victim shall be examined by female doctor(s) only; (S.
- [section is available).] 27 (2) of 
POCSO Act.)  
Medical Examination and forensic sample collection shall proceed irrespective of FIR 
filed / complaint filed.
- [section is available).] 10053 / FW / D7 / D& E / 2023; 8-1-25).
- [section is available).] 2182 of 2022, High Court of Madras, Madras).
- [section is available).] In victims, <12 years, parent / guardian can consent;  
For genital examination, invasive investigations, consent of individual > 18 years, 
consent of parents in < 18 years is mandatory.
- [section is available).] Informed Consent / Informed refusal needs to be sought separately for  
1.
- [section is available).] Examination; 2.
- [section is available).] Sample collection; 3.
- [Unit is under the headship of HOD of Forensic Medicine. Medico legal examination] 2182 of 2022, 
High Court of Madras, Madras)  
 
13.
- [Unit is under the headship of HOD of Forensic Medicine. Medico legal examination] (GO (Ms) No: 641, Health and Family Welfare Department; 
dated: 20.06.2013) 
 
15.
- [Unit is under the headship of HOD of Forensic Medicine. Medico legal examination] Certificate shall be issued with 07 days of 
examination.
- [Unit is under the headship of HOD of Forensic Medicine. Medico legal examination] 79 
 
Forensic Science Lab reports and other investigation reports once received shall be 
acknowledged back.
- [Unit is under the headship of HOD of Forensic Medicine. Medico legal examination] I-30(d) 
 
When a minor is brought / adult survivor is examined, information regrading MTP shall 
be communicated.
- [Unit is under the headship of HOD of Forensic Medicine. Medico legal examination] Sample preservation:  
Up to 10 weeks – rinse in saline, pack in rock salt;  
10 to 24 weeks – entire foetus in rock salt;  
> 24 weeks – right femur / whole lower limb in rock salt.
- [Unit is under the headship of HOD of Forensic Medicine. Medico legal examination] Temperature shall be maintained at 2 to 8
0 
C.
- [Unit is under the headship of HOD of Forensic Medicine. Medico legal examination] Specimen shall be forwarded within 24 hours of collection.
- [Unit is under the headship of HOD of Forensic Medicine. Medico legal examination] 2182 of 
2022, High Court of Madras, Madras)  
 
 
MISCELLANEOUS SITUATIONS: 
1.

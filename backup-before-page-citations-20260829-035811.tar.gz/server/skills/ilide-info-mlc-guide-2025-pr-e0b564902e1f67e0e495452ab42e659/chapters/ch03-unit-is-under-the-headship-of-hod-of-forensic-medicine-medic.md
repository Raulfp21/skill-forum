# Unit is under the headship of HOD of Forensic Medicine. Medico legal examination

## Introduction

Unit is under the headship of HOD of Forensic Medicine. Medico legal examination 
files are to be retained in Forensic Medicine Department. 
(TN Govt. Health & Family Welfare Department Letter.: 23935/ z1/ 2020-1; 14.10.2020; Director of Medical 
Education, Letter No: 43406/h d (II)/1/2018; 27.11.2020) 
Round the clock available specialists shall attend to the survivor immediately and other 
ancillary specialists to attend the survivor on call / or on their immediate next working 
time. Facts & findings of other specialists if needed can be sought for and certification 
done by the Forensic Medicine Department. 
Age estimation is not required, if there is enough documentary proof. (Refer under  
Age Estimation). 
 
In cases of victims received and treated at General Casualty / Emergency department, 
A.R. entry, intimation shall be followed as with any M.L.C., and the victim is to be 
admitted under One Stop Centre or in a separate ward in Paediatrics / OG / General 
Surgery (Male victim, above Pediatrics age group) and copy of A.R., intimation are 
attached in the case sheet (Treatment records are to be sent to M.R.D. at the time 
of discharge). 
 
10. All swabs and smears in the protocol shall be collected. 
 

78 
 
11. If 1% Toluidine blue is sprayed and excess is wiped out, Micro injuries will stand 
out in blue evidence are collected; 
Per speculum examination is not a must in case of children/young girls when there is 
no history of penetration and no visible injuries. 
Examination and treatment as needed may have to be performed under general 
anaesthesia in case of minors and when injuries inflicted are severe. If there is 
vaginal discharge, note its texture, colour, odour. 
 
12. Per vaginum examination commonly referred to by lay persons as two-finger test, 
must not be conducted / completely barred by Apex Court. Neither shall it be done, 
nor shall it be mentioned in AR register or elsewhere. 
Any person who conducts the two-finger test or per vaginal examination while 
examining a person alleged to have been subjected to Sexual assault is in 
contravention of Apex Courts directions and shall be guilty of misconduct.  
Instrument Colposcopy can be done to detect injury to hymen or to detect injuries or 
medical treatment. It shall not be done as a matter of routine. (HCP No. 2182 of 2022, 
High Court of Madras, Madras)  
 
13. Status of hymen is irrelevant because the hymen and an intact hymen does not 
rule out sexual violence and a torn hymen does not prove previous intercourse.  
Only those that are relevant to the episode of assault (findings such as fresh tears, 
bleeding, oedema etc.) are to be documented with respect to hymen. 
 
14. Copy of entire Proforma / preliminary certificate is to be given to the victim free 
of cost at the end of examination. (GO (Ms) No: 641, Health and Family Welfare Department; 
dated: 20.06.2013) 
 
15. Preliminary Certificate of Sexual Offence case examination (presenting themselves / 
Court direction) shall be prepared in Duplicate by the Medical Officer immediately after 
the examination; 
Original certificate should be sealed, forwarded to the Magistrate / Court concerned 
through the in-charge constable sent by Court on the same day; Duplicate – 
Department copy.  
 
16. If requisition is made by the Police Officer alone to examine the victim,  
Certificate shall be made in Triplicate, Original – Magistrate, Duplicate – Investigating 
Officer, Triplicate – Department copy. Certificate shall be issued with 07 days of 
examination. 
 
17. Ancillary Forensic Laboratory investigation samples are to be sent through in 
charge constable immediately. 

79 
 
Forensic Science Lab reports and other investigation reports once received shall be 
acknowledged back. 
18. Opinion shall be formed using the tables below and certificate shall be made 
ready as above.  
(Readiness of Final Opinion shall be communicated to the constable nominated by 
Court / Investigating Officer of the Case concerned I.O. through Out-Post / Nearest 
Police Station). 
Examined under Court direction – Certificate shall be prepared in Duplicate by the 
Medical Officer; 
Original certificate should be sealed, forwarded to the Magistrate / Court concerned, 
Duplicate – Department copy. 
Examined under Police memo / Police Intimation done by Medical Officer – Certificate 
shall be made in Triplicate, Original – Magistrate, Duplicate – Investigating Officer, 
Triplicate – Department copy. 
Copy to victim – shall be intimated to them through Institution concerned.  
 
20. Each Case file shall contain Request letter, History, FIR, duly filled Examination 
Proforma, Preliminary certificate copy, FSL report, Final Opinion certificate copy. It is be 
maintained at the Department.  
PENILE PENETRATION:  
Genital 
injuries  
Physical 
injuries  
FSL report  Final opinion 
Present Present Positive for semen Signs suggestive of forceful vaginal / 
anal intercourse  
Present Absent  Positive for semen Signs suggestive of forceful vaginal / 
anal intercourse 
Absent  Present  Positive for semen Signs suggestive of forceful vaginal / 
anal intercourse 
Absent  Absent  Positive for semen Signs suggestive of vaginal / anal 
intercourse 
Absent  Absent Positive for drug / 
alcohol / semen  
Signs suggestive of forceful vaginal / 
anal intercourse under drug / alcohol 
influence 
Absent  Absent Negative No signs of force / penetration;  
however nature of complaint cannot be 
completely ruled out by medical means.  
 
NON – PENILE PENETRATION:  
Genital 
injuries  
Physical 
injuries  
FSL report  Final opinion 
Present Present Negative for semen / 
alcohol / drug / lubricant 
No signs suggestive of vaginal / anal 
intercourse but there is evidence of physical 
and genital assault  
Present Absent  Negative for semen / 
alcohol / drug / lubricant 
No signs suggestive of vaginal / anal 
intercourse but there is evidence of genital 
assault   
Absent  Present  Negative for semen / 
alcohol / drug / lubricant 
No signs suggestive of vaginal / anal 
intercourse but there is evidence of physical 
assault   

80 
 
Absent  Absent  Negative for semen / 
alcohol / drug / lubricant 
No signs suggestive of forceful vaginal / anal 
intercourse 
Absent  Absent Positive for presence of 
lubricant only 
Possibility of vaginal / anal penetration by 
lubricated object 
 
NON – PENETRATIVE ASSAULT:  
Bite marks present and or 
FSL detects salivary stains  
Signs suggestive of evidence of bite mark(s) on 
....................... site; Age of injury is ....................... 
Sucking mark (discoid, subcutaneous 
extravasation of blood, with or without bite 
marks) present and or FSL detects salivary 
stains 
Signs suggestive of sucking mark(s) on 
.................................. site;  
Age of injury is ................   
Forceful fondling, with presence of bruises or 
contusions with or without fingernail marks 
Signs suggestive of forceful physical injuries on 
...................... Site; Age of injury is ................... 
Only forceful kissing and FSL detects salivary 
stains 
Signs suggestive of salivary contact 
(which may be due to kissing) 
If the history suggests forced masturbation of 
the assailant by survivor and if there is 
evidence of seminal stains detected on the 
hands 
Signs suggestive on the survivor of seminal fluid 
contact (which may be due to masturbation) 
In case there are no signs of sucking, licking 
etc.. detected, but history suggests some form 
of assault 
It is still important to document a good history 
because the survivor may have had a bath or 
washed him / herself.  
 
21. Forwarding Samples to FSL:  
Samples are to be packed, labelled, sealed (Sample forwarding – FSL Section); 
Samples shall be forwarded with FSL Sample forwarding form – Medl. I-30(d) 
 
When a minor is brought / adult survivor is examined, information regrading MTP shall 
be communicated. When MTP is scheduled, Police shall be intimated the date of MTP, 
so that FTA cards (for victim’s DNA profile) can be obtained by Police from FSL, 
Chennai.  
 
Sample preservation:  
Up to 10 weeks – rinse in saline, pack in rock salt;  
10 to 24 weeks – entire foetus in rock salt;  
> 24 weeks – right femur / whole lower limb in rock salt.  
(Placenta Umbilical cord need not to be sent).  
Fill a thermocol box partially filled with ice + salt mixture. Place the Containers having 
sample in the centre of the mixture, add some more of the ice + salt mixture. 
Ensure the container is completely surrounded by the ice + salt mixture / dry ice. 
Temperature shall be maintained at 2 to 8
0 
C.  
 
Samples shall be handed over the Police, either the case has been filed and has FIR 
/ Police report. Specimen shall be forwarded within 24 hours of collection. It shall be 
intimated through Police outpost or nearby Police Station.  
 

81 
 
Sample discarding; 
When the whole product of conception / part of foetus is received and DNA extracted, 
the DNA profiling is done; extracted DNA is deep frozen, the profile is digitized and 
saved by FSL. If facility is available in the FSL, samples can be destroyed in the 
FSL itself. If no such facility is available, it can be handed over to the bio medical 
waste vendors who can thereafter destroy the same as per procedure.  
Samples shall not be returned back to Courts / Medical Institutions. (HCP No. 2182 of 
2022, High Court of Madras, Madras)  
 
 
MISCELLANEOUS SITUATIONS: 
1. For Proforma to examine female accused, female victim Proforma and labels can be 
used with required corrections;  
For Proforma to examine male victim, male accused Proforma and labels can be used 
with required corrections; 
2. Male victim can be examined by doctor of any gender. 
3. Female accused can be force examined only when examining doctor is also a 
female.  
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 

82 
 
 
 
 
 
 
 
 
 
 
 
 
 
SEXUALOFFENCE CASE – ACCUSED MALE EXAMNATION  
 
 
 
 
 
 
 
 
 
 
 

83 
 
SEXUAL OFFENCE CASE – ACCUSED MALE EXAMINATION: 
1. Medical Examination of an accused of rape or attempt to commit rape can be 
done on the request of Police Officer by a Registered Medical Practitioner in a 
Government run / Local body run institution (Casualty Medical Officer / Emergency 
Medical Officer); in absence of the above mentioned, any registered medical practitioner 
within 16-kilometre radius can do such examination – preservation of evidence is of 
prime importance. (S. 52 BNSS) 
If time of travel and such travel does not jeopardize the evidence collection, or for 
opinion on bodily wounds (as to age of wounds, manner of such examinations can be 
sent to the Professor of Forensic Medicine / Police Surgeon of the nearest Medical 
College / Medical College of the District. 
 
2. Examination of a person in Judicial custody / Jail – Requisition from Court shall be 
addressed to the Professor of Forensic Medicine / Police Surgeon of the nearest 
Government Medical College / Government Medical College of the District.  
Reception of requests and delegation of cases shall be done as mentioned in other 
cases. Chief Medical Officer of a Government Hospital can also entertain such 
requests; if a Forensic Medicine qualified Medical Officer is available in the hospital.  
 
3. Male Potency test need not be undertaken in a routine manner in all cases 
involving sexual offences.  
(1) If the accused person raises impotency as a defence, the burden of proof will be 
upon the accused person to prove that he is impotent. Only in such instances there 
is requirement for conducting the potency test.  
(2) The doctor must in rare cases adopt invasive methods to find if the man had 
consumed any pill or other medication and committed penetrative sexual violence where 
otherwise he is impotent. 
(3) Even in cases, as the semen may be traced in the victim or in her 
undergarments etc, it is enough if the blood sample of the offender is taken and the 
DNA is matched. It is not necessary to draw the semen from the accused person. 
(H.C.P.No.2182 of 2022, Madras High Court, Madras) 
 
4. “Informed Consent” should be obtained for medical examination and other procedures 
from the adult accused or from the parents or guardians, if the accused person has 
not attained age of giving a valid consent for medical examination. 
Written informed consent is sought from the accused person; 
Reasonable force may be examined while examination, if consent is not given, and 
there is reasonable ground to believe such examination would reveal evidences 
regarding crime. However, only a female medical officer / medical practitioner shall 
examine a female accused.  
Examination shall include - Name & address, brought by, age, marks of injury, 
evidence preserved, start & end time of examination, other particulars if any.  
Examination shall be done without delay, and the report shall be issued to 
investigating officer without any delay so as to forward it to the Magistrate.  

84 
 
5. Register for sexual offence cases, Case file (Request letter, History, FIR, Proforma 
in annexure, and Duplicate certificate) shall be kept in the Department. Proforma for 
examination and model certification are in annexure. 
6. Number of cases done daily is to be totalled and register closed daily.  
 
7. Ancillary Forensic Laboratory investigation samples (biological specimens) or the 
clothes shall be sent through in charge constable immediately. 
 
8. When the requisition is made by the Police Officer to examine the accused, 
Certificate shall be made in Triplicate. Original – Magistrate, Duplicate – Investigating 
Police Officer, Triplicate – Department copy. 
When the requisition is made by the Court, Preliminary Certificate of sexual offence 
case examination shall be prepared in duplicate by the Medical Officer immediately 
after the examination and the Original certificate shall be sealed, forwarded to the 
Magistrate / Court concerned through the in charge constable sent by Court on the 
same day; Duplicate shall be retained as Department copy. 
Police shall be advised to get copy of certificate through the Court.  
 
9. Forensic Science Lab reports and other investigation reports once received shall be 
acknowledged immediately.  
 
9. Opinion shall be formed using the tables below and certificate to Magistrates / Court 
shall be sealed and sent immediately. Copy of FSL report can be sent along. 
 
10. Readiness of Police certificate (if request for examination is given by Police alone) 
shall be intimated to the concerned I.O. through Out-Post / Nearest Police Station. 
 
11. Opinion may be: 
a. When the subject is potent and his penile washings show vaginal epithelium,   
Opinion may be – Possibility of performance of sexual intercourse i.e., of 
vaginal/anal/urethral/oral penetration by the male sex organ of the alleged 
accused............................... under reference cannot be excluded. 
 
b. When the subject is potent and the penile washings do not show any vaginal 
epithelium,  
Opinion may be – No definite opinion can be given as to whether the alleged 
accused ............................ in the case under reference had performed any recent sexual 
intercourse in the ordinary way and there is nothing to suspect about his potency. 
c. If the subject is impotent, as found out on clinical examination and investigations, 
Opinion may be – Alleged accused ......................... in the case under reference is 
incapable of performing sexual intercourse in the ordinary way due to ................................. 
(Temporary / Permanent cause). 

85 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 

86 
 
 
 
 
 
 
 
 
 
 
 
 
TOXICITY CERTIFICATE CASES 
 
 
 
 
 
 
 
 
 
 
 
 
 

87 
 
TOXICITY CERTIFICATE CASES:  
1. Substances seized and being investigated under NDPS / Prohibition statues of State 
would require certification as to the toxicity of the substances. 
 
2. Professor of Forensic Medicine / Police Surgeon of Government Medical College of 
the District shall receive request from Investigating Officer for Toxicity certification of a 
substance.  
(FSL report about nature of substances needs to be enclosed in it). 
 
 
3. Professor of Forensic Medicine / Police Surgeon shall issue a typed Toxicity 
Certificate (Model in annexure) under TN Prohibition Act (realize the fees for it 
prescribed by the Government through College Office or Treasury) / NDPS Act / 
COTPA Act / other statues as required by the Prosecting agency. 
 
 
4. Duplicate certificate to be retained in the department file. 
 
 
5. Due discussion with Casualty / Emergency Department or nearby Medical Institutions 
regarding any number(s) of persons admitted, treated or died during the concerned 
time would be useful for the case.  
 
 
 
 
 
 
 
 
 
 
 
 
 

88 
 
 
 
 
 
 
 
 
 
 
 
 
MISCELLANEOUS 
 
 
 
 
 
 
 
 
 
 
 
 

89 
 
MEDICAL BOARDS & NEGLIGENCE cases: 
1. Each Government Medical College shall form a Negligence Enquiry board under the 
chair of Professor of Forensic Medicine / Police Surgeon.  
If any complaint received or clarification opinion is sought by Police, the board shall 
be reconstituted by including Professors on concerned specialty.  
2. M.L..C related Medical boards on Court’s direction constituted by Head of Institutions 
are to include Professor of Forensic Medicine / Police Surgeon. In case of District 
hospitals the same can be done with due request to nearest Medical College to 
achieve more medico-legally sound solution. 
3. Medical boards on disability / physical fitness carrying out their periodic duty are not 
covered under this manual, unless the case fits the above circumstances.  
Medical negligence cases: 
Guidelines of the Supreme Court of India on handling of cases of medical negligence 
(Jacob Mathew v. State of Punjab and another – 2005 SCCL.COM 456. Criminal Appeal No. 144-145 of 2004 
decided by the Supreme Court on August 5, 2005): 
1. A simple lack of care, an error of judgment or an accident, even fatal, will not 
constitute culpable medical negligence. If the doctor had followed a practice acceptable 
to the medical profession at the relevant time, he or she cannot be held 
liable for negligence merely because a better alternative course or method of treatment 
was also available, or simply because a more skilled doctor would not have chosen to 
follow or resort to that practice. 
2. Professionals may certainly be held liable for negligence if they were not possessed 
of the requisite skill which they claimed, or if they did not exercise, with reasonable 
competence, the skill which they did possess. 
3. The word gross has not been used in Section 106 of BNS. However, as far as professionals 
are concerned, it is to be read into it so as to insist on proof of gross negligence 
for a finding of guilty. 
4. The maxim Res ipsa loquitur (Let the event speak for itself; no other evidence 
need be insisted) is only a rule of evidence. It might operate in the domain of civil 
law; but that by itself cannot be pressed into service for determining the liability for 
negligence within the domain of criminal law. It has only a limited application in trial 
on a charge of criminal negligence. 
5. Statutory Rules or executive instructions incorporating definite guidelines governing the 
prosecution of doctors need to be framed and issued by the State and Central 
governments in consultation with the Medical Council of India (MCI). Until this is done, 
private complaints must be accompanied by the credible opinion of another competent 
doctor supporting the charge of rashness or negligence. In the case of police 
prosecutions, such an opinion should preferably from a doctor in government 
service. 
6. Doctors accused of rashness or negligence may not be arrested simply because 
charges have been leveled against them; this may be done only if it is necessary for 
furthering the investigation, or for collecting evidence, or if the investigating officer fears 
that the accused will abscond 
 
Police shall conduct a preliminary inquiry, depending on the facts and circumstances of 
each case. It shall be done before registering complaint / FIR.  (Police Standing Order - 
551 - 6 (vi) (c)) 

90 
 
No private complaint to be entertained without prima facie opinion; Investigating Officer 
to obtain Medical opinion from Government doctor;  
Not to arrest doctors as routine, unless it is largely justified that not arresting would 
impede further investigation / evidence collection / unavailability of doctor & arrest is to 
be executed only after consultation with senior Police officials. 
Cases under S. 304 A IPC (106 BNS) filed after obtaining opinion from nearest 
Government Medical College specialist shall be taken by Deputy Superintendent of 
Police / Assistant Commissioner of Police & above.   
 
(GO (Ms) No 133, Health & Family Welfare Department, dated: 09.07.2002; G.O.(Ms) No.220 Health and 
Family Welfare (z1) Department, dated, 04.07.2008; Office of the Director General of Police / Head of Police Force, Tamil 
Nadu - C. No. 4923431/ Crime 4(3) /2023, dated: 21.06.2023; Office of the Director General of Police, Tamil Nadu 
Memo – Rc. No. 209008 / Con. IV (1) / 2006, 07.10.2006)  
 
Medical Boards for disability certification:  
Locomotor disability:  
a. Medical Superintendent or Chief Medical Officer or Civil Surgeon,  
b. Specialist in Physical Medicine and Rehabilitation (PMR), or a Specialist in 
Orthopaedics if specialist in PMR is not available,  
c. One specialist doctor as nominated by the Medical Superintendent or the Chief 
Medical Officer as per the condition of the person with disability.  
 
Visual Impairment:  
a. Medical Superintendent or Chief Medical Officer or Civil Surgeon or any other 
equivalent authority as notified the State Government;  
b. Ophthalmologist;  
c. Ophthalmologist / Optometrist* / Ophthalmic Assistant* (*4 years degree from 
recognized university);  
 
Hearing impairment and Speech & Language disability 
a. Medical Superintendent or Chief Medical Officer or Civil Surgeon or any other 
equivalent authority;  
b. ENT Specialist; 
c. Audiologist / Speech Language Pathologist / Audiometric Assistant (Should be BASLP 
or equivalent which is RCI recognised); 
d. In addition, in cases of Speech disability due to "Dysarthria" and "Apraxia of 
Speech" and Language Disability due to “Aphasia”, Neurologist / Paediatric Neurologist 
shall be included; 
e. In case of Speech Disability in the "Maxillofacial anomalies", Plastic Surgeon / Oral-
Maxillofacial Surgeon/Paediatric Surgeon shall be included in the Medical Board. 
 
Specific Learning Disability, Intellectual disability and Autism Spectrum Disorder;  
a. Medical Superintendent or Chief Medical Officer or Civil Surgeon or any other 
equivalent authority as notified by the State Government; 
b. Paediatrician or Paediatric Neurologist (where available) or Developmental 
Paediatrician (where available) or physician (if age >18 years)  
or MD Internal Medicine / Family Medicine for Autism Spectrum disorder;  
c. Psychiatrist or Child and Adolescent Psychiatrist (wherever available); 
d. Clinical or Rehabilitation Psychologist. 
 

91 
 
Mental illness;  
a. Medical Superintendent, or Chief Medical Officer, or Civil Surgeon or any other 
equivalent authority as notified by the State Government; 
b. Psychiatrist;  
c. Psychiatrist / Physician or RCI registered Clinical Psychologist / Rehab Psychologist / 
Psychiatric social worker (wherever required Psychological Assessment report from RCI 
registered Psychologist obtained in last three months). 
 
Chronic Neurological Conditions:  
The Medical Superintendent or Chief Medical Officer or Civil Surgeon or any other 
equivalent authority as notified by the State Government shall be the head of the 
certification authority with the following two other members:  
a. Paediatrician / Paediatric Neurologist for patients aged ≤18 yrs;  
b. Physician (Medicine specialist) / Neurologist for patients aged >18 yrs; Specialist in 
Physical Medicine and Rehabilitation (PMR) or in case of non-availability of PMR 
Specialist, a Specialist in Orthopaedics, for certifying locomotor disability component; 
c. Psychiatrist for mental illness due to chronic neurological conditions; 
d. Trained psychologist (RCI certified clinical or rehabilitation) 
A and B are mandatory and C and D will be coopted as the case may demand 
 
Blood disorder;  
(a) Chairperson - Chief District Medical Officer or the Chief Medical Officer or Medical 
Superintendent of the hospital; 
(b) Members - 
i. Treating doctor Haematologist (adult / paediatric) or General Medicine or Paediatrician 
or General physician or as the case may be and the availability of experts; 
ii. PMR expert or Orthopaedic surgeon, if required; 
iii. Other Specialists: In case of sequelae relating to visual abnormality, hearing 
problem, cerebral dysfunction, etc. In case of limitation of availability of any expert, 
which ever additional experts are available can be included; 
iv. End organ damage (if doubt or difficulty in assessment) then only if needed 
additional specialist may be included as per the discretion of chairperson. But undue 
delay or inconvenience to patient is to be avoided. 
 
Multiple disabilities;  
Standing medical board shall comprise of the following: - 
(a) The Medical Superintendent or Chief Medical Officer or Civil Surgeon or Plastic 
Surgeon or any other equivalent authority as notified by the State Government – 
Chairperson  
(b) Specialists required for assessing the individual disabilities as per the requirement 
of respective guidelines for Locomotor disability, Visual impairment, Hearing impairment, 
Disability associated with blood related disorders, Developmental disorders, Mental illness 
and Chronic Neurological Disorders 
 
In view of shortage of the specialist doctors resulting in huge pendency in disability 
assessment, the chairperson (Who compulsorily has to be a Government Doctor e.g. 
Chief Medical Officer or Civil Surgeon or as specified) of the disability assessment 
board may, if required, include private medical practitioner(s) (duly qualified in the 
respective medical domain) as a board member.  

92 
 
(Department of Empowerment of Persons with Disabilities - Rights of Persons with Disabilities Act, 2016 - 
Rules – Guidelines for assessing the extent of specified disabilities - S.O. 1338 (E), Dated: 12
th
 March 
2024)  
 
Investigation into cases concerning other departments -- 
The result of police investigation into cases connected with other 
Government departments should be communicated at once by the Investigating 
Officer to the local head of the department. (Police Standing Order – 579). 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 

93 
 
MEDICAL TERMINATION of PREGNANCY cases: 
Qualification: 
Medical Practitioner with degree or diploma in Obstetrics & Gynaecology; 
in a place recognised / approved by District level authority (Joint Director of Health 
Services); or 
Experience in the practice of gynaecology and obstetrics for a period of not less than 
three years (Prior to 1971);  
Medical practitioner who has completed six months of house surgery in gynaecology 
and obstetrics; or,  
experience at any hospital for a period of not less than one year in the practice of 
obstetrics and gynaecology; or 
has assisted a registered medical practitioner in the performance of twenty-five cases 
of medical termination of pregnancy of which at least five was done independently 
(terminations beyond twenty to twenty four weeks, this clause of experience or training 
prescribed shall not apply).  
Admission Register: 
Admission Register shall be maintained as per Form III of the MTP rules, containing 
Serial number, Date of Admission, Name of patient, Wife / Daughter of, Age, Religion, 
Address, Duration of pregnancy, Reason for termination, Date of termination of 
pregnancy, Date of discharge of patient, Result & Remarks;  
Name of Registered Medical Practitioner (s) by whom opinion is formed, Name of 
Registered Medical Practitioner by whom pregnancy is terminated. 
Number shall be allotted serially for each calendar year (01 / 2025, 02 / 2025..; 01 / 
2026, 02 / 2026 etc.) All case records (Case sheets, Operation theatre register, 
summary, any other document / register) shall mention only the assigned Serial 
number.  
It is a secret document, information contained as to name and other particulars shall 
not be disclosed to any person, except for departmental inquiry by Chief Secretary to 
Government, claiming damages / suit before District Judge, investigation into offence by 
jurisdictional Judicial Magistrate. When Intimation to Police regarding MTP for POCSO 
cases (Form in Annexure), identity details need not be mentioned. Upon Police arrival 
to the Hospital, details can be revealed orally to aid the investigation. (HCP No. 2182 of 
2022, High Court of Madras, Madras) 
 
Medical Practitioner can issue medical certificate for leave to the concerned employed 
woman. But her employer is not permitted to disclose the information to any other 
person.    
Consent for M.T.P. is to be obtained from the girl (>18 years), or parents / guardian 
(< 18 years & insane). However, examination can be done with consent of girl above 
12 years. Consent forms (Form C) for consent by self, consent by guardian is in the 
annexure.  
Gestation limit: 
Gestation age doesn’t exceed 20 weeks – (by One Medical Practitioner) 
Continuance of pregnancy would involve risk to life of pregnant woman or grave injury 
to mental or mental health; 

94 
 
There is substantial risk that if the child were born, it would suffer from any serious 
physical or mental abnormality; 
Failure of contraceptive method to prevent pregnancy / limit children by woman or 
partner; continuation of pregnancy may be presumed to cause grave injury to mental 
health of pregnant woman; 
Pregnancy is alleged by the pregnant woman to caused by rape, the anguish caused 
by pregnancy shall be presumed to constitute grave injury to mental health of pregnant 
woman;  
Gestation age doesn’t exceed 24 weeks – (Opinion from two Medical Practitioners) 
Continuance of pregnancy would involve risk to life of pregnant woman or grave injury 
to mental or mental health - Survivors of sexual assault or rape or incest; Minors; 
Change of marital status during the ongoing pregnancy (widowhood and divorce); 
Women with physical disabilities [major disability as per criteria laid down under the 
Rights of Persons with Disabilities Act, 2016; Mentally ill women including mental 
retardation; The foetal malformation that has substantial risk of being incompatible with 
life or if the child is born it may suffer from such physical or mental abnormalities to 
be seriously handicapped; and Women with pregnancy in humanitarian settings or 
disaster or emergency situations as may be declared by the Government; 
There is substantial risk that if the child were born, it would suffer from any serious 
physical or mental abnormality; 
Pregnancy is alleged by the pregnant woman to caused by rape, the anguish caused 
by pregnancy shall be presumed to constitute grave injury to mental health of pregnant 
woman.  
 
Medical board comprising of Dean / Medical Superintendent / Resident Medical Officer 
of the Tertiary Hospital; Head of the Department / Associate Professor, Obstetrics and 
Gynaecology Department of the Tertiary Hospital; Head of the Department / Associate 
Professor, Paediatrics / Neonatology Department of the Tertiary Hospital; Head of the 
Department / Associate Professor, Radiology / Sonology Department of the Tertiary 
Hospital; Head of the Department / Associate Professor, Cardiology / Paediatric 
Cardiology Department of the Tertiary Hospital; Head of the Department / Associate 
Professor, Neurology / Paediatric Neurology Department of the Tertiary Hospital; 
Psychiatrist Counsellor / Psychologist of the Tertiary Hospital; Medical Superintendent / 
Resident Medical Officer of the Tertiary Hospital; Associate Professor / Professor, Foetal 
Medicine / Genetics of the Tertiary Hospital (if available) in 32 Medical Colleges 
(District wise list in Annexure).  
Medical Board to examine the woman and her reports so as to provide its opinion 
with regard to termination of pregnancy or rejection of request for termination within 
three days from the date of receipt of such request and to ensure safe termination 
procedure along with appropriate counselling;  
Board is to decide continuation of pregnancy / to medically terminate it beyond 24 
weeks of gestation in case of foetal abnormality. (G.O.Ms. No.223, Health and Family Welfare 
(R2), 11th July 2023, Aani 26, Sobakiruthu, Thiruvalluvar Aandu-2054). 
Whenever, pregnancy exceeds 24 weeks of gestation, Medical Board shall examine & 
frame opinion without any delay and can get the opinion of District Legal Services 
Authority as to the legality of doing MTP in the concerned case and do MTP;  

95 
 
Aggrieved Victim / female can get copy of Medical Board’s opinion and file before 
High Court for directions.     
MTP can be done to save life of pregnant woman at any stage of pregnancy. 
Above are the only permissible situations for M.T.P., failing which the act amounts to 
criminal abortion. 
Opinion of Medical practitioner(s) shall be entered in Form I (Regulation 3) and kept 
in a sealed cover bearing the serial number assigned.  
For M.T.P. in rape survivors, Police intimation is necessary and to keep the product of 
conception rinsed in normal saline and kept in 0 to 4
0 
C ice box or entire foetus in 
common salt (for DNA) to be handed over to the Investigating Police Officer. (Detailed 
SOP under Sexual Offence Survivor Examination) 
Consent forms, Medical Practitioners opinion, case records shall be placed in an 
envelope for each case, mentioning only the assigned serial number and shall be kept 
in safe custody. Head of the Department shall intimate through Head of the Institution 
regarding weekly statement of cases to State Level Designated Authority. 
 
CHILD ABUSE cases: 
With due representation from Child Welfare Committee or after seeing a victim seeking 
treatment in a medical institution, a team of Paediatrics, Psychiatry & Psychology 
(Orthopaedics etc. If required) faculties are to be formed for assessing and treating the 
child;  
If needed, Professor of Forensic Medicine / Police Surgeon with Professors in 
Paediatrics, Psychiatry & Psychology shall be formed into a board to assess age and 
other medico legal reports. 
 
PRE CONCEPTION PRE NATAL DIAGNOSTIC TESTS Act: 
Pre conception / pre-natal diagnostic testing instruments / machines, Genetic testing 
clinic, laboratory, centres shall register & obtain approval from the concerned District 
authority (Joint Director of Health Services). (G.O. Ms. No. 308 Health and Family Welfare (R1) 
Department, dated: 24.12.2013)  
No person including the person conducting pre-natal diagnostic procedures shall 
communicate to the pregnant woman concerned or her relatives or any other person 
the sex of the foetus by words, signs or in any other manner or conduct such test 
to determine sex of foetus. 
No prenatal diagnostic tests shall be done except for detection of chromosomal 
abnormalities; genetic metabolic diseases; haemoglobinopathies; sex-linked genetic 
diseases; congenital anomalies; any other abnormalities or diseases as may be 
specified by the Government; shall be done except when age of the pregnant woman 
is above thirty-five years; pregnant woman has undergone of two or more spontaneous 
abortions or foetal loss; pregnant woman had been exposed to potentially teratogenic 
agents such as drugs, radiation, infection or chemicals; pregnant woman or her spouse 
has a family history of mental retardation (with intellectual disability) or physical 

96 
 
deformities such as, spasticity or any other genetic disease; (v) any other condition 
specified by the Government.  
 
PSYCHIATRY OPINION cases:  
1. Professor of Psychiatry in a Medical College shall receive letters from Court, to give 
opinion regarding Mental Capability / Mental Illness of a person with reference to 
Criminal / Civil cases. 
2. Psychiatrist at District level hospitals also can oblige such requests from Court.  
3. I.Q. calculation shall preferably be done by a Psychologist, attached to the same 
institution or nearest Government Institution. Period of observation needed shall be 
communicated to the Court. 
4. At the end of observation period of ten days, ‘Mental Capable’ certificate shall be 
given; 
Or, ‘Mental Illness’ – advice for follow up to nearest Medical College can be given.  
In cases of ‘Mental Illness’ – person to be kept in safe custody, recommendation to 
be communicated to the Board / Court for extension of admission time / admission to 
any other higher Mental Health Establishment as the case may be. 
5. The Police should furnish the medical officer to whom a mentally ill is sent for 
observation, with all available details as to his previous history and the alleged causes 
of his mental illness.  
Police Officer can bring in a person with mental illness who is found wandering in his 
limits to nearest Mental Health establishment and make arrangements to assess him / 
her within24 hours. (MHA, 2017) 
When required by a Magistrate, the Police shall obtain and furnish the information 
necessary for the compilation of a mentally ill person’s medical history sheet from 
Hospital authorities. (Para 88 – The Criminal Rules of Practice, 2019, High Court, Madras.) 
6. In case of a person with mental illness who is homeless or found wandering in 
the community, a First Information Report of a missing person shall be lodged at the 
concerned police station and the station house officer shall have a duty to trace the 
family of such person and inform the family about the whereabouts of the person. 
Thereafter, Medical Officer, in consultation with Police & Social Welfare department can 
arrange for Welfare homes / Caring homes and shift them accordingly. (S. 100 - MHA, 
2017) 
7. Every Police Officer may recapture any mentally ill, who escapes from an Institute 
of Mental Health provided that in the case of a lunatic not being a mentally ill 
criminal, the power to recapture shall be exercisable only for a period of one month 
from the date of escape. In cases where the accused who has been a mental patient 
is referred to the Court for trial after treatment, the Court shall supply a copy of the 
final order or judgment free of cost to the hospital concerned. (Para 88 – The Criminal 
Rules of Practice, 2019, High Court, Madras.) 
8. When required by the Head / Superintendent of the Institute of Mental Health, the 
Police shall take such steps as are necessary to bring to this Institute, a mentally ill 
patient temporarily discharged there from, who is not produced before the Head / 
Superintendent of the Institute whenever he is required to be produced or on the date 

97 
 
of the termination of the period of the temporary discharge. (Police Standing Order – 384 
(6,7,8)).  
9. Admissions to Mental Health establishments can be requested as 
Independent patient admission - admitted by Mental Health Professional or Medical 
Officer or Psychiatrist;  
supported admission by a Nominated representative up to 30 days – admitted upon 
independent examination of two psychiatrists or one psychiatrist & one mental health 
professional or one psychiatrist & one medical practitioner,  
when a minor – intimate within 72 hours, when he turns major – assess within 24 
hours for being independent admission or supported one,  
woman is admitted – a woman attendant is mandatory for woman in patients, all 
admissions – intimate the board within 07 days,  
Mental health care professional shall review capacity of consent of the mentally ill 
once in every 07 days);  
supported admission by a nominated representative beyond 30 days (extend up to 90, 
120 first instance, 180 days every time) – admitted on independent examination of two 
psychiatrists, review for capacity to consent of the mentally ill once fortnight;  
intimate within 07 days to the Board;  
Recommendation from Court / Magistrate / Police / Board, 
referral from other State run Mental health establishment / custodial homes (beggar 
homes, orphanages etc), 
under Prisoners Act, Armed forces act.  
10. Treatment shall be decided on Advance Directives, if any registered at Board by a 
mental ill person during lucid interval. When Advance Directive registered is not given 
as a copy or in life saving emergency or persons under custody, treating doctor shall 
adhere to his / her treatment protocol.  
 
11. For certification requiring Intellectual disability, Specific Learning disability, Autism 
spectrum disorder, Speech & Language disability Mental illness; 
Board – Medical Superintendent, Psychiatrist, Psychologist, Development neurologist, 
Paediatrician can issue certificates. Form VII (Certificate of Disability) shall be used. 
Within One month – reply with certificate / reject;  
For Persons with Mental illness along with Intellectual disability, Multiple Disability Form 
can also be used. 
 
 
 
 
 
 
 
 

98 
 
SUMMONS: 
1. Issuance: 
Summons issued to witness (Form – 33 of Criminal Procedure Code) shall ordinarily be 
signed by the Head Ministerial Officer of the Court. The words “//By order of the 
Court//” shall invariably be prefixed to the signature of the Head Ministerial Officer in 
such cases.  
 
2. Details in Summons: 
Medical Officer shall at once check for the date, time and place in which the case to 
which it relates, / will be heard. Prefix Thiru. / Tmt. / Selvi. / Thirunangai. / 
Thirunambi as the case may be, with name of the person (Medical Officer) 
summonsed. (Para – 29 (5) The Criminal Rules of Practice, 2019, High Court, Madras.) 
The particulars of the person examined by the Doctor, the date on which he appeared 
at the hospital and the number of the Wound Certificate, Accident Register or Post-
mortem Certificate, as the case may be, shall be mentioned, whenever possible, in the 
summons to medical witnesses (Para – 29 (9) The Criminal Rules of Practice, 2019, High Court, 
Madras.) 
 
3. Summons reception: 
Summons server shall make endorsement / entry in ‘Summons Register’ maintained at 
Office of Dean / Chief Medical Officer (Head of the Institution) as the case may be 
and serve it to the Medical Officer concerned directly. All Summons shall be received 
in Duplicate (Two copies), one shall be duly acknowledged by the Medical Officer, 
including honorary medical officers (Tamilnadu Medical Code, Para – 859) 
(Name, designation, time & date with seal) and returned through the summons server.  
Where witnesses in Railway Police cases reside outside the limits of the Railway 
Police Station, arrangements should be made to have the summons served through the 
concerned Police Station in whose limits the witnesses reside. 
 
Summons reception should be immediately communicated to Head of Department for 
alternate arrangements in the Department. Letter regarding the same shall be 
communicated to the administration. (Police Standing Order – 454 (c)) 
 
4. Summons can be issued to Head of Department / Institution, for it to be duly 
handed over to the concerned Medical Officer, if he / she is on leave / suspension / 
absent from their working station 
The Court may issue summons to official witnesses through Heads of Departments in 
cases where their present address is not definitely known. The Court may, in such 
cases, issue a duplicate copy of the summons also direct to the witness either 
through post or through electronic communication or through the police in the address 
shown in the final report or complaint.  
 
5. In the same way, Summons can be given to one family member or pasted on 
house wall of a witness, if he / she is not readily available. 
 
 
6. When witness summons is issued to a Medical Witness and other expert, a 
convenient date is be fixed to avoid unnecessary postponement of their examination. If 

99 
 
more than one Medical Officer of the same hospital is cited as a witness in a case, 
only one may, as far as possible, be summoned at a time. If possible, it may be 
previously ascertained from the Medical Officer, what time would best fit in with his 
professional duties. 
A medical witness could be summoned only when the presence of accused is certain 
and when there is no likelihood of the case being adjourned for any other reason. 
Presiding Officer of the Court should see, that the time fixed for the examination of 
Medical Officers is adhered to and that the absence of the Medical Officer from his 
duties is as brief as possible. (Para – 29 (7) The Criminal Rules of Practice, 2019, High Court, 
Madras; Tamilnadu Medical Code, Para - 860) 
If summons is issued for same date to many Medical Officers of the same 
Department, Medical Officer who receives summons later can communicate the matter 
to the Presiding Officer of Court and request for another date and time of appearance. 
This is to ensure patient care and continued functioning of the department routine. 
 
Evidence through video conferencing:  
Application: 
Any party to the proceeding or witness, except in suo-motu direction by Court, may 
move a petition / application for examination of a witness through video conferencing. 
In all cases, except suo-motu direction, the petition/application must be supported by an 
affidavit, as prescribed in the Schedule, and must contain, among others, averments on 
following aspects; (a) Reasons for inability of the witness to appear before the Court. 
(b) That the cost of video conferencing shall be borne by the party applying for video 
conferencing;  
On receipt of the application and upon hearing both sides, the Judge, for reasons to 
be recorded in writing, that the attendance of the witness in person will cause 
inordinate delay and expenses, and that, it is expedient in the interest of justice to 
allow recording of evidence through video conferencing, may allow the prayer, specifying 
the cost to be borne by the party, if any. 
When summons are issued to a witness, proposed to be examined through video 
conferencing, the summons must mention in specific the date, time and venue of the 
video conferencing centre directing the witness to attend in person at the centre along 
with identification affidavit. The existing rules regarding service of summons and the 
consequences for non-attendance, as provided in the Code, shall apply with respect to 
service of summons.  
Procedure: 
The identity of the person to be examined shall be confirmed by the court with the 
assistance of the co-ordinator at Remote Point, at the time of recording of the 
evidence; 
Before a party to proceedings/witness is examined through video conferencing, he/she 
has to file a proof of identity, as mentioned in the Schedule, or if he/she is not in 
possession of an identity proof, as mentioned in the Schedule, he/she shall file an 
affidavit or an undertaking duly verified before Authorities mentioned in Section 139 of 
Civil Procedure Code (CPC) / Section 297 of Criminal Procedure Code (Cr. PC) / 333 

100 
 
of BNSS that the person, who is shown as the party to proceedings / witness, is the 
same person, who is going to depose on the screen. A copy of identity proof is to 
be made available to the other side. 
In civil cases, party requesting for recording statement of the person to be examined 
through video conferencing, shall confirm to the court, location of the person, his 
willingness to be examined through video conferencing, time, place and facility of such 
video conferencing. 
In criminal cases, where the person to be examined is a prosecution witness or court 
witness, the prosecution and where person to be examined is a defense witness, the 
defense counsel will confirm to the court his location, willingness to be examined by 
video conferencing, time, place and facility of such video conferencing. 
Video conference shall ordinarily take place during the court hours. However, the Court 
may pass suitable directions with regard to timings of the video conferencing as the 
circumstances may dictate. 
Signing the document: 
The record of proceedings including transcription of statement shall be prepared at the 
Court Point under the supervision of the court and accordingly authenticated. The soft 
copy of the transcript, digitally signed by the co-ordinator at the Court Point shall be 
sent by e-mail through NIC or any other Service Provider (owned by State/Central) to 
the Remote Point, where printout of the same will be taken and signed by the 
deponent. A scanned copy of the statement digitally signed by the co-ordinator at the 
Remote Point would be sent by e-mail through NIC or any other Indian service 
provider to the Court Point The hard copy would also be sent subsequently, preferably 
within three days of recording, by the co-ordinator at the Remote Point to the Court 
Point by courier / post. (Madras High Court Video Conferencing Rules, 2018 - R.o.c. No. 7062A / 
2018 / Comp4 / VC) 
 
7. Summons while transfer:  
Medical Officer on transfer order, can intimate the Directorate through the Head of 
Institution, regarding the summons date and date of relieving can be regulated after 
the summons date Court duty. (Tamilnadu Medical Code, Para – 861) 
 
8. When a Summons is communicated to Head of Department / Institute, for a Medical 
Officer who got transferred / relieved; details of communication address / present 
working station of the Medical Officer shall be communicated to concerned Court in 
the summons itself / through a separate communication. Summon may be issued to 
the Medical Officer concerned through the concerned Directorate. (Tamilnadu Medical Code, 
Para 859) 
 
9. Documents mandated by Court: 
In case of document producing (Ducis Tecum) summons, the concerned Head of 
Institution / Department Head can nominate the Head of Office under whose custody 
(one technician / records clerk) the document is maintained to submit it in the Court 
of Law. Order of authorisation shall be given to the concerned. (Tamilnadu Medical Code, 
Para – 863).  
Exceptions are given to documents from unpublished official records related to affairs of 
State; communications made through Official correspondence, objection to use as 
evidence, which is to be decided by Court concerned (S. 123, 124, 162 of Indian Evidence 

101 
 
Act / S. 129 130, 165 of BSA - Tamilnadu Medical Code, Para – 863)  
Unless the Court requires original document, which is given in writing with reason, 
Department Head shall send a true copy duly certified prescribed in the manner by


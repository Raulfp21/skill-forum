# Section 76 of the Evidence Act, 1872 / Section 75 of BSA (duly signed, marked as

## Introduction

Section 76 of the Evidence Act, 1872 / Section 75 of BSA (duly signed, marked as 
true copy and sealed, sent). (Para – 30 (2) The Criminal Rules of Practice, 2019, High Court, 
Madras.) 
 
If Court summons for the production of public records or other documents, in Original, 
if it thinks it necessary to meet the ends of justice to do so after recording the 
reasons; 
Original document shall be copied for department records and Original shall be sent. 
 
10. Medical Officer shall take the documents related to the case after entering in the 
‘Document lending register’ (contains no. Of pages in the document, date of lending, 
date of summons, date of return) in the Department / M.R.D. Register and it shall be 
periodically verified by the Head of Department / in charge.  
 
11. On the day of summons, all relevant documents of the case shall be taken along 
to attend the Court / Summonsing Officer (Investigating Officer can summons a 
witness).  
Doctor can visit the Public Prosecutor in his / her chamber to discuss about the 
case. 
 
12. High Court of Judicature at Madras has issued circulars that wearing over coats 
while disposing witness is not necessary for Medical Experts; (Registrar, High Court of 
Madras – R.O.C. No. 1511 / 95 – F1; dated: 07.09.1995).  
13. But it is prudent for the Doctor to wear overcoat for easy identification in a busy 
Court room. 
 
14. Doctor shall confine himself / herself to the case concerned, no undue talking to 
others / lawyers.  
He / She may sit (beside the Presiding Officer) in the Court Hall.  
Presiding Officer may require an expert witness to sit or stand while recording her / 
his testimony  
(Para – 46 The Criminal Rules of Practice, 2019, High Court, Madras.) 
 
15. If Court warrants Original document, when a Medical Officer is in Court, certified 
copy and due acknowledgement would be given by Court for record keeping.  
Or Court thinks, it is necessary to retain the original, shall direct a photocopy to be 
made by the Copyist Department of the Court and after certifying the photocopy to be 
a true copy of the original, return the original to the person who has produced, under 
due acknowledgment in Judicial Form No.57 – time (Para – 30 (5) The Criminal Rules of 
Practice, 2019, High Court, Madras.)  
 
12. Medical Officer receiving Summons for cases done in her / his old station, can 
avail Court Duty for Document Collection, Witness giving, Document return and travel. 

102 
 
Court shall grant ‘Attendance Certificate’ to witness, the certificate shall mention that he 
/ she  appeared for giving evidence in his official capacity (in Judicial Form No.59), 
date on which the witness appeared, duration of the period for which he / she was 
detained, so as to enable her / him to draw travelling allowance and the batta under 
the relevant rules. The acknowledgments for giving such certificates shall be obtained 
in Administrative Form No.27 (Criminal Register No.27)  
(Para – 276 (2) of The Criminal Rules of Practice, 2019, High Court, Madras) 
 
13. Medical Officer attending Court from the same station can avail Court duty on that 
day – on duty; in situations where witnessing in a case is being continued for the 
next day or so, Attendance Certificate shall be submitted for all days.  
Medical Officer attending Court to out station can avail Court duty for Document 
collection, Witness giving and travel time as per norms; in situations where witnessing 
in a case is being continued for the next day or so, Attendance Certificate shall be 
submitted for concerned days. 
(Para 96 (3) of Tamilnadu Travelling Allowance Rules) 
Sanction of the Government is not necessary to a journey of an officer who is 
summonsed to a place outside the State by a Court of law to give evidence in his 
official capacity.  
(Para 60, Rulings (2) of Tamilnadu Travelling Allowance Rules).  
On return to duty, communication to the Administration with Attendance Certificate from 
Court / Summonsing Officer and application for eligible allowances shall be done by 
the Medical officer as per norms. 
Necessary entries shall be done in ‘Document Lending Register’, regarding return of 
documents, pages submitted to Court etc. And verified by the Head of Department / 
Documents in-charge Officer.  
 
14. Refusal of Expert Testimony: 
Govt. Medical Officer shall refuse to give expert opinion unless summonsed by Court, 
if he / she is not professionally engaged in that case (in all criminal cases, in civil 
cases where Government is other party).  
If in the above situation, he / she is summonsed, immediate communication shall be 
made by the Medical Officer to the Directorate of Medical Education & Research, 
District Magistrate of the District in which the Court is situated and to the 
Commissioner of Police in Metropolitan cities. (Tamilnadu Medical Code, Para 653) 
 
15. If the Medical Officer gives Expert Opinion in any criminal case or civil case in 
which Govt. Is a party, where he / she has not been summoned at the instance of 
State, Medical Officer shall communicate to the Directorate of Medical Education & 
Research about all fees, remunerations he / she received. (Tamilnadu Medical Code, Para 
653) 
 
16. T.A / D.A on Government/Private Cases: 
a. TA/DA will be paid as per Govt. Rules by the Court / party. 
In criminal cases, doctor is given a certificate of Court attendance which enables her / 
him to draw her / his Travelling and Daily Allowance through her / his institution. In 
case where the doctor is not granted TA/DA by the institution, then the same may be 
brought to the notice of Court and granted by the Court. 
(within the radius of 08 kilometers distance from place of work, travelling expense incurred to be borne 
by the Court – P 276 (3) of The Criminal Rules of Practice, 2019, High Court, Madras.;  

103 
 
more than eighth kilometres distance are to be claimed as per Tamilnadu Travelling Allowances Rules).  
b. In civil cases, a fee called ‘Conduct Money’ shall be paid or assured to be 
paid when the summons is delivered. Summons of a Court should always be obeyed 
as first priority. Doctor shall honor the summons irrespective of the fees and bring it 
to the notice of the Presiding Officer of the Court in case of default fees. 
 
17. On recall witness summons, the same is communicated to the administration and 
Court, and ask for the recalling party to bear the expenses. When a witness is 
recalled, the Court shall furnish her / him, her / his deposition recorded earlier for her 
/ him to refresh her / his memory, before her / his examination-in-chief/cross 
examination. 
 
18. If a Medical Officer is summonsed at the instance of a private party / person (not 
at the instance of State / Court), it falls under his / her private practice. Medical 
Officer shall receive fee and remuneration from the party / person. Amount shall be 
communicated to the Government, and the Government can decide on recovering such 
amount reasonable for absence of officer’s time from duty. (Tamilnadu Medical Code, Para 
654) 
 
19. In such situations, Medical Officer is entitled to avail her / his eligible casual leave 
but shall not claim ‘on duty’. (Tamilnadu Medical Code, Para 653) 
 
20. Honorary Medical Officers, when attending the Court to give evidence in their 
official capacity, shall be paid allowances at the rates admissible to the Government 
servants of similar grades under the relevant rules applicable to them.  
Medical Officers and sub ordinates, whose services are lent by the Government to the 
local bodies, attends the Court to give evidence in their official capacity and not either 
in their private capacity or in prosecution instituted by the local body, they shall be 
paid eligible allowances from the State funds at the same rates as would be 
admissible to Government servants of similar grades under the Rules applicable to 
them.  
 
21. Copy of Judgments:  
Professor of Forensic Medicine / Police Surgeon can obtain judgments from the Court 
websites regarding the cases, the Department Medical Officers are professionally 
engaged with. Or he / she can request the same from the Courts concerned.  
 
21. Where, in a judgment or order, a Court impugns the character or conduct of a 
public servant, the Court shall forward a copy of the judgment or order to the Head 
of the Department or the immediate superior of the public servant concerned.  
In a case where a public servant / Government Official is charged with a criminal 
offence, a copy of the judgment or order shall be furnished by the Court to the Head 
of the Department concerned, free of charge. 
(Para 84, 85 – The Criminal Rules of Practice, 2019, High Court, Madras.) 
 
 
 
 

104 
 
SUMMONS – Civil Procedure Code:  
 
1. Every summons shall be signed by the Judge or such officer as he appoints, and 
shall be sealed with the seal of the Court (Code of Civil Procedure, Order V, Service of 
Summons, r. 1 (3)).  
Service shall in all cases be made a sufficient time before the time specified in the 
summons for the attendance of the person summoned, to allow him a reasonable time 
for preparation and for travelling to the place .at which his attendance is required 
(Code of Civil Procedure, Order XVI, Summoning and Attendance of Witnesses, r. 9). 
 
2. Delivery of summons by Court:  
Every summons for the attendance of a person to give evidence or to produce 
document shall specify the time and place at which he is required to attend, and also 
whether his attendance is required for the purpose of giving evidence or to produce a 
document or for both purposes. 
or any particular document, which the person summoned is called on to produce shall 
be described in the summons with reasonable accuracy. (Code of Civil Procedure, Order XVI, 
Summoning and Attendance of Witnesses, r. 5). 
Within the jurisdiction of the Court, summons shall  be delivered or sent either to the 
proper officer (Officer may be an officer of a Court), to be served by him or one of 
his subordinates or to such courier services as are approved by the Court;  
Post by registered post acknowledgment due, or by speed post or by such courier 
services as are approved by the High Court;  
any other means of document transmission (fax, electronic mail service) (Code of Civil 
Procedure, Order V, Service of Summons, r. 9). 
 
Where the serving officer delivers or tenders a copy of the summons to the defendant 
personally, or to an agent or other person on his behalf, he shall require the 
signature of the person to whom the copy is so delivered or tendered to an 
acknowledgment of service endorsed on the original summons (Code of Civil Procedure, 
Order V, Issue and Service of Summons, r. 16). 
 
When an acknowledgment or any other receipt purporting to be signed by the 
defendant or his agent is received by the Court or postal article containing the 
summons is received back by the Court with an endorsement purporting to have been 
made by a postal employee or by any person authorised by the courier service to the 
effect that the defendant or his agent had refused to take delivery of the postal article 
containing the summons or had refused to accept the summons by any other means 
specified; when tendered or transmitted to him, the Court issuing the summons shall 
declare that the summons had been duly served. (Code of Civil Procedure, Order V, Issue 
and Service of Summons, r. 9). 
 
Court may, on the application of any party for the issue of a summons for the 
attendance of any person, permit such party to effect service of such summons on 
such person and shall, in such a case, deliver the summons to such party for 
service.  
The service of such summons shall be effected by or on behalf of such party by 
delivering or tendering to the witness personally a copy there of signed by the Judge 

105 
 
or such officer of the Court as he may appoint in this behalf and sealed with the 
seal of the Court (Serving Officer).  
If such summons, when tendered, is refused or if the person served refuses to sign 
and acknowledgement of service or for any reason such summons cannot be served 
personally, the Court shall, on the application of the party, re-issue such summons to 
be served by the Court in the same manner as a summons to a defendant. 
Where a summons is served by a party under this rule, the party shall not be 
required to pay the fees otherwise chargeable for the service of summons. (Code of Civil 
Procedure, Order V, Service of Summons, r. 7A). 
 
3. Delivery of summons within Jurisdiction of another Court: 
Summons may be sent by the Court by which it is issued,  
either by one of its officers,  
or by post or by such courier service (approved by the High Court), 
by fax message or by Electronic Mail service  
or by any other means (approved by the High Court) 
to any Court (not being the High Court) having jurisdiction in the place where the 
person resides / Court of Small Causes in Madras (Code of Civil Procedure, Order V, Service 
of Summons, r. 21, 22).  
Court to which a summons is sent, shall, upon receipt thereof, proceed as if it had 
been issued by such Court and shall then return the summons to the Court of issue, 
together with the record (if any) of its proceedings with regard thereto. (Code of Civil 
Procedure, Order V, Service of Summons, r. 23). 
Court may substitute for summons, a Letter signed by Judge such officer as he may 
appoint in this behalf containing all particulars required to be stated in a summons, it 
shall be treated in all aspects as a summons. (Code of Civil Procedure, Order V, Service of 
Summons, r. 30). 
 
4. Summons to produce document: Any person may be summoned to produce a 
document, without being summoned to give evidence; and any person summoned 
merely to produce a document shall be deemed to have complied with the summons 
if he causes such document to be produced instead of attending personally to produce 
the same. (Code of Civil Procedure, Order XVI, Summoning and Attendance of Witnesses, r. 6) 
Any person present in Court may be required by the Court to give evidence or to 
produce any document then and there in his possession or power. (Code of Civil 
Procedure, Order XVI, Summoning and Attendance of Witnesses, r. 7). 
 
5. Expenses of witness: Party applying for summons shall, before the summons is 
granted, pay into Court such money for travelling and other expense and one day’s 
attendance. 
In determining the amount payable, the Court may, in the case of any person 
summoned to give evidence as an expert, allow reasonable remuneration for the time 
occupied both in giving evidence and in performing any work of an expert character 
necessary for the case. (Code of Civil Procedure, Order XVI, Summoning and Attendance of 
Witnesses, r. 2 (1) (2)). 

106 
 
Sum so paid into Court shall be tendered to the person summoned, at the time of 
serving the summons, if it can be served personally. (Code of Civil Procedure, Order XVI, 
Summoning and Attendance of Witnesses, r. 3). 
Where the summons is served directly by the party on witness, expenses shall be 
paid to the witness by the party. (Code of Civil Procedure, Order XVI, Summoning and Attendance 
of Witnesses, r. 2 (4)). 
Court may discharge the person summoned without requiring him to give evidence; 
order such sum to be levied by attachment & sale of property or both, where it 
appears to Court the sum paid is not sufficient. (Code of Civil Procedure, Order XVI, 
Summoning and Attendance of Witnesses, r. 4 (1)).  
In the same way, Court may discharge the person summoned without requiring him to 
give evidence; order such sum to be levied by attachment & sale of property or both, 
where it appears to Court the sum paid is not sufficient, for expenses of witness 
detained more than one day. (Code of Civil Procedure, Order XVI, Summoning and Attendance of 
Witnesses, r. 4 (2)). 
 
6. No one shall be ordered to attend in person to give evidence unless he resides 
(a) within the local limits of the Court’s ordinary jurisdiction, or 
(b) without such limits but at a place less then (one hundred) or (where there is 
railway or steamer communication or other established public conveyance for five-sixths 
of the distance between the place where he resides and the place where the Court is 
situated) less than (five hundred kilometres) distance from the court-house; 
Provided that where transport by air is available between the two places mentioned in 
this rule and the witness is paid the fare by air, he may be ordered to attend in 
person. (Code of Civil Procedure, Order XVI, Summoning and Attendance of Witnesses, r. 19) 
 
7. When Summons is issued with directions from the Judge stating that expert witness 
sum shall be paid at the Court;  
Medical Officer shall honour the summon and depose accordingly.  
Expenses as above would be paid by the party directly.  
Medical Officer can bring to the notice of the Judge regarding insufficient sum, if any. 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 

107 
 
COURT EVIDENCE:  
 
The following points shall be observed while giving testimony: 
a) Assume a comfortable but dignified position in the witness box. 
b) Do not use complicated medical terms, use simple language e.g. say bleeding 
instead of hemorrhage etc. 
c) On the witness box, your duty is to answer the questions and not to lecture to 
the Court, or argue with opposition counsel. If a ‘Yes’ or ‘No’ is demanded and 
if an honest ‘Yes’ or ‘No’ cannot be stated, turn to the judge and give 
explanation when the answer is not likely to be understood in proper manner. The 
witness must tell the truth, the whole truth, and nothing but the truth. 
In answering questions, try always to be brief. If you can honestly and safely reply 
with a simple 
‘yes’, that is fine. If you are unclear what is being asked, ask for the question to be 
repeated. If you do 
not know the answer then say, ‘I do not know.’ This is not an admission of 
ignorance, but of honesty. 
d) Do not appear partial to the side which calls you as a witness. Stick to the facts 
and do not let your-self be led away into the realm of speculation. Maintain your 
composure. 
e) Do not admit that a certain author or a certain book is an authority on any 
subject, unless you are sure that you agree with every statement which the author 
makes. Whenever you read a passage from a reference book you should always insist 
to read the lines yourself and that too along with few lines preceding, the quoted 
lines and also the lines thereafter so that the proper meanings of the paragraph are 
understood. 
f) Do not bluff or make rash statements which cannot be supported. Often times the 
correct answer is ‘I do not know’, Do not hesitate in giving this answer. Medicine 
is a vast subject, and if a witness does not know answer to a particular question, he 
should say so at once, he should not go beyond the limits of his knowledge and 
experience. It is tempting, always, to try to assist the court wherever you can, but you 
are strongly advised to stick within your areas of knowledge. 
g) Doctor should be prompt and punctual in his attendance and not leave the Court 
without permission of the Presiding Officer. 
h) If a medical witness is accurately reporting the facts &findings, truthful, unbiased, 
composed, and is fair in all his opinions, her / his integrity and professional reputation 
will remain untarnished. 
 
 
 
 
 
 
 
 
 
 
 

108 
 
MEDICO LEGAL RECORDS: 
 
1. In Medical Colleges, case records from Casualty / Emergency Department and Wards 
shall be sent to Medical Records Department.  
Case Records of Forensic Medicine Department are kept in Record Room of Forensic 
Medicine Department itself. 
 
2. In other Medical Institutions, all case records shall be sent to Medical Records 
Department at the earliest. 
 
 
3. ‘Record Register’ shall be maintained that documents entry of records into the 
records room / record department. 
 
 
4. ‘Records lending & return register’ shall also be maintained. 
 
 
5. Records of a particular case can be lent by the Medical Officer concerned for 
completing pending certification (want of old treatment records etc.) or Final opinion 
(after Lab reports) / for attending Courts.  
 
 
6. Students can be permitted for research works to view medico legal records without 
jeopardizing Investigation process. Data from the records can be used for research and 
publication with due acceptance from Institution Ethics Committee, Institution Science 
Committee etc.  
 
 
7. Inspection by Elected representatives and others are entitled to visit the hospitals 
and records such as stock books, attendance book of the employees with the 
knowledge of Medical Officer in charge; entitlement doesn’t apply to records of 
professional character – Accident register, Wound register, Post Mortem certificate 
register, Case sheets, In and Out nominal register. 
 
 
8. All records / files related to medico legal cases / post-mortem cases are not open 
to any person including L.I.C, lawyers. All third parties can get the documents through 
Court / Investigating Officer of the case. 
 
 
9. Copy of Post Mortem report can be issued under RTI Act (Decision No. 
CIC/SG/A/2010/000775/10977 Appeal No. CIC/SG/A/2010/000775).  
However, Public Information Officer (PIO) can claim exemption u/s 8(1) (e) & (j) of the 
RTI Act if information pertaining to a victim / patient is sought by a third person / 
personal information is sought.  
 
 

109 
 
10. For records in M.R.D., warranted by Court – with letter addressed to R.M.O. / in 
charge of Medical Records, documents requested shall be sent after making a copy of 
all documents and retained in the Department. 
11. A.R. book / other records, if requested by Court, photocopy of office record shall 
be duly certified by Hospital Superintendent and sent to Court. If in special situations, 
Court warrants actual record, same shall be sent to Court. 
Court shall return it as early as practicable after making copy in its record. 
 
 
12. Copies of old A.R.s / certificate can be given to Investigating authorities, upon 
written request to RMO / in-charge of Medical records. 
 
 
13. For records in Forensic Medicine, warranted by Court – with letter addressed to 
Professor of Forensic Medicine / Police Surgeon, he / she shall send the documents 
requested after making a copy of all documents and the copy is to be retained in 
the Department. 
 
 
14. If a certificate / document is requested for second time, a letter duly forwarded by 
the Superintendent of Police / Deputy Superintendent of Police or Commissioner / 
Deputy Commissioner / Assistant Commissioner of Police is needed. 
 
15. Documents arising out of routine functioning or nature of work in a department 
shall be sent to Court without delay, once the document is requested for.  
 
 
16. Documents of confidential nature between the patient and doctor, documents from 
higher authorities not arising out of routine functioning or nature of work in a 
department can be claimed exemption and the same is communicated to Court.  
On further insistence, records have to be submitted to Court. 
 
 
17. All records sent are to be duly numbered and tagged; a covering letter stating the 
details, number of pages, and designation of forwarding authority is to be attached. 
 
 
18. Certificates, Formats sent for first time do not require a Covering letter, only the 
copies made as per directions of Court / request from I.O. requires a covering letter. 
 
 
19. Improper use of certificate by the receiving authority / others, if comes to the 
notice of the medical institutions, the same shall be communicated to the Directorate 
of Medical Education & Research / Public Health / DMRHS – ESI as the case may 
be through proper channel. Copy of the communication can be brought to the notice 
of District level officer of the concerned department through which the certificate was 
improperly used. Communications shall be in spirit of co-ordination & well usage but 
not of punitive nature.  
 

110 
 
20. Any communication from other departments with regards to improper opinion, lack of 
required medical knowledge in framing medical opinion, long pendency etc. in general, / 
in connection to a particular Medical Officer is to be immediately communicated to the 
Head of Institution and to the Directorate. 
 
 
21. For corrections with respect to Name, Age, S/o D/o etc. In hospital records, 
declaration from Notary Public / VAO is mandatory.  
When the corrections are sought in Post mortem certificates, Drunkenness certificates 
etc. Which were done on the details given by Police, a request letter for change / 
correction from Investigating Officer is mandatory. 
 
22. Retention time for DMER, DMS, DMS (ESI) & DPH: 
Medico legal inpatient Records and Death cases – 06 years;  
Master case sheets in specialty Hospitals if maintained according to their requirement – 
20 years;  
Scientific and Research Oriented inpatient records based on which case study and 
paper presentation made and other records which the Dean / Director / Superintendent 
of the Hospital desires to retain permanently – 20 years;  
In patient records of IMH, Chennai and Government institute of Rehabilitation Medicine, 
K. K. Nagar – 12 years;  
Pediatric Medico Legal inpatient records, death case records and Pediatric Scientific and 
Research oriented inpatient records in the ICH and Hospital for Children Chennai – 12 
years. 
Non Medico Legal inpatient records – 03 years (When the institution is not under 
CEA) 
(Govt. Letter. No. 58841 / E1 / 2005-5, dated:2.2.2009, Health and Family Welfare Department) 
 
Death register – 12 years; Accident Register – 12 years; Wound certificate booklet in 
counter foil – 12 years; Register showing intimation of accidents to Police – 01 year 
(Tamilnadu Medical Code, Para – 991) 
 
Medical Termination of Pregnancy Act – Unless directed by Chief Secretary to the 
Government, District Judge, Judicial Magistrate, Admission Register shall be destroyed 
after five years from the last entry; other records after three years of termination.  
Pre Conception Pre Natal Diagnostic Tests Act - All records, charts, forms, reports, 
consent letters and all other documents required to be maintained under this Act and 
the rules shall be preserved for a period of two years.  
Clinical Establishment Act - (HEALTH AND FAMILY WELFARE DEPARTMENT, TAMIL NADU 
CLINICAL ESTABLISHMENTS (REGULATIONS) RULES, 2018. - G.O. Ms. No. 206, Health and Family 
Welfare (Z2), 1st June 2018, Vaikasi 18, Vilambi, Thiruvalluvar Aandu – 2049) 
Medical case record shall be maintained for a period of not less than ten years in 
the form of a register in the clinical establishment in respect of each patient, which 
shall include the following particulars, namely: 
(i) a detailed daily statement of the patient’s health and condition;  
(Ii) details of any investigations made, surgical operations carried out and treatment 
given and  
(iii) records of all medical prescriptions, X-Ray reports, laboratory reports or any other 
report with full name, qualifications of the doctor.  

111 
 
(iv) in the case of a maternity home or a maternity case, the said person shall keep 
a case record of each child born to a patient. Full and detail record of pregnancy 
must be maintained for at least a period of ten years 
Medico Legal Cases - Every Hospital which treats medico legal cases in accordance 
with Government Order, all such records and registers pertaining to such cases shall 
be preserved as per the Government orders from time to time and police shall be 
intimated regarding their admission, discharge, death etc..  
A separate record shall be maintained in the form of a register, of all surgical 
operations, performed in the clinical establishment, which include, among others, the 
name of the medical practitioner who performed the operation and the name of the 
anaesthetist in attendance. All patients either discharged or referred to other Hospitals 
shall be given a discharge advice card / slip 
Mental Health Care Act Rules, 2018 
Every Mental Health Care Establishment shall maintain the following records permanently 
Basic Medical Record of all out patients;  
Basic Medical Record of all inpatients;  
Basic Psychological Assessment Report;  
Basic Therapy Session Note  
When application is made by a mentally ill person / from his nominated representative 
(Form A), copy of Basic Medical Records shall be given within 15 days in Form B of 
the MHCA Rules, 2018).  
Medical Officer may withhold specific information in the medical records, if disclosure 
would result in serious harm to the mentally ill or harm to others; however, the 
concerned application may be appealed & decided by Mental Health Review Board.  
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 

112 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
ANNEXURES 
 
 
 
 
 
 
 
 
 
 
 
 

113 
 
Accident Register   
Police Jurisdiction in Chennai & Coimbatore  
Intimation to Police / Magistrate  
Age of Wounds and S. 116 of BNS.   
Wound certificate 
Age case – Proforma 
Age case – Radiology request form  
Age case X ray findings form 
Age assessment scales & Certifying Surgeon limit 
Post mortem examination notes booklet 
FSL / RFSL jurisdiction & Serology sample jurisdiction  
Viscera in poisoning cases  
Viscera forwarding form – Toxicology  
Viscera forwarding label  
FSL – Sample forwarding form   
Viscera forwarding – Histopathology form  
Post mortem notes book in Custodial deaths 
Autopsy in Organ Transplant cases- Organ Retrieval Authorisation form 
Post Mortem Examination certificate – Format  
Medical Certificate for Cause of Death  
DNA Cases format (Form – I)  
Drunkenness Examination Proforma  
Drunkenness Examination certificate – Format  
Sexual Offence Accused Examination – Proforma  
Sexual Offence Victim Examination – Proforma  
Sexual Offence Accused Examination certificate – Format   
Sexual Offence Victim Examination certificate – Format 
Toxicity Certificate – Format 
Fitness for remand / Screening on admission to jail form 
 
 

114 
 
 (Medl.I-25) 
GOVERNMENT .............................. HOSPITAL, 
......................................... 
ACCIDENT REGISTER / WOUND REGISTER (Entry shall be made in Triplicate) 
Hospital No.........................................................  Date and time ................................................ 
 
Name...............................................................  Age ........................................................ 
Sex ..................................................................  Occupation............................................... 
Residence............................................................................................................................. 
....................................................................................................................................... 
Identification marks:     .............................................................. 
.............................................................. 
Brought by whom................................................................................................................. 
Police informed or not...... Declaration required or not .........  If yes, Magistrate Intimation ..................... 
 
History: (How, when, where & by whom) (mention, Helmet worn or not, in case of two wheeler accidents):  
................................................................................................................................................ 
 
........................................................................................................................................... 
 
........................................................................................................................................... 
 
General examination:.............................................................................................................. 
 
Injuries& Treatment:.................................................................................................................. 
 
........................................................................................................................................... 
 
........................................................................................................................................ 
 
........................................................................................................................................ 
 
......................................................................................................................................... 
 
Station   :       Signature of the Emergency / Casualty Medical Officer: 
Date    :       Name in Block letters, Registration number: 
ORIGINAL 
S.No: 

115 
 
 (Medl.I-25) 
GOVERNMENT .............................. HOSPITAL, 
......................................... 
ACCIDENT REGISTER / WOUND REGISTER (Entry shall be made in Triplicate) 
Hospital No.........................................................  Date and time ................................................ 
 
Name...............................................................  Age ........................................................ 
Sex ..................................................................  Occupation............................................... 
Residence............................................................................................................................. 
....................................................................................................................................... 
Identification marks:     .............................................................. 
.............................................................. 
Brought by whom................................................................................................................. 
Police informed or not...... Declaration required or not .........  If yes, Magistrate Intimation ..................... 
 
History: (How, when, where & by whom) (mention, Helmet worn or not, in case of two wheeler accidents):  
................................................................................................................................................ 
 
........................................................................................................................................... 
 
........................................................................................................................................... 
 
General examination:.............................................................................................................. 
 
Injuries& Treatment:.................................................................................................................. 
 
........................................................................................................................................... 
 
........................................................................................................................................ 
 
........................................................................................................................................ 
 
......................................................................................................................................... 
 
Station   :       Signature of the Emergency / Casualty Medical Officer: 
Date    :       Name in Block letters, Registration number: 
DUPLICATE 
S.No: 

116 
 
 (Medl.I-25) 
GOVERNMENT .............................. HOSPITAL, 
......................................... 
ACCIDENT REGISTER / WOUND REGISTER (Entry shall be made in Triplicate) 
Hospital No.........................................................  Date and time ................................................ 
 
Name...............................................................  Age ........................................................ 
Sex ..................................................................  Occupation............................................... 
Residence............................................................................................................................. 
....................................................................................................................................... 
Identification marks:     .............................................................. 
.............................................................. 
Brought by whom................................................................................................................. 
Police informed or not...... Declaration required or not .........  If yes, Magistrate Intimation ..................... 
 
History: (How, when, where & by whom) (mention, Helmet worn or not, in case of two wheeler accidents):  
................................................................................................................................................ 
 
........................................................................................................................................... 
 
........................................................................................................................................... 
 
General examination:.............................................................................................................. 
 
Injuries& Treatment:.................................................................................................................. 
 
........................................................................................................................................... 
 
........................................................................................................................................ 
 
........................................................................................................................................ 
 
......................................................................................................................................... 
 
Station   :       Signature of the Emergency / Casualty Medical Officer: 
Date    :       Name in Block letters, Registration number: 
TRIPLICATE 
S.No: 

117 
 
Police Jurisdictions:  
G.O. (Ms). No. 322, Health & Family Welfare Department (Z1), dated: 29.10.2015;  
G.O. (Ms). No. 390, Health & Family Welfare Department(Z1), dated: 15.12.2023. 
Chennai:  
Madras Medical College (1)  Stanley Medical College (2) Kilpauk Medical College (3) 
 
B1 North Beach  
C3 Seven Wells  
H1 Washermenpet 
H2 Stanley Medical College 
Hospital, Outpost  
H3 Tondiarpet 
H4 Korrukupet  
H5 New Washermenpet  
H6 R. K. Nagar  
H7 Peripheral Hospital, 
Tondiarpet 
M1 Harbour  
M2 Water Borne P.S.  
M5 Government RSRM 
Hospital  
N1 Royapuram  
N2 Kasimedu  
N3 Muthialpet  
N4 Fishing Harbour 
P3 Vyasarpadi  
N5 Government RSRM 
Hospital Outpost 
P5 Sharmanagar 
 
Govt. Medical College,       Government Royapettah    Government Med College,  
Omandurar Govt. Estate (4)       Hospital (5)     ESI, KK Nagar (6)  
 
 
 
 
F5 Chetpet 
G3 Kilpauk 
G5 Secretariat 
Colony  
G6 Kilpauk Medical 
College Hospital 
outpost 
K1 Sembium  
K2 Ayyanavaram  
K3 Aminjikarai  
K4 Anna Nagar 
K5 Peravallur  
K6 T. P. Chatram 
K7 ICF Colony  
K8 Arumbakkam  
P1 Pulianthope  
P2 Otteri  
R5 Choolaimedu  
V1 Villivakkam  
V2 Virugambakkam  
F3 Nungambakkam  
B2 Esplanade 
B3 Fort  
C1 Flower Bazaar 
C2 Elephant gate 
C4 G.H. Out Post 
C5 Kothavalchavadi 
F1 Chintadripet 
F2 Egmore 
F6 Egmore Museum 
F7 Women and Children 
Hospital 
G1 Vepery  
G2 Periamet 
G4 Institute of Mental 
Health 
P4 Basin Bridge    
D2 Annasalai  
D4 Zam Bazaar 
D6 Anna Square 
E3 Teynampet  
F4 Thousand Lights  
R6 Kumaran Nagar 
D1 Triplicane  
(D7 Government Estate 
Police Station merged 
with  
D1 Police Station) 
D8 Kasturibhai Gandhi 
Hospital 
 
D3 Ice House   
D5 Marina 
E1 Mylapore 
E2 Royapettah 
E4 Abhiramapuram 
E5 Foreshore Estate 
E6 Royapettah Hospital 
Outpost 
J1 Saidapet 
J3 Guindy 
J4 Kotturpuram 
J5 Shastri Nagar 
J6 Thiruvanmiyur 
J7 Velachery 
R7 K. K. Nagar 
R3 Ashok Nagar 
R2, Kodambakkam  
R4 S. P. Angadi  
R1 Mambalam 
R 10 MGR Nagar  
R 8 Vadapalani 

118 
 
Coimbatore:  
Coimbatore Medical College & Hospital:  
West Zone Mettupalayam Sub division  
B1 - Big Bazaar Street 
B2 - RS Puram  
B3 - Variety Hall Rd 
B4 - Ukkadam 
1. Mettupalayam PS 
2. Sirumugai PS 
3. Karamadai PS 
4. Annur PS 
5. Pillur PS 
Central Zone  Periyanaikenpalayam 
Subdivision 
C1 - Katoor  
C2 - Race course  
C3 - Saibaba Colony  
C4 - Rathinapuri 
1. PN Palayam PS 
2. Thadagam PS 
3. Thudiyalur PS 
 Perur Subdivision 
 1. Perur PS 
2. KG Chavadi PS 
3. Maddukkarai PS 
4. Thondamuthur PS 
5. Alandurai PS 
6. Karunyanagar PS 
7. Kinathukadavu PS 
8. Vadavelli PS 
Government Medical College & ESI Hospital:  
East Zone Pollachi Sub division  
E1 - Singanallur PS 
E2 - Peelamedu PS  
E3 - Saravanampatti  
1. Pollachi East PS 
2. Pollachi West PS 
3. Pollachi Taluk PS 
4. Mahalingapuram PS 
5. Vadakkipalayam PS 
6. Negamam PS 
7. Gommangalam PS 
South Zone  Valparai Subdivision 
D1 - Ramanthapuram 
D2 - Selvapuram PS  
D3 - Podanur PS 
D4 - Kuniamuthur PS 
1. Valparai PS 
2. Anaimalai PS 
3. Aliyur PS 
4. Kottur PS 
5. Kadamparai PS 
6. Mudis PS 
7. Shiekalmudi PS 
 KM Patty Subdivision 
 1. Karumathampatty PS 
2. Kovilapalayam PS 
3. Chettipalayam PS 
4. Sultanpet PS 
5. Sulur PS 

119 
 
(Medl.I-26) 
GOVERNMENT .............................. HOSPITAL, 
......................................... 
INTIMATION OF ACCIDENTS & INJURIES TO POLICE / MAGISTRATE  
(Entry shall be made in Triplicate) 
Hospital No.........................................................  Date and time ................................................ 
 
1. Name of the person      :        Age & Gender:  
2. Address     :  
 
3. Brought by       : 
 
4. Place at which injury or accident occurred     : 
 
5. Alleged cause     : 
 
6. Treatment        :      A.R. No:  
 
        OP No:    IP (Ward): 
            D.O.A:  
 
7. Whether dying declaration necessary   : 
 
8. Present status      :  Ward No (if admitted) -     Time of death –  
 
9. Telephone information received by     : 
  (if given) 
 
10. Time of dispatch of intimation to the 
  Police and Magistrate     : 
 
 
Station   :       Signature of the Emergency / Casualty Medical Officer: 
Date    :       Name in Block letters, Registration number: 
 
 
 
 
ORIGINAL 
S.No: 

120 
 
(Medl.I-26) 
GOVERNMENT .............................. HOSPITAL, 
......................................... 
INTIMATION OF ACCIDENTS & INJURIES TO POLICE / MAGISTRATE  
(Entry shall be made in Triplicate) 
Hospital No.........................................................  Date and time ................................................ 
 
1. Name of the person      :        Age & Gender:  
2. Address     :  
 
3. Brought by       : 
 
4. Place at which injury or accident occurred     : 
 
5. Alleged cause     : 
 
6. Treatment        :      A.R. No:  
 
        OP No:    IP (Ward): 
            D.O.A:  
 
7. Whether dying declaration necessary   : 
 
8. Present status      :  Ward No (if admitted) -     Time of death –  
 
9. Telephone information received by     : 
  (if given) 
 
10. Time of dispatch of intimation to the 
  Police and Magistrate     : 
 
 
Station   :       Signature of the Emergency / Casualty Medical Officer: 
Date    :       Name in Block letters, Registration number: 
 
 
 
 
DUPLICATE 
S.No: 

121 
 
(Medl.I-26) 
GOVERNMENT .............................. HOSPITAL, 
......................................... 
INTIMATION OF ACCIDENTS & INJURIES TO POLICE / MAGISTRATE  
(Entry shall be made in Triplicate) 
Hospital No.........................................................  Date and time ................................................ 
 
1. Name of the person      :        Age & Gender:  
2. Address     :  
 
3. Brought by       : 
 
4. Place at which injury or accident occurred     : 
 
5. Alleged cause     : 
 
6. Treatment        :      A.R. No:  
 
        OP No:    IP (Ward): 
            D.O.A:  
 
7. Whether dying declaration necessary   : 
 
8. Present status      :  Ward No (if admitted) -     Time of death –  
 
9. Telephone information received by     : 
  (if given) 
 
10. Time of dispatch of intimation to the 
  Police and Magistrate     : 
 
 
Station   :       Signature of the Emergency / Casualty Medical Officer: 
Date    :       Name in Block letters, Registration number: 
 
 
Form-J 
TRIPLICATE 
S.No: 

122 
 
INTIMATION TO POLICE  
ABOUT UNAUTHORIZED ABSENCE FROM MENTAL HEALTH ESTABLISHMENT  
[Rule 9, Mental Health Care Act, rules] 
 URGENT/FOR IMMEDIATE ACTION 
 
 
To 
The Station in-charge  
________ Police Station 
 _____________  
 
 
Madam / Sir, 
   Subject: - Intimation about unauthorized absence (without leave or discharge) 
of a 
   prisoner with mental illness.  
 
This is to inform you that Mr. /Mrs.       aged 
 years, son / daughter of Mr. /Mrs.     
with identification marks    1. 
     2.  
was admitted at our establishment, as a prisoner with mental illness under Section 103 of 
Mental Health Care Act, 2017 (10 of 2017), on    (date). 
He/she has been missing from his/her ward since     (date). 
An internal enquiry report in this regard is enclosed.  
Kindly register a missing case, take him in to your protection when found and hand him over 
to us. 
 
Thanking you,  
 
Signature 
 
Date & Seal 
 
 
 
 
 
Enclosures: copy of the Aadhar Card, Recent Photograph and Internal Report  
 
 
 
 
 
 
 
 
 
 

123 
 
 
AGE OF INJURIES 
ABRASION:  
Fresh – Bright red; 
12 – 24 hours    - Reddish scab; 
2 to 3 days     - Reddish brown scab; 
4 to 7 days     - Brownish black scab; 
 7 days      - Scab dries, shrinks & falls off from periphery.  
 
CONTUSION:  
Fresh        - Red; 
Few hours to 3 days   - Blue; 
4
th
 day       - Blue black to brown (Hemosiderin); 
5 to 6 days  - Green (Haematoidin); 
7 to 12 days     - Yellow (Bilirubin):  
> 12 weeks       - Normal.  
 
INCISED WOUND: 
Fresh       - Hematoma formation; 
12 hours    - Swollen edges;  
24 hours    - Scab of dried clot covering the entire area.


# Unit to (R)FSL.

## Introduction

Unit to (R)FSL. 
64. Serology section: Forwarded to Deputy Director, Serology, Forensic Science 
Laboratory, Chennai / Regional Forensic Science Laboratory (Zone wise RFSLs receiving 
samples for Serology is given in the annexure).  
Blood sample from body / Control Blood – Few blood droplets from heart / blood 
from a peripheral vein shall be placed in a gauze piece (7.5 x 05 cm minimum) or 
chemical free filter paper and air dried; gauze / filter paper used shall have a portion 
free of blood for being used as control; 
Air dried sample shall be kept in separate paper cover /container, label with Medl. I-
30(a) label shall be bearing the Name, Age, Sex of deceased, Crime number, P.M. no 
with date, nature of sample, and body part from where it is collected and placed in a 
separate envelope and sealed. 
Legibly filled Form – Medl. I-30(d), pertaining to the case details, in charge constable 
carrying it, nature of sample and number of sample envelopes with relevant post 
mortem examination findings. All request documents (Form – Medl I-30(d), case history 
& F.I.R. copy) shall be kept in single envelope. 
Document envelope is to be sealed and handed over separately; 
All sealed Sample containing envelopes are placed in a box, box is to be sealed and 
then handed over to the in-charge constable. Investigating Officer shall obtain a 
Magisterial order for such analysis by Lab. 

59 
 
65. DNA section: Samples shall be forwarded to Deputy Director – DNA, Forensic 
Science Laboratory, Chennai (Jurisdictional Regional Forensic Science Laboratory, if DNA


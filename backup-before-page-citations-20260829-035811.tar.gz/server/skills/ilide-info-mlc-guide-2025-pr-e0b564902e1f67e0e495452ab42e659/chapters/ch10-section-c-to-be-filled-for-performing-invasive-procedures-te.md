# SECTION C: To be filled for performing invasive Procedures/ Tests only

## Introduction

SECTION C: To be filled for performing invasive Procedures/ Tests only  
 
17. Name of the doctor/s performing the procedure/s:  
 
18. History of genetic/medical disease in the family (specify): 
Basis of diagnosis (“Tick” on appropriate basis of diagnosis):  
(a) Clinical      (b) Bio-chemical 
(c) Cytogenetic      (d) other (e.g. radiological, ultrasonography etc.-specify) 
 
19. Indication/s for the diagnosis procedure (“Tick” on appropriate indication/s):  
A. Previous child/children with:  
(i) Chromosomal disorders      (ii) Metabolic disorders  
(iii) Congenital anomaly    (iv) Mental Disability 
(v) Haemoglobinopathy     (vi) Sex linked disorders 
(vii) Single gene disorder      (viii) Any other (specify)  
B. Advanced maternal age (35 years)  
C. Mother/father/sibling has genetic disease (specify)  
D. Other (specify)  
20. Date on which consent of pregnant woman / person was obtained in Form G 
prescribed in PC&PNDT Act, 1994  
 
21. Invasive procedures carried out (“Tick” on appropriate indication/s)  
i. Amniocentesis      ii. Chorionic Villi aspiration  
iii. Fetal biopsy      iv. Cordocentesis  
v. Any other (specify) 
 
22. Any complication/s of invasive procedure (specify) 
 
23. Additional tests recommended (Please mention if applicable)  
(i) Chromosomal studies    (ii) Biochemical studies 
(iii) Molecular studies      (iv) Pre-implantation gender diagnosis 
(v) Any other (specify) 
 
24. Result of the Procedures/ Tests carried out (report in brief of the invasive tests/ 
procedures carried out) 

214 
 
 
25. Date on which procedures carried out: 
 
26. The result of pre-natal diagnostic procedures was conveyed to    on 
 
27. Any indication for MTP as per the abnormality detected in the diagnostic procedures/ 
tests 
 
Date:      Name, Signature and Registration Number with Seal of the 
         Gynaecologist/Radiologist/Registered Medical Practitioner 
Place:         performing Diagnostic Procedure/s


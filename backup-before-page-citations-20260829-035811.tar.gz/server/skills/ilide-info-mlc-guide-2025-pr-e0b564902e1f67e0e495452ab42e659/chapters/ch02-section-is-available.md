# section is available).

## Introduction

section is available).  
In Dead: 
10 cm shaft of femur from dead body, clavicles and permanent molars preserved in 
common salt; 
in absence of femur, any long bone in common salt.  
In Dry bones – Bone is to be wrapped in paper; Molar teeth in a vial.  
Partly burnt body – Dry bone is wrapped in paper; Bone with Adhering tissue: 
Preserved in common salt.  
Blood in gauze cloth, air dried (not liquid blood); Tissues in saline can also be sent. 
Hair with root packed in a vial to identify the body; 
Air dried swabs of Buccal epithelial brushing on left & right buccal sides for deceased 
person’s DNA can also be sent. 
 
In a foetus / new born, right thigh preserved in common salt;  
Products of conception is to be rinsed with normal saline (not completely soaked in 
saline) & collected in a wide-mouthed container with a lid. 
Clothing /articles stained with blood or other body fluids (identifies victim or perpetrator);  
Vaginal smear/swab – to be collected by medical officer (to identify the perpetrator); 
Nail clippings with spencer well forceps (to identify the perpetrator); 
Container shall be labelled or air-dried sample in separate paper cover shall be 
labelled with Medl. I-30(a) label – bearing the Name, Age, Sex of deceased, Crime 
number, P.M. no with date nature of sample, body part from where it is collected and 
placed in a separate envelope / box. 
Legibly filled Form – Medl. I-30(d) pertaining to the case details, in charge constable 
carrying it, nature of sample and number of sample envelopes with relevant post 
mortem examination findings. All request documents (Form – Medl I-30(d), case history 
& F.I.R. copy) shall be kept in single envelope. 
Document envelope is to be sealed and handed over separately; 
All sealed Sample containing envelopes are placed in a box, box is to be sealed and 
then handed over to the in-charge constable. Investigating Officer shall obtain a 
Magisterial order for such analysis by Lab. 
66. Anthropology Section (Skull Superimposition): Samples shall be forwarded to Deputy 
Director, Anthropology, Forensic Science Laboratory, Chennai. 
Useful in case of decomposed bodies or burns or when face is not recognizable, 
Pack entire skull with mandible in common salt. 
Medical Officer shall advise the Investigating Officer to send a life size photograph of 
the suspected person in question, while taking the sample to Lab. 
Container shall be pasted with Medl. I-30(a), all Label shall be bearing the Name, 
Age, Sex of deceased, Crime number, P.M. no with date, nature of sample, body part 
from where it is collected and placed in a separate envelope and sealed. 

60 
 
Legibly filled Form – Medl. I-30(d), pertaining to the case details, in charge constable 
carrying it, nature of sample and number of sample envelopes with relevant post 
mortem examination findings. All request documents (Form – Medl I-30(d), case history 
& F.I.R. copy) shall be kept in single envelope. 
Document envelope is to be sealed and handed over separately; 
All sealed Sample containing envelopes are placed in a box, box is to be sealed and 
then handed over to the in-charge constable. Investigating Officer shall obtain a 
Magisterial order for such analysis by Lab. 
67. Chemistry Section: Sample shall be forwarded to the Deputy Director, Chemistry, 
Forensic Science Laboratory, Chennai. 
Useful to detect inflammable substances on clothes or on skin, in cases of burns –
Burnt remnant of clothes and piece of cotton swab from skin can be sent. 
Useful to estimate metallic substances concentration in entry & exit skin points in 
electrocution – Skin around Entry, Skin around Exit sites & Control skin samples in 
rectified spirit can be sent in select cases.  
Packing, forwarding, documents required are same as above. 
 
68. Ballistics Section: Sample shall be forwarded to the Deputy Director, Ballistics, 
Forensic Science Laboratory, Chennai. 
Useful to find gunshot residues on hands / other parts of body. 
 
Instruct / communicate Police or Investigating Officer to secure both upper limbs of the 
body by covering it in plastic cover.  
Instruct / communicate the Hospital staff to cover entire upper limbs with plastic 
sheets, as soon as the body arrives at hospital, if the above step is not followed / 
missed.    
GSR test sampling: 
Place Plain cotton ball in one container; Cotton ball dipped in Nitric Acid in one 
container; Cotton ball dipped in Nitric Acid swabbed over elbow in one container; 
Cotton ball dipped in Nitric Acid swabbed over dorsum of each fingers on both hands 
in one container. This is done to detect Secondary residues, if any.  
(Five ml of nitric acid to be dissolved in 95 ml of water to make 5% nitric acid) 
If firing was done with foot or toe, swabs can be taken from soles of both foot, 
dorsum of both foot, all toes and any other part of body likely to get residues from 
a likely scenic reconstruction and a control swab are to be sent.  
Results are more useful if the cotton ball swabs are taken within 03 hours of death, 
between 03 to 06 hours results are less useful.  
 
Alternatively, Stick a plain cellophane tape over snuff box region & proximal phalanx of 
index finger, peel the tape from body and place another plain tape piece over the 
peeled piece. This is done to capture Primary residues if any, between the two films 
of cellophane tape.  
Clothing need to be removed intact / cut on lateral aspect along the stitches, fold the 
clothes by keeping butter paper in between the folds and pack it;  

61 
 
Skin (entry wound) shall be cut circumferentially, place butter papers one above & one 
below it and keep the sample in a container.  
Packing, forwarding, documents required are same as above. 
On reception of Forensic Science Laboratory reports, acknowledgment slips shall be 
sent back through posts by the concerned Professor / Police Surgeon or Chief Medical 
Officer / Resident Medical Officer (the authority receiving requisition for autopsy).  
In case of Police constables carrying reports in extra ordinary situations, Laboratory 
letter shall be returned with due acknowledgment through the concerned Police 
constable. 
 
69. Histo-Pathological examination: Samples shall be forwarded to Professor of 
Pathology.  
Organ / Tissue bits shall be preserved in 10% formalin / 95 % ethanol preservative, 
covered by a layer of cotton on top;  
Medical Officers in Government hospitals, can send samples of internal organs, hyoid 
bone collected during autopsy to the nearest Government Medical College Pathology 
department. 
Form – Medl I-30(b) is to be filled in duplicate; of which duplicate copy is to be 
acknowledged and returned back by Professor of Pathology. 
Relevant autopsy findings can be written in the form itself along case history and 
F.I.R. copy, Medical Officer can guide the Pathologist in writing, regarding the disease 
process he is suspecting about. 
Pathological specimens collected can be used for preparing Medical College Museum. 
(Tamilnadu Medical Code – Para 272) 
 
70. Microbiological examination: Samples shall be forwarded to Professor of 
Microbiology.  
In Suspected microbiological cause of death, red hot spatulated spleen bit or smear 
from tissues in peritoneum / pericardium or gut swab for cultures can be sent to 
Microbiology department of nearest Medical College. 
Sample in culture medium for virus / 80 % glycerol in buffered saline can be sent to 
King’s Institute, Guindy, Chennai for virological examination. 
Biochemistry examination: Samples shall be forwarded to Professor of Biochemistry.  
Biochemistry department of nearest Medical College. 
 
71. FINAL OPINION: After receiving report of each ancillary investigation used, 
provisional opinion certificate of Medical Officer shall be sent in the same manner as 
discussed above. 
Viscera & other reports which arrive at later dates shall be entered into ‘Viscera 
Report Register’, ‘Histo-Pathological Examination Register’ and transferred to PM file by 
the Professor of Forensic Medicine / Police Surgeon. 
At the end of all ancillary reports, Final opinion certificate shall be sent in the same 
manner as discussed above. 

62 
 
Post mortem examination – Provisional Opinion / Final opinion (Annexure for format): 
Original    – Magistrate (sent through post immediately); 
Police copy  – Investigating Police Officer (Intimate the readiness of certificate to the 
concerned I.O. through Out Post / Nearest Police Station); 
HoD copy  - Head of the Department copy;  
Office copy  – Department record. 
Copy of FSL report can be sent to Magistrate along with Final opinion 
(Investigation Officer receives his report copy directly from FSL). 
 
Difference of opinion between the Tamil Nadu Forensic Science Department, Chennai 
and the post-mortem findings of Medical Officers – In all cases where the opinion of 
Medical officers based on post-mortem findings differs from that of the Tamil Nadu 
Forensic Science Department, Chennai / RFSL, the Medical Officers concerned should 
get into touch with the Tamil Nadu Forensic Science Department, Chennai / RFSL and 
ascertain reasons for arriving at different findings. (Surgeon Generals P. No. 51-M, 16th 
February 1939.) 
It becomes duty of the Enquiry Officer in cases of Post Mortem examinations done on 
death under Police Custody / torture to follow up Forensic Science Laboratory reports 
to prepare and send reports within 15 days. (Police Standing Order 151 A (2) (g)) 
Notification of District Health Authorities shall be made through Head of the Institution, 
in case of Notifiable diseases / Maternal deaths (S. 64 of Tamilnadu Public Health Act) 
  
72. Upon request from Court, for committal / trial of cases, requested documents shall 
be taken from Department records and shall be forwarded to Court through the 
mentioned Constable by Court.  
Such constable shall acknowledge in writing after receiving the same. 
Attested copies shall be sent ordinarily;  
but if Court specifically mentions for Original documents, originals shall be forwarded to 
Court through Constable concerned, photostat & attested copies of the document sent 
along with Court letter shall be attached to departmental record file. 
Forwarding such documents / reports doesn’t require a covering letter from Professor of 
Forensic Medicine / Police Surgeon.   
When Court requires Original document for committal / trial, and if, Final Opinion is 
pending because of non-receipt of RFSL / FSL reports, such fact shall be 
communicated to Court in writing and attested copies of all requested documents shall 
be sent.  
Once, Final Opinion is prepared, Original documents need to be sent to Court. 
73. Medical Officer on transfer: 
If a particular Medical Officer gets transferred to a new station and there is pendency 
of certificates, Head of Department of concerned old station shall request the Head of 
Institution of the new station to permit the medical officer concerned for its completion. 
TA / DA rules would be applicable for this bound duty.   
For Medical Officers who got superannuation, the concerned Head of Department 
through the Head of Institution can communicate to the Medical Officer regarding her / 

63 
 
his pendency. Medical Officer is lawfully bound to complete the same. TA / DA shall 
be managed by the concerned Institution. 
 
74. Weapons of Unusual Character / special interest  
In the opinion of the Sessions Judge, material objects confiscated in a Case is of a 
most unusual character or of special interest (other than firearms & ammunition) in the 
light of the facts of the case, it shall be ascertained by reference to the Professor of 
Forensic Medicine / Police Surgeon of Medical College & Principal of the Police 
Training School concerned, whether it is required for the Medico Legal Museum of the 
College or for the Police Museum in the School.  
The weapon shall be destroyed only if it is not so required.  
If it is so required, it shall be sent either to the Professor / Police Surgeon or 
Principal, Police Training School. The former shall, however, have priority over the 
latter in respect of weapons for which there is a demand from both of them. 
(Para 263 – The Criminal Rules of Practice, 2019, High Court, Madras.) 
 
75. Supply of copies of judgments and orders to Professor of Forensic Medicine:  
All Magistrates should forward to the Professor of forensic Medicine copies of their 
judgments or final orders in all cases in which their evidence have been taken.   
(Tamilnadu Medical Code – Para 630) 
 
76. Pathological Autopsy: Professor of Pathology shall take responsibility for Hospital / 
Pathological autopsy. 
 He / She shall ensure, 
 a) Scientific grounds for Pathological Autopsy;  
 b) Due Research / Scientific Committee approval for it; 
 c) Consent for autopsy from the relatives of dead; 
 d) Cost for consumables, personnel borne by the Department / Faculty requesting it. 
Procedure shall be conducted in Pathology Department itself – Limited dissection of a 
particular system(s) is to be done; Body shall be handed over to the relatives.  
Dissection hall of Anatomy / Forensic Medicine can be used with prior communication 
via a Request Letter and other details mentioned above. 
Time shall be fixed by Professor of Anatomy / Forensic Medicine in such cases, so 
that Students dissection / Medico Legal autopsies are not interfered with. 
 
77. Professor / Police Surgeon and Medical Officer in charge of stations (Departments 
or Units) should see that all circulars and other Government or departmental orders, 
issued from the Office of Directorate of Medical Education & Research, Directorate of 
Public Health & Preventive Medicine, Directorate of Medical Services, Directorate of 
Medical Services (ESI) as the case may be for the information of the department, are 
duly and regularly circulated amongst medical officers and subordinates serving under 
them, Medical Officers are however, allowed their own discretion in the manner of 
orders of a confidential or important nature (Tamilnadu Medical Code – Para 77). 
 

64 
 
78. Superintendent or Medical officer in charge of every Government institution is 
required to keep completed and up to date a book of the standing orders, Orders of 
Government and Health Directorates concerning the Institution.  
 
79. In these books, orders should be arranged in sections and paragraphs numbered 
continuously throughout. Number and dates of the orders, sanctioning a new standing 
order should be quoted in the margin. (Tamilnadu Medical Code – Para 283). 
 
80. Registers & Forms: 
Professor / Police Surgeon in Medical Colleges, shall ensure safe keeping of the 
records in the Department of Forensic Medicine as below:  
Regarding history, establishment, organization or reorganization of institution / department 
and all records containing matters of permanent interest are to be carefully preserved; 
Registers & Indices of correspondence should always be retained – Permanent; 
Orders book – Permanent; Visitor’s book – Permanent; 
Leave Registers – 25 years; Stock book – 25 years;  
Post Mortem Register (Age Case register, DNA case register) – 12 years; Post mortem 
certificate booklet – 12 years; 
Copy application register – 10 years;  
Call book – 03 years; Dispatch by post register – 03 years; Indent for stores & forms 
– 03 years; Leave account – 03 years; Records issue (Document lending) register – 03 
years; Stamp registers – 03 years; 
Register of letters received, Register of letters dispatched – 02 years; Stock book for 
forms & booklet (Used & Unused) – 02 years;  
Records showing key handing over & taking over – 01 year 
(Tamilnadu Medical Code, Para – 991) 
Certificate Issued register, Viscera reports / HPE reports register, Seal register, Autopsy 
kit / Microscopes register, Case Allotment register, Library book register, Book lending 
register – Time period not mentioned, hence keeping it as permanent would be 
prudent.  
Chief Medical Officer (Head of the Institution) shall entrust the records as above to 
Medical Records Section in other institutions. 
 
81. Closing the Department: 
Professor / Police Surgeon shall entrust on rotation, a Medical Officer & required para 
medical staff to supervise & submit the keys & wax impression metal seal (affixed 
while closing the department) to Institution Administration / Keys sergeant (KIPMM 59). 
On next morning, the same team shall oversee the intact seal and open the 
department. Department shall be locked with seal daily, only to be opened on next 
day / after explicit Government order to do so. 
Chief Medical Officer / Resident Medical Officer shall ensure the same where MLC / 
PM documents are kept.  
 

65 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
DNA TESTING CASES 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 

66 
 
DNA TESTING CASES:  
1. In Government Medical Colleges, Professor of Forensic Medicine / Police Surgeon 
shall receive requests for sample collection towards DNA testing; in his / her absence, 
Associate Professor; in his / her absence, Assistant Professor in the department shall 
receive such requests in the Forensic Medicine Department of the College. 
Receiving authority shall entrust the case in rotation to departmental sub ordinate 
Medical Officer(s) with written directions regarding conduct of the case. 
 
2. In Government Medical hospitals, Chief Medical Officer / Resident Medical Officer of 
the hospital shall oblige the requests and comply on rotational basis with directions 
towards the conduct of case.  
 
3. Letter from Court:  
Court shall direct in writing to the Forensic Science Laboratory for issuance of FTA 
(Flinder’s Technology Associates of Australia) card, stating the name and location of 
Government Hospital, designation of Medical Officer, who is to draw samples from the 
accused / victim / third party and  
(Investigating Officer shall co-ordinate with the Professor of Forensic Medicine / Police 
Surgeon in Government Medical College or Chief Medical Officer in Government 
Hospitals and fill in the Medical Officer designation, as the case may be and forward 
it to Court for the above purpose). 
4. Court can then forward FTA cards and Letters bearing Photographs, Identification 
marks of all persons from whom examplars are required to be drawn to Professor of 
Forensic Medicine / Police Surgeon or Chief Medical Officer for drawal of samples 
through Police. 
 
5. Letter from Police or Investigating Agency:  
When an Investigating Agency / Police, obtains FTA cards from the Forensic Science 
Laboratory;  
after consulting with  the Professor of Forensic Medicine / Police Surgeon or Chief 
Medical Officer for drawal of samples;  
Request letter containing Photographs, Identification marks of all persons from whom 
examplar is to be drawn, separate unfilled Form I with photograph of each person 
from whom the Medical Officer is required to draw examplar shall be submitted to 
Professor of Forensic Medicine / Police Surgeon or Chief Medical Officer. Reception 
and entries in the Medical Institution shall me made as above. 
(Model of Form I is in annexure) 
6. In addition, Investigating Agency shall videograph the process of drawal of examplar 
by the Medical Officer, and keep the videograph in an electronic form such as pen 
drive, compact disc etc. in their case diary and also furnish a copy of it to the Court 
concerned.  
No videograph shall be taken of drawal of semen, vaginal swabs, pubic hair and other 
examplars from the private parts of a person. 
The Medical Officer shall confirm the identity of the person with the photograph affixed 

67 
 
in Form I, and after drawing the examplar, shall fix the same, obtain the signature 
and thumb impression of the person and seal in Form I.  
(High Court, Madras – R. O. C. No. 39824 / 2020 / F1 / P. Disc. No. 92 / 2020; 28.12.2020;  
Tamilnadu, DGP – Circular memorandum No. Crime I / 181716 / 2011, dated: 09.08.2011) 
 
7. Request letters in otherwise situations: 
In situations of Disputed Paternity / Maternity, under Domestic Violence Cases etc, (not 
under Police Cases with a Crime number); concerned authority taking up the cases 
shall nominate a Designated Officer. Such Officer shall obtain DNA / FTA cards from 
the FSL Chennai.  
After consulting with the Professor of Forensic Medicine / Police Surgeon or Chief 
Medical Officer for drawal of samples;  
Request letter containing Photographs, Identification marks of all persons from whom 
examplar is to be drawn, separate unfilled Form I with photograph of each person 
from whom the Medical Officer is required to draw examplar shall be submitted to 
Professor of Forensic Medicine / Police Surgeon or Chief Medical Officer. 
Expenses to be borne by the concerned party for travel to & fro, video recording of 
sample drawal etc. (Police Standing Order – 381 (B)) 
 
8. Register: 
A ‘DNA Examplar register’ shall be maintained at institutions; cases shall be entered 
with Name, Age, Sex, Signature & thumb impression of the accused / victim / third 
party, Police Station with Crime Number, Name & designation of the Official 
accompanying the accused / victim / third party, Name & designation of the Medical 
officer, Date & time of examplar drawn, details of examplar drawn. 
 
9. FTA cards: 
Space with lines in the folding covers of FTA Card is for filling details of the case 
and identification of the person. 
 
10. Medical Officer, under aseptic precautions, shall make drops of blood (pricking, not 
by syringing) of the concerned person into the designated areas of FTA card.  
 
11. Card shall be air dried, not shown into direct light;  
Card shall be put inside self-sealing envelope provided and signed by the Medical 
Officer with seal. 
 
12. Sealed Envelopes: 
Envelope (s) shall be placed in forwarding Cover bearing details of the case (provided 
by FSL), pasted and affix wax impression seal on the space designated as ‘G.H.’ 
alone.  
Cover containing the samples shall be handed over to the in-charge Constable 

68 
 
entrusted by Court and he / she shall be instructed to get wax impression seal on 
the space designated as ‘Court’ and forward it to FSL through the Court. 
Acknowledgement shall be obtained from the constable / Investigating officer. 
 
13. When the process is done upon the request of Police / Investigating Agency 
alone,  
The Medical Officer shall hand over the examplars in a sealed cover with her / his 
rubber stamp affixed on the cover, to the Investigating Agency to be submitted to 
Court as above.  
Sealed cover shall be accompanied by Form I duly filled and certified by the Medical 
Officer.  
Investigating Agency shall then forward it to Forensic Science Laboratory through the 
Court as above. 
 
14. When Court directs for DNA sampling & testing on CFSL, Hyderabad etc on 
certain cases, same procedure shall be followed and exemplars can be preserved 
using FTA Card / blood on Gauze / Blood on EDTA.  
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 

69 
 
 
 
 
 
 
 
 
 
 
 
 
DRUNKENNESS CERTIFICATION 
 
 
 
 
 
 
 
 
 
 
 
 

70 
 
DRUNKENNESS CERTIFICATION:  
1. Certification regarding drunkenness status of a person can be obtained from the 
Casualty / Emergency Department of a Government Medical Institution (Prohibition cum 
Accident cases for drunkenness status examination has jurisdiction for each Medical 
College in Chennai – same as brought dead, Age cases, Bone cases, Second Opinion 
cases, Sexual Offence Accused examination cases etc.) by any Police Officer with 
written request.  
 
2. Scheme of examination for ascertaining drunkenness in an individual is to be done 
in the Proforma given in annexure (Medl I 66 C) to withstand legal scrutiny and be 
acceptable in Courts of Law. (Tamilnadu medical Code, Para - 634) 
Proforma scheme of examination is to be done, form along with Police letter / memo, 
FSL receipt (if investigations sent) and Duplicate certificate are to be tied into a single 
file or attached to the register maintained and numbered serially. 
 
3. Consent is to be asked for examination, on refusal, examination of accused of 
offence can be done with reasonable force upon requisition from those concerned 
police officer, when a female has to be examined under this section, examination shall 
be done by or under the supervision of a female medical practitioner shall do the 
examination. (S. 51 BNSS).  
 
4. For cases referred for examination directly by other Department Authorities (Railways, 
Road Transports, Uniformed services Departments etc.) Original to investigating Officer, 
Duplicate to Referred Authority, Triplicate to the examined person and Quadruplicate to 
Emergency Department Office file can be done. 
 
5. Cost of reproduction of Duplicate and Triplicate certificates are to be paid to hospital 
office by the authorities requesting certification. 
 
6. Ancillary investigations: 
Smell of alcohol cannot be relied completely, symptoms produced during Stage of 
Excitement are subjective; hence blood, urine, stomach wash for FSL examination shall 
be done. (Tamilnadu Medical Code, Para – 634) 
10 ml of blood from ante – cubital vein after cleaning the area and allowing it to air 
dry; Midstream Urine sample are sent. 
100 mg of Sodium Fluoride + 20 mg of Potassium oxalate are added as preservative 
in a glass container; with label – Medl. I-30(a), sealing wax impression and sent 
through in charge Police constable. 
Ideally, collection of two samples of Blood & Urine in 30 minutes interval is 
scientifically more useful for interpretation of quantitative analysis & intoxication levels.  
Blood can also be preserved by adding crystals of Sodium Chloride, Urine can also 
be preserved by adding crystals of Sodium Chloride, till it is saturated. (Tamilnadu Medical 
Code, Para – 635) 
 

71 
 
7. Examination findings, Copy of Viscera label – Medl. I-30(a), History & F.I.R. copy, if 
any, are to be enclosed in an envelope, sealed and addressed to – Deputy Director 
(Toxicology – D), Forensic Science Laboratory, Chennai in Chennai jurisdiction and 
Deputy Director (Toxicology – D), Regional Forensic Science Laboratory on Police 
Districts Jurisdiction. Investigating Officer shall obtain a Magisterial order for such 
analysis. Certificate shall be given issued without any delay.  
Biochemistry Department of nearest Medical College can also be utilised for the same.  
 
8. On reception of reports, Final Opinion is to be given by the Medical Officer who 
did the Drunkenness examination in the same manner as above (Readiness of 
Certificate can be communicated through OP / nearest station). 
 
9. Drunkenness examination & Certification under Tamilnadu Prohibition Act may be 
done by Rural Medical practitioners. District Superintendent of Polie is authorised to 
sanction their fees for the certificates. (Tamilnadu Medical Code – Para 636 & 427) 
But the above examination & certification is prohibited for homeopathic practitioners 
(Tamilnadu medical Code, Para - 637) 
 
10. Drunkenness examination & Certification of a person or railway employee shall be 
done by Railway doctor, it shall be marked as Medico Legal Case, examined carefully, 
blood sample obtained and tested at any Govt. or private lab at the earliest. (Tamilnadu 
Medical Code, Para – 639; Indian Railway Medical Manual, Section – G, Para 565 - 567).  
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 

72 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
EXPERT OPINION 
 
 
 
 
 
 
 
 
 
 
 
 

73 
 
EXPERT OPINION certificates:  
1. Investigating Officer of a case can request to the Professor of Forensic Medicine / 
Police Surgeon of Govt. Medical College of the District / Nearest Govt. Medical 
College (if there is no Medical College) for Expert opinion for cases conducted in the 
same Medical College department or nearby medical institutions. (Tamilnadu Medical Code, 
Para 624, 625) 
 
2. If necessary, through the Director of Medical Education & Research to a panel of 
more autopsy experienced Professors in Govt. Medical Colleges than the first opinion 
expert. (Tamilnadu Medical Code, Para 652) 
 
 
3. It can be sought for Autopsy cases, Age cases, Sexual offence cases, Wound 
certificates, Drunkenness certificates or any other medico legal certificates.   
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 

74 
 
 
 
 
 
 
 
 
 
 
 
 
 
SEXUALOFFENCE CASE – SURVIVOR FEMALE EXAMNATION  
 
 
 
 
 
 
 
 
 
 
 
 

75 
 
SEXUAL OFFENCE CASE – SURVIVOR FEMALE EXAMINATION:  
Sexual Offence suspected upon Medical Examination: 
A doctor, when dealing with an adult / child, for medical consultation, finds from 
history or examination findings observed, suspects on medical opinion suggesting sexual 
assault / abuse, treatment and psychological support is to be started at once.  
M.L.C. is to be marked and Police intimation is to be given mandatorily. 
If the victim is not willing for Police intimation – Police intimation shall have the line – 
‘Denial / Refusal for Police Intimation’. 
In Primary Health Centres, if any POCSO cases come, First aid and vitals shall be 
checked, stabilise the victim and then immediately send the victim / survivor to the 
nearby Government Hospital through 108 Ambulance services.  
Examination: 
Proforma for examination and model certification (applicable to all Government & Private 
Medical Institutions) are in annexure (GO (Ms) No: 201, Health and Family Welfare Department; 
dated:11.07.2014; GO (Ms) No: 174, Health and Family Welfare Department; dated:18.06.2015) 
Gender, class, caste, religion, ethnicity or other factors are not to be considered for 
examination & treatment.  
Report shall contain - Name, Age, brought by, address, materials collected, marks of 
injury, mental condition, start & completion time of examination, other details if any. 
When a victim (child) is brought to the hospital at an advance stage of pregnancy or 
after the girl had delivered a child, it will suffice to take note of the stage of 
pregnancy of the victim girl after properly identifying her and in case where the girl 
delivered a child, to take note of the same and identify the girl and the child with 
necessary particulars. Examination for the purpose of filling the Proforma above is not 
necessary, 
Examination shall be for the counselling and treatment of any injuries on body;  
Suggest for MTP, with due consent from parent / guardian, Intimation to Police for 
MTP under Humanitarian ground (rape) shall be made  
((Forms in Annexure – Director of Family Welfare, Chennai – SOP - Ref. No. 10053 / FW / D7 / D& E 
/ 2023; 8-1-25; HCP No. 2182 of 2022, High Court of Madras, Madras). 
 
Register: 
‘Sexual Offence Survivor Register’ containing serial numbering of cases examined, 
examining doctor, other details etc. shall be maintained. 
Sexual orientation and sex worker as profession are individual’s choices, no attempts 
shall be made by the medical practitioner with idea of correcting / curing it; choices 
shall be left to the individuals and necessary psychological and medical support given. 
Hospital shall give free treatment of child victims (penetrative sexual assault & sexual 
assault, under 18 years), rape survivors, vitriolage victims (G.O. (D) No. 641 Health and 
Family Welfare (E1) Department, dated: 20.06.2013); 
In cases of victim of custodial rape, intimation shall be done to Revenue Divisional 
Officer in addition to Deputy Superintendent / Assistant Superintendent of Police to aid 
in their investigation under Police Standing Order 151. 
 

76 
 
Examination is to be done by: 
In Adult:  
Examination of a survivor of rape / attempted rape presenting herself shall be done 
by a Registered Medical Practitioner in Government run / Local body run institution; 
in absence of the above mentioned, any registered medical practitioner – treatment 
takes precedence. 
Female adult victim can be examined with consent by doctor of any gender; 
In Child: 
< 18 years female victim shall be examined by female doctor(s) only; (S. 27 (2) of 
POCSO Act.)  
Medical Examination and forensic sample collection shall proceed irrespective of FIR 
filed / complaint filed.  
Medical Officer / Practitioner shall make it a M.L.C. case & Police intimation is 
mandatory; If the victim is not willing for Police intimation – Police intimation shall have 
the line mentioned – ‘Denial / Refusal for Police Intimation’ and Intimation shall be 
done by the Medical Practitioner / Officer (Forms in Annexure – Director of Family Welfare, 
Chennai – SOP - Ref. No. 10053 / FW / D7 / D& E / 2023; 8-1-25). 
 
Examination under Police / Magistrate / Court: 
Child:  
Under POCSO, only in Penetrative Sexual Assault or Aggravated Penetrative Sexual 
Assault Forensic examination and evidenced collection is needed.  
Injuries on the body as in non-penetrative sexual assault or other sections of POCSO 
needs medical attention / opinion regarding nature of injury alone.  
Doctor who examines the victim child shall take a decision as to the nature and 
extent of medical examination that has to be conducted with the child for the purpose 
of preparing a report. (HCP No. 2182 of 2022, High Court of Madras, Madras). 
In victims, <12 years, parent / guardian can consent;  
For genital examination, invasive investigations, consent of individual > 18 years, 
consent of parents in < 18 years is mandatory. 
Informed Consent / Informed refusal needs to be sought separately for  
1. Examination; 2. Sample collection; 3. Treatment; 4. Police Intimation. 
In life threatening situation, treatment shall be initiated without consent to save life of 
the individual, Head of the Institution shall be intimated to nominate one woman to be 
present & accompany the survivor. (S. 30 of BNS)  
Adult: 
Where, during the stage when an offence of committing rape or attempt to commit 
rape is under investigation, it is proposed to get the person of the woman with whom 
rape is alleged or attempted to have been committed or attempted, examined by a 
medical expert, such examination shall be conducted by a registered medical 
practitioner employed in a hospital run by the Government or a local authority and in 
the absence of such a practitioner, by any other registered medical practitioner, with 
the consent of such woman or of a person competent to give such consent on her 
behalf and such woman shall be sent to such registered medical practitioner within 
twenty-four hours from the time of receiving the information relating to the commission 
of such offence. 
Police are to send the person with Police Memo / Letter, for Forensic Examination of 

77 
 
sexual offences survivors Forensic examination shall be started after written expressed 
consent (if needed with interpreter / social worker); 
Victim cannot be forced to undergo Forensic examination. 
In cases of sexual offence victim examination – transgender / intersex / third sex 
person shall be identified as third gender. 
If they desire and decide to be identified as male or female, same shall be entered 
(irrespective of genital / hormonal sex) and pronouns of that particular sex be used in 
further communication to him / her and in the certifications 
 
In cases of rape under Police custody, the victim should be sent to a nearby Hospital 
/ Medical officer for Medical check-up within 06 hours of occurrence of crime and 
medical opinion should be obtained on the same day by the Enquiry Officer. (Police 
Standing Order 151 A (2) (h)) 
Whenever a complaint of rape in custody against the Police is made, the Sub 
Divisional Magistrate should immediately subject the victim to medical examination as 
early as possible within 6 hours of the incident and arrange to send the dresses 
worn by the victim at the time of the incident for chemical analysis and report based 
on the medical and forensic evidence and testimony of the ravished Woman and by 
other evidences, the enquiry officer can draw inference whether the alleged rape was 
committed or not (Police Standing Order 151, (C) DETAILED GUIDELINES FOR CONDUCTING PSO 
151 (OLD PSO145) ENQUIRY, Part IV, C (e)). 
 
In cases of Medical Colleges, a ‘One Stop Crisis Centre’ unit (/ separate room) shall 
function with faculties from Obstetrics & Gynaecology, Paediatrics, Casualty Medical 
Officer / EMO, Psychiatrist in a place preferable for patient’s care and the above 
departments. Survivors (child / adult) shall not be examined at General ward / 
Casualty / Labour ward where other patients will be waiting.


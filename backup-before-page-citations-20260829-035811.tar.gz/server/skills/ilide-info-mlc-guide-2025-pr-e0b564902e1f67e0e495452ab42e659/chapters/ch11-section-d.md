# SECTION D:

## Introduction

SECTION D:  
DECLARATION OF THE PERSON UNDERGOING PRENATAL DIAGNOSTIC TEST/ 
PROCEDURE 
 
I, Mrs./Mr.          declare that by undergoing 
the          Prenatal Diagnostic Test/ Procedure,  
I do not want to know the sex of my foetus.  
 
Date:       Signature/Thumb impression of the person undergoing  
          the Prenatal Diagnostic Test/ Procedure  
 
In Case of thumb Impression:  
Identified by (Name)      Age:    Sex: 
Relation (if any):     Address & Contact: 
 
Signature of a person attesting thumb impression: 
 
Date: 
 
DECLARATION OF DOCTOR/PERSON CONDUCTING PRE NATAL DIAGNOSTIC 
PROCEDURE/TEST 
 
I,           (name of the person conducting 
ultrasonography / image scanning) declare that while conducting ultrasonography/image 
scanning on Ms./ Mr        (name of the pregnant woman or the 
person undergoing pre-natal diagnostic procedure/ test),  
I have neither detected nor disclosed the sex of her foetus to anybody in any manner.  
 
 
Signature:    
Date:       Name in Capitals, Registration Number with 
          Seal of the Gynaecologist / Radiologist / Registered 
          Medical Practitioner Conducting Diagnostic procedure 
 

215 
 
FORM G (See Rule 10) 
FORM OF CONSENT (For invasive techniques) 
 
I,       wife/daughter of     Age   years residing at 
               hereby state that I 
have been explained fully the probable side effects and after effects of the pre-natal 
diagnostic procedures. 
I wish to undergo the preimplantation / pre-natal diagnostic technique / test / procedures 
in my own interest to find out the possibility of any abnormality (i.e. disease / deformity / 
disorder) in the child I am carrying.  
I undertake not to terminate the pregnancy if the pre-natal procedure / technique / test 
conducted show the absence of disease / deformity / disorder.  
I understand that the sex of the foetus will not be disclosed to me.  
I understand that breach of this undertaking will make me liable to penalty as prescribed 
in the Pre-natal Diagnostic Techniques (Regulation and Prevention of Misuse) Act, 1994 (57 
of 1994) and rules framed thereunder.  
 
Date 
Place         Signature of the pregnant woman. 
 
 
I have explained the contents of the above to the patient and her companion  
 
(Name       Address  
            
Relationship   ) in a language she / they understand.  
 
Name, Signature and / Registration 
number of Gynaecologist / Medical 
Geneticist / Radiologist / Paediatrician / 
Director of the Clinic / Centre / 
Laboratory  
 
Date  
 
            Name, Address and Registration number 
            of Genetic Clinic / Institute 
 
SEAL 
 
 
 
 
 
 
 
 

216 
 
FURTHER READING: 
 
1. Tamilnadu Medical Code, Volume 1 and 2.  
 
2. Tamilnadu Police Standing Orders & Rules (PSOs). 
 
3. Govt. of India, Hospital Manual – 2002. 
 
4. National Human Rights Commission Guidelines in Custodial Deaths. 
 
5. Haryana Medico Legal Manual – 2012. 
 
6. Kerala Medico Legal Code – 2011. 
 
7. Maharashtra Medico Legal Manual – 2018. 
 
8. Right to Information Act, 2005. 
 
9. Medico Legal Examination & Postmortem Reporting System (MedLeaPR). 
 
10. Handbook on Forensic Science & Criminal Justice System, Chandigarh Judicial Academy 
2017. 
 
11. WHO Guidelines for Medico-Legal Care for Victims of Sexual Violence. 
 
12. Guidelines & Protocols, Medico-Legal Care For Survivors / Victims of Sexual Violence, 
MoHFW, Govt of India. 
 
13. Department of Health Research (DHR) Guidelines, Forensic Medical Care For Victims Of 
Sexual Assault. 
 
14. Clinical Forensic Medicine. A Physician’s Guide. Edited by Margaret M. Stark. New 
Jersey, USA. 2005. Chapter 4.1. Forensic Evidence 4.1.1. Method of Sampling, p 72.   
 
15. Tamilnadu Prison Rules.


# Section A: To be filled in for all Diagnostic Procedures/Tests

## Introduction

Section A: To be filled in for all Diagnostic Procedures/Tests  
 
1. Name and complete address of Genetic Clinic/Ultrasound Clinic/Imaging centre: 
 
 
2. Registration No. (Under PC& PNDT Act, 1994) 
 
3. Patient’s name        Age 
 
4. Total Number of living children: 
(a) Number of living Sons with age of each living son (in years or months):  
(b) Number of living Daughters with age of each living daughter (in years or months):  
 
5. Husband’s /Wife’s/ Father’s / Mother’s Name : 
 
6. Full postal address of the patient with Contact Number, if any 
 
 
 
7. (a) Referred by (Full name and address of Doctor(s)/ Genetic Counselling Centre):  
 
 
(Referral slips to be preserved carefully with Form F)  
 
(b) Self-Referral by Gynaecologist / Radiologist / Registered Medical Practitioner conducting 
the diagnostic procedures: 
 
(Referral note with indications and case papers of the patient to be preserved with Form 
F) (Self-referral does not mean a client coming to a clinic and requesting for the test or the 
relative/s requesting for the test of a pregnant woman) 
 
 
8. Last menstrual period or weeks of pregnancy :


# Section 116 of BNS is as follows:

## Introduction

Section 116 of BNS is as follows:  
The following kinds of hurt only are designated as Grievous: -  
Emasculation; 
Permanent privation of the sight of either eye; 
Permanent privation of the hearing of either ear; 
Privation of any member or joint; 
Destruction or permanent impairing of the powers of any member or joint; 
Permanent disfiguration of the head or face; 
Fracture or dislocation of a bone or tooth; 
Any hurt that endangers life or which causes the sufferer to be during the space of 
fifteen days in severe bodily pain, or unable to follow his ordinary pursuits.  
Wound(s) that heal with or without complications and don’t fit into Grievous hurt are 
(simple) hurt(s).  

124 
 
 (Medl.I-24) 
GOVERNMENT .............................. HOSPITAL, 
......................................... 
WOUND CERTIFICATE (Issued in Triplicate) 
Certificate concerning wounds found in a male / female / third sex ....................................................... 
aged ...................years, an inhabitant of ........................................................................................ 
who was sent with letter/memo no / IP no / OP no: ...............................................dated....................... 
from.................................................................................................................................. 
and was accompanied by.......................................................................................................... 
for report as to the nature of wounds. 
Identification marks:    1) 
     2)  
 
I am of the opinion that above wounds.............................................................................. 
.................................................................................................................................................................... 
....................................................................................................................................................................... 
.............................................................................................................................. 
.................................................................................................................................................................... 
 
Station   :        Signature of the Medical Officer: 
Date    :        Name in block letters, Registration number & Designation: 
Sent to   : 
Copy to   :   
 
 
ORIGINAL 
S.No: 
 
S. No 
 
Type of wound 
 
Size  
 
Site  
 
Simple/ Grievous / 
Dangerous 
 
Weapon or 
Manner of 
production 
 
Remarks 
(Age of wound 
etc.) 
       

125 
 
 (Medl.I-24) 
GOVERNMENT .............................. HOSPITAL, 
......................................... 
WOUND CERTIFICATE (Issued in Triplicate) 
Certificate concerning wounds found in a male / female / third sex ....................................................... 
aged ...................years, an inhabitant of ........................................................................................ 
who was sent with letter/memo no / IP no / OP no: ...............................................dated....................... 
from.................................................................................................................................. 
and was accompanied by.......................................................................................................... 
for report as to the nature of wounds. 
Identification marks:    1) 
     2)  
 
I am of the opinion that above wounds.............................................................................. 
.................................................................................................................................................................... 
....................................................................................................................................................................... 
.............................................................................................................................. 
.................................................................................................................................................................... 
 
Station   :        Signature of the Medical Officer: 
Date    :        Name in block letters, Registration number & Designation: 
Sent to   : 
Copy to   :   
 
 
DUPLICATE 
S.No: 
 
S. No 
 
Type of wound 
 
Size  
 
Site  
 
Simple/ Grievous / 
Dangerous 
 
Weapon or 
Manner of 
production 
 
Remarks 
(Age of wound 
etc.) 
       

126 
 
(Medl.I-24) 
GOVERNMENT .............................. HOSPITAL, 
......................................... 
WOUND CERTIFICATE (Issued in Triplicate) 
Certificate concerning wounds found in a male / female / third sex ....................................................... 
aged ...................years, an inhabitant of ........................................................................................ 
who was sent with letter/memo no / IP no / OP no: ...............................................dated....................... 
from.................................................................................................................................. 
and was accompanied by.......................................................................................................... 
for report as to the nature of wounds. 
Identification marks:    1) 
     2)  
 
I am of the opinion that above wounds.............................................................................. 
.................................................................................................................................................................... 
....................................................................................................................................................................... 
.............................................................................................................................. 
.................................................................................................................................................................... 
 
Station   :        Signature of the Medical Officer: 
Date    :        Name in block letters, Registration number & Designation: 
Sent to   : 
Copy to   :   
 
TRIPLICATE 
S.No: 
 
S. No 
 
Type of wound 
 
Size  
 
Site  
 
Simple/ Grievous / 
Dangerous 
 
Weapon or 
Manner of 
production 
 
Remarks 
(Age of wound 
etc.) 
       

127 
 
AGE CASE No:....... ..........            
dt:....... ..........                                                            
...................... MEDICAL COLLEGE, ............. 
............................................................................ 
DEPARTMENT OF FORENSIC MEDICINE. 
AGE ASSESMENT CERTIFICATION PROFORMA. 
                                                            (1/4) 
Requisition from:         Dated: 
 
1. Name of the individual        : 
2. Sex           :      
3. Parent’s or Guardian’s Name    : 
4. Address and Residence       :  
 
5. Occupation          :      
6. Caste & Identification mark     :  
 
7. Married or Single        : 
8. Age as alleged by       :  
9. Persons accompanying or brought by     :  
 
10. Time & Place of Examination      :  
 
11. Consent of the individual for examination     :  
 
12. Signature of the individual    : 
 
13. In case of minor, signature of Guardian  : 
14. Name of the nurse present at the time of  
      examination         : 
     :   
                
 
 
                     

128 
 
PHYSICALEXAMINATION                (2/4) 
1. Height        : 
2. Weight        :  
3. Breadth       : 
 
 
4. Chest girth at the level of nipples  : 
5. Abdominal girth at the level of Navel   : 
6. General build & appearance   : 
7. History        : 
 
8. Voice         : 
9. Teeth         :     
10. Hair -  Scalp :      Beard :      Moustache :       
  Axilla :      Pubic : 
11. General appearance and demeanour   : 
  State of clothing 
  Deposition 
  Speech 
  Gait 
12. General examination    :  
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 

129 
 
 
13. Dentition:                                                    (3/4) 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
                                                             

130 
 
14.  Radiological examination:                                          (4/4) 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
OPINION:  
 
 
Police Surgeon,............and Professor of Forensic Medicine, 
.......................... Medical College, .............. 
 
 
ORIGINAL  : 
DUPLICATE :  
 
 
 

131 
 
Medl. – 30 (e) 
DEPARTMENT OF FORENSIC MEDICINE, 
........................... MEDICAL COLLEGE, 
........................... 
                                                   
Age Case No:                                     Date:  
From  
     The Police Surgeon and Professor of Forensic Medicine,  
     .......................... Medical College, .................... 
 
To  
     The Radiologist,  
     .......................... Medical College, .................... 
 
Madam / Sir,  
     I request that radiograms of the progress of ossification for estimation of age with regard to 
the individual sent herewith bearing the under mentioned identification marks and accompanied by 
P.C. No........................................................................................................... be 
taken and forwarded to me with a report of their findings. 
Name:                           Alleged age:  
Identification marks:  
X rays:  
 
 
 
 
 
 
 
 
 
                                        , 
 Police Surgeon,............and Professor of Forensic Medicine, 
.......................... Medical College, .............. 
 
 

132 
 
Medl. – 30 (h) 
DEPARTMENT OF FORENSIC MEDICINE, 
........................... MEDICAL COLLEGE 
AGE CASE REPORT 
Age Case No:            Date:  
Name:                 Sex:                      Sent by: 
Identification Marks:        
Radiology:  
Anatomical part                      Condition of epiphysis       Approximate Age 
Head of Humerous 
Greater tuberosity  
Lesser tuberosity  
Tip of 132ntussusc process 
Acromion process  
Sternal end of clavicle  
Capitulum 
Trochlea  
Lateral epicondyle  
Medial epicondyle   
Head of radius   
Upper end of ulna / Olecranon 
Lower end of radius  
Lower end of ulna 
Base of I Metacarpal  
Heads of other metacarpals  
Phalanges  
Capitate  
Hamate  
Triquetral  
Trapezoid, Scaphoid 
Trapezium  
Pisiform  
Iliac crest  
Tri radiate cartilage (acetabular cup) 
Ischio pubic ramus  
Ischial tuberosity  
Head of Femur 
Greater trochanter  
Lesser trochanter 
Lower end of femur 
Upper end of tibia 
Upper end of fibula  
Patella   
Lower end of tibia 
Lower end of fibula 
Calcaneum  
 

133 
 
 
Other X rays, if applicable: 
X ray skull  
 
 
X ray sternum  
 
 
 
 
 
Dentistry: 
Dental formula: 
 
 
 
 
X ray appearance.  
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
Medl – I 30 (h) 

134 
 
AGE ASSESSMENT:  
Physical development Stages in Women:  
 
8-9 Hormones begin to release, sometimes causing moodiness and skin 
sensitivity 
9-10  Hips start rounding out 
10-11    Breast nipples begin to grow, Breast tissues around and under nipple 
begin to appear 
Growth spurt may be seen 
Downy hair near labia 
12-13    Axially hair 
Genital organs growth 
13-14    Underpants are wet with clear mucous 
More with ovulation and sexual arousal 
14-15  Earliest normal pregnancy 
Major growth spurt complete 
15-16  Acne 
Deepening voice 
16-17 Full height achieved 
09 and 14 years – Menstruation age, Pregnancy is possible.  
 
Development Stages in Men: 
9-10     Hormones begins to release, sometimes causing moodiness and skin 
sensitivity 
10-11 Testes become larger, Scrotal skin redder in colour and coarse in 
texture 
11-12 Prostate gland begins to function 
Penis begins to lengthen 
12-13 Pubic hair growth 
Growth spurt may begin 
Spontaneous erections 
13-14  Rapid growth of penis 
Testes colour deepens 
Pseudo breast 
14-15    Axillary hair 
Voice changes 
15-16 
Average age when sperm matures 
Can cause pregnancy 
Majority of growth spurt complete 
16-17    Chest and shoulder will fill out 
Acne 
Body hair 
21  Full height achieved 
 
 
 
 

135 
 
Secondary sexual characters - 
Pre-pubertal (10-12 years), Pubertal (12-14 years) and Post-pubertal (14-16 years).  
Breast development – Tanner stage of breast in female 
Stage 1 
Prepubertal 
(not before 9-10 years) 
Elevated papilla, small fat areola 
Stage 2 
(10-11 years) 
(Breast bud) 
Papilla forms a palpable nodule  
Stage 3  
(by 13 years) 
Breast development beyond the areola, 
contour of breast not defined 
Stage 4  
(by 13 years) 
Contour of breast well defined, more breast 
development with elevation of the Areola double mound 
Stage 5  
(by 15-16 years) 
Mature breast – more breast development with loss of 
double mound, papilla project as Nipple 
 
Age ranges in population: 
Breast Budding 11±1.2 years, within 2 years fully developed; 
Appearance of pubic hair 11.8± 1.2.5 years; 
Growth Spurt 12.5 ± 1.5 years; 
Menarche 13.5±1.5 years; 
Pubic hair development:  
 
Dental Age:  
 
Teeth 
 
Eruption 
 
Root completion & 
Calcification  
Central Incisor  Range 6-8 years,mean 7.1 years 10 years 
Lateral Incisor  Range 7-9 years, mean 7.8 years 
11 years 
Canine Range 11- 12 years, mean 10.8 years 13-15 years 
First Premolar Range 9-11 years,mean 10.5 years 12-13 years 
Second Premolar Range 10-12 years,mean 10.6 years 13-14 years 
First Molar Range 6-6.5 years, mean 6.5 years 9-10 years 
Second Molar  Range 12-14 years, mean 11.8 years 14-16 years 
Third Molar  Range 15-25 years, 
mean 18 years male, 17 years female 
18-25 years 
  
Female 
 
Male 
Stage 1: 
(< 12 years) 
No pubic hair, fine brown 
 
Vellus hair 
Stage 2: 
(12-13 years) 
Sparse not extending on to 
mons pubis 
Light pigmented at thebase of 
penis 
Stage 3: 
(13-14 years) 
Darker, coarse extending on 
to monspubis, pigmented 
Starts to curl and spread 
Stage 4 
(14-15 years) 
Covering most parts but not 
going upto thighs  
Covering most parts but not 
going upto thighs 
Stage 5 
(> 15 years) 
Dense hair extending to the 
innerthighs 
Mature pubic  
Hair 

136 
 
Third molars: 
Germination centre of the third molar appears between 7 and 9 years, and in 
majority of the cases the 
eruption is not seen before 16 years of age in females. 
Eruption and development of teeth in females takes place one year earlier than 
males. 
Crown and Root Development of the Third Molars – Complete Crown Formation 15 
years; Crown with 1/3
rd
 Root Formation 16 Years; Crown with 2/3
rd
 Root Formation 
17 Years; Crown with Complete Root Formation 18 years; Apical Closure of Root 19 
years.  
 
Skeletal age: 
Pelvis (X-ray AP view) 
 Age of appearance  Fusion  
Iliac crest 14 years 21 to 22 years 
Tri radiate cartilage  
(acetabular cup) 
Nil 13 to15 years  
Ischio pubic ramus  Nil  06 years 
Ischial tuberosity 16 years  21 to 22 years  
Head of Femur ½ to 01 year 17 to 18 years  
Greater trochanter  03 years 17 to 18 years 
Lesser trochanter 12 to 14 years 17 to18 years 
 
Shoulder joint (X-ray AP view – age group17-18 years) 
 Age of appearance  Fusion  
Head of Humerous 01 year Centres unite at 06 years & 
forms conjoined epiphysis, which 
fuses with humeral shaft at 18 to 
19 years 
Greater tuberosity  03 years  
Lesser tuberosity  05 years  
Tip of 136ntussusc 
process 
11 years  16 years  
Acromion process  15 years  18 years  
Sternal end of clavicle  19 years  21 years  
 
 
Elbow Joint (X-ray AP & Lateral view – age group14-16 years) 
 Age of appearance  Fusion  
Capitulum 01 year Centres of Capitulum, Medial 
epicondyle and Trochlea unite at 
14 years & form conjoined 
epiphysis, which unites with 
Humerous shaft at 16 years  
Trochlea  10 years  
Lateral epicondyle  11 years  
Medial epicondyle   05 years  16 years  
Head of radius  05 years  16 years  
Upper end of ulna / 
Olecranon 
9 years  16 years  
 
 

137 
 
Wrist Joint (X-ray AP view – age group 18-19 years) 
 Age of appearance  Fusion  
Lower end of radius  02 years 18 to 19 years 
Lower end of ulna 06 years 17 to 18 years 
Base of I Metacarpal  02 to 03 years  15 to 17 years 
Heads of other metacarpals 1 ½ to 2 ½ years  15 to 19 years 
Phalanges   15 to 18 years  
Capitate  02 months of life Nil  
Hamate  03 months of life  Nil 
Triquetral  03 years  Nil 
Trapezoid, Scaphoid 04 to 05 years  Nil 
Trapezium  06 years  Nil 
Pisiform  09 to 11 years  Nil 
 
Knee & Ankle Joint (X-ray AP view& lateral view – age group 18-19 years) 
 Age of appearance   Fusion  
Lower end of femur 09 months of I.U.L.  18 to 19 years 
Upper end of tibia 01 year 18 to 19 years 
Upper end of fibula 01 year 18 to 19 years 
Patella   14 years (single bone) 
Lower end of tibia 01 years 16 to 17 years  
Lower end of fibula 04 years 16 to 17 years 
Calcaneum  06 to 08 years 14 to 16 years 
 
Later years  : 
X ray of lateral view of sternum to view fusion of 137ntuss elements and X rays 
of Skull to view suture closure patterns are to be used. 
Sternum: 
Sternum has ossification centres since birth, which unite from downward to upwards 
direction, The third and fourth parts of the sternum (sternebrae) unite at the age of 
15years while the second and third unite at 20 years. 
The first and second parts of sternum unite at 25 years. 
Tip of Xiphoid process appears at 3 years and unites at 40years. 
Suture closure:  
Sagittal suture – Posterior 1/3
rd
 by 30 to 40 years, Anterior 1/3
rd
 by 40 to 50 years, 
Middle 1/3
rd
 by 50 to 60 years; 
Lambdoid suture – Upper ½ by 50 to 60 years, Lower ½ by 60 to 70 years; 
Coronal suture – Upper half by 40 to 50 years, Lower half by 30 to 40 years.  
 
 
 

138 
 
Factories Act, 1948; Tamilnadu Factories Rules, 1950 (G.O. (Ms). No. 27 Labour and Employment 
(M2) Department, dt: 27.03.2002) 
 
Certifying Surgeon  Local Limit  
Assistant Surgeon in the Office of the Deputy Chief 
Inspector of Factories (Testing and Safety), 
Chennai. 
 
 
Assistant Surgeon in the Office of the Deputy Chief 
Inspector of Factories (Testing and Safety), Vellore. 
 
Assistant Surgeon in the Office of the Deputy Chief 
Inspector of Factories (Testing and Safety), 
Cuddalore. 
 
Assistant Surgeon in the Office of the Deputy Chief 
Inspector of Factories (Testing and Safety), Salem 
 
Assistant Surgeon in the Office of the Deputy Chief 
Inspector of Factories (Testing and Safety), 
Coimbatore. 
 
Assistant Surgeon in the Office of the Deputy Chief 
Inspector of Factories (Testing and Safety), Trichy. 
 
 
 
Assistant Surgeon in the Office of the Deputy Chief 
Inspector of Factories, Sivakasi 
 
 
Assistant Surgeon in the Office of the Deputy Chief 
Inspector of Factories Tirunelveli 
 
Chief Medical Officer-in-Charge of Bharath Heavy 
Electricals Ltd., Tiruchirapalli. 
 
 
Divisional Medical Officer-in- Charge of Southern 
Railway Hospitals 
 
The Medical Officers of the Heavy Vehicles Factory 
Hospital, Avadi. 
 
The Medical Officers of the Cordite Factory, 
Aravankadu, The Nilgiris. 
Entire Chennai Corporation, divisions, 
and Tiruvallur district and 
Kancheepuram district. 
 
 
Entire Vellore district and Tiruvannamalai 
district. 
 
Entire Villupuram district and Cuddalore 
district. 
 
 
Entire Salem, Namakkal, Dharmapuri and 
Erode districts. 
 
Entire Coimbatore and Nilgiris districts. 
 
 
 
Entire Trichy, Thanjavur, Tiruvarur, 
Pudukkottai, Perambalur, Ariyalur, Karur 
and Nagapattinam districts. 
 
 
Entire Madurai, Dindigul, Theni, 
Virudhunagar, Ramanathapuram and 
Sivagangai districts. 
 
Entire Tirunelveli, Thoothukudi and 
Kanyakumari districts. 
 
In respect of the factories under the 
management of Bharath Heavy Electricals 
Limited, Tiruchirapalli. 
 
In respect of Southern Railway 
Workshops including Integral Coach Factory, Chennai. 
 
In respect of Heavy Vehicles Factory, Avadi, 
Chennai-54. 
 
In respect of Cordite Factory, 
Aravankadu, The Nilgiris district. 
 
 
 
 
 
 
 

139 
 
Medl. I-28 
Post Mortem Serial Number:                  
Date:        
1. This form is intended for use only in medico legal cases. The Medical Officer conducting the autopsy may 
dictate rough notes as the examination proceeds, which may be entered in copying pencil in this loose form by 
his assistant. The Medical Officer should sign the loose form after satisfying himself that the entries are 
correctly made and should make the Post Mortem Examination certificate ready in the Format Medl. I. 29.  
The loose form (Medical-I-28) should be considered as the original document liable to be produced in Judicial 
Courts as evidence on proof of the correctness of the entries made in the post mortem certificates. No 
additions should be made to it later. 
2. Medical Officer conducting Post Mortem Examinations should go through Paragraphs 399 to 410 and 
Paragraphs 591 and 592 of the Madras Civil Code (Code 1). 
 
3. The printed matter indicates the Principle, morbid appearances and is a guide and refresher to memory. It is 
not to be considered complete and detailed. The measurements and weights are from European sources and 
are perhaps higher than the average for our country. In recording appearances both positive and negative 
findings would be of value. 
 
4. Attention is invited to the Surgeon – General’s Circular No: 39 of the 7
th
 July 1914, regarding the 
responsibility of Senior Medical Officers in Station towards autopsies. 
 
Station & Crime No: 
 
Section: 
 
In charge of body: 
 
 
 
Post Mortem Examination 
 
ON THE BODY OF a male / female named 
 
 
Age     : 
 
 
Conducted by  : 
 
 
 
at      : 
 
on      : 
 
 
ORIGINAL to   :  
 
DUPLICATE to      : 
 
TRIPLICATE to     : 
             
 

140 
 
Notes from the requisition for a post mortem examination on the body of a male / female 
 
Named         
 
Aged about    Year     Months  Days   
 
Residence 
 
Caste:       Occupation: 
 
Approximate height   Feet:    Inches  New born averages 
         European (Jellet): 
Approximate breadth   inches     length 20 inches, 
         weight 8 lb, 8 oz to 7 lb. 
Approximate girth    inches     Indian (Lyons): 
         length 16 to 20 inches, 
Approximate weight   pounds    weight 4 lb, 5 oz to 7 lb. 
     
Identification marks: 
(1) 
 
(2) 
 
(3) 
 
(4) Tattoo marks and pattern 
 
(5) Caste marks: 
 
Found / Died  at        a.m. /  p.m. on       at 
 
sent by       with letter no. 
 
dated   in charge of Constable      No. 
 
Received at       a.m. /  p.m. on  at 
 
It is stated that the body found at     a.m. /  p.m. on 20 
 
It is stated that there was an interval of hours       State, if hanging, drowned 
         other posture in relation to 
         surrounding objects 
minutes between the last eating, drinking 
and the development of the symptoms which were: 
 
Vomiting         State the nature of vomitus 
Purging 
Loss of sensation 
Dilatation / contraction of pupils       
Unconsciousness 
Excitement 
Flushing of faeces 
 

141 
 
State parts affected and nature:    Twitching 
Tingling 
convulsions      Clonic  / tonic 
clutching at 
 
Delirium 
Paralysis 
 
Haemorrhages 
Bleaching of mouth    Colour 
Dryness or moistness of skin 
 
Collapse 
Suffocation 
Cyanosis (Lividity) 
Deep sleep 
Other persons partook of the same food, drink and exhibited 
(Symptoms) 
 
 
 
 
The following articles were also sent with the corpse: 
 
The purpose for which these  Clothes       Ornaments, Jewellery 
were sent and nature of     Excreta       Vomit 
examination to be conducted  Urine     Weapons 
 
Description of cuts, stains and 
number of cloths, etc.   
 
 
   Gas (from unused wells, cesspools, rooms, etc.) 
     
   Is the body decomposed or otherwise 
 
   Short history of case in duplicate, if supplied or not. 
 
   Copy of history or case sheet from hospital or if treated outside sent or not 
 
   The body was reported to have been received in Mortuary at 
   on     through Police Constable No. 
 
   Further notes, if any (such as short notes from case sheets of hospital) 
   
    
 
      (Signature with designation) 
 
 
 

142 
 
Notes of Post Mortem Examination 
The body was first seen by the undersigned at    a.m. / p.m. on  If the body was see 
          before post mortem 
          examination, note time 
          and general conditions 
Its condition then was 
 
Examination was conducted by  (on dated) 
 
And it was began at place 
 
Name: Age:    Sex: 
 
Height:       Breadth:     Weight: 
 
 
Identification marks (as seen by the Medical Officer) 
 
(1) 
(2) 
(3) 
(4) 
(5) 
 
These do / do not agree with the identification marks given in the requisition 
 
 
Clothing: Say whether worn or not 
and how worn and describe 
 
 
Jewellery:  Whether worn or not 
marks left by them and describe 
 
Body identified by PC no: Name: 
 
 
 
 

143 
 
EXTERNAL EXAMINATION 
GENERAL SURVEY OF THE BODY: 
01. Condition of clothes         : 
 Dry, wet, stained etc 
02. Surroundings of the body      : 
03. Attitude of the body         : 
 Lies on back, arms close to sides, flexed at 
 elbows, forearm in pronation, supination, palm resting on trunk, 
 lower limbs extended, flexed, closed / apart 
04. Temperature of the body (with a thermometer)     :  
05. State of nutrition        : 
 Body is corpulent, stout, well nourished, emaciated, not muscular, 
 adipose depletion 
06. Symmetry of body       : 
 Proportion of head to body; unequal development of limbs; 
 atrophy of muscles (name them); deformities or losses. 
 Maldevelopments; distortion (ex. Rickets, osteomalacia) 
07. Colour of skin         : 
 Pale, purple or Lividity of face, neck and trunk, colour of mucosa 
 (oral, conjunctival, preputial, vaginal and anal). 
 Discolouration (pigmentation and decolouration: mention sites, 
 distribution and colour) albinism, leukoderma, leprosy, pityriasis, 
 chlorosis, jaundice, Addison’s patches 
08. (a) Colour of iris: 
 
     (b) Colour of hair, length of hair, shaved or not 
 
 Head 
 Moustache        Beard 
 Armpits 
 Pubis 
09. Presence of visible diseases       : 
 Blisters, vesicles, eruptions or rash, scales, erysipelas, 
 thickening tumours, ulcers (oral, labial, cutaneous, anal), scars, 
 naevi, disease of hair. Mention site and nature. 
10. (a) Body is covered with blood, vernix caseosa, scarf skin   : 
11. (b) Scars and tattoo marks injuries       : 
 Describe them (vide sketch) 
  
 Injuries (Scratches, Ecchymosis, bruises, contusion, fracture, 
 dismemberment) – Location, direction, length, breadth, depth, margins, 
 tailing (examine  with lens, draw outline of injuries if possible) 
 bleeding or covered with clots or scab: probable age of injury, 
 foreign bodies in wounds, cuts on clothing correspond with body wounds. 
 Foreign bodies in natural passages (mention nature, size, weight etc) 
 Marks of rope around neck, injuries caused by sharp or blunt, heavy or  
 light weapons, self-inflicted or produced by fits (mention whether epileptic, 
 eclamptic or uremic) and those induced by drugs. 
 When injury to tongue by biting or to face by falling etc. Burns or scalds. 
 
 
 
 
 

144 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 

145 
 
12. Stains (Location, extent)        : 
 Blood, semen, vomit, faeces, mud, dust, grease, betel etc  
13. Signs of decomposition (in usual order)     : 
 Body warm, muscles relaxed and contractile, rigidly rigor mortis present 
 (parts), passed off (parts), eyeballs flaccid, flattening of points of support, 
 post mortem hypostasis (prove by pressure and incision and state and 
 area), Marks and livid blood vessels, green discolouration, odour, 
 softening of eyeballs, exudation from mouth and nose, ova of flies present, 
 moving maggots. Seep and blebs on back of legs, neck, sides of chest etc.  
 Peeling of cuticle, loosening of hair, thorax and abdomen burst, sutures of 
 skull opened, eye liquefied, saponification, mummification, damage by 
 wild animals, skeletonization. 
14. General appearances do or not tally the Police report     : 
15. Death would have occurred about so many hours or days  : 
HEAD FACE AND FORM OF BODY 
16. Head of new born (diameter: Jellet): 
 (a) Cervico bregmatic      : 7.66 cm  (8) 
 (b) Fronto mental    : 12.38 cm (12) 
 (c) Supra occipito mental    : 11.25 cm (11) 
 (d) Occipito mental   : 10.12 cm (10) 
 (e) Occipito frontal   :  
 (f) Sub occipito frontal      : 9 cm 
 (g) Sub occipito bregmatic    : 6.43 cm (6) 
 (h) Bitemporal      : 7.2 cm  (7) 
 (i) Biparietal        : 8.43 cm (8) 
Adult: (a) Sub occipito bregmatic     : 28.5 cm (29) 
 (b) Occipito frontal   : 30.93 cm (31) 
 (c) Supra occipito mental    : 32.40 cm (32) 
 (d) Cervico bregmatic      : 28.4 cm (29) 
17. Features         : 
 Symmetrical, contorted, calm, distorted, pale, livid, congested, swollen, 
 bloated, prominent veins of forehead, mutilated 
18. Scalp           : 
Loss of Hair, arrangement of hair, disorder of hair; oedema, tumours, 
caput succedaneum, haemorrhage, suppuration, depression, bossing 
19. Eyelids          : 
 Open, closed, bulged, gouged, arcus senilis; pupils: contracted, normal, 
 dilated. Eyelids: suffused, swollen, haemorrhage in angle of eye; 
 Horizontal, upturned, down turned. 
20. Nose           : 
 Broken, discharge of blood, frothy blood mucus, foreign body, polypus, 
 ulcers of septum 
21. Mouth and Lips        : 
 Froth, characteristic odour or discoloured staining. 
 Mucosa lining softened, destroyed, excoriated, herpes 
22. Tongue          : 
 Protruded between teeth, stained mucous surface, swollen, ulcer, 
 new growth 
23. Discharge of blood          : 
 Froth, frothy blood, putrid fluid etc. From mouth or nose or both. 
 Trail of saliva running down the chest, foreign body in mouth  
24. Jaws           : 
 Clenched; gums: blue, red; spongy, tumours, necrosis etc. 
25. Teeth           :  
 Complete number, broken, decayed, lost (mention the missing) tumour 

146 
 
26. Ear         : 
Discharge of pus, blood, fluid, foreign body, pierced lobes, recently torn 
27. Neck glands          : 
Enlarged, caseous; Situation 
28. Thorax          : 
 Shape (well formed); long and narrow (barrel shaped), pigeon breasted, 
 funnel breasted, ricketic rosary, difference between the sides, fracture or 
 diseases of ribs, cartilages. Tumours in thorax. 
29. Trunk: New born diameters (Jellet). 
 Shoulders bisacromial     : 9.9 cm  (10) 
 Sterno dorsal     : 8.85 cm (9) 
 Bi trochanteric    : 8.85 cm (9) 
 Bis iliac    : 8.43 cm (8) 
 Sacro iliac        : 4.95 cm (5) 
30. Mammary glands       : 
Development, hypertrophy, atrophy, tumours, cysts, primary areola, 
secondary areola(colour), stria alba 
31. Axillary glands         : 
Enlarged, length 
32. Abdomen         : 
Striae albicantes, linea nigra, caput medusa, distension (uniform or 
 unequal) walls, thick, thin, retracted walls (hernia; umbilicus healed; 
umbilical cord: demarcated, tied and adherent, fallen) 
33. Groin           : 
Glands enlarged; buboes, ulcers, undescended testis, tumours, scars. 
34. Generative organs      : 
Penis indrawn,shortened, development; urethral discharge, veneral sore, 
Circumcised or not; scars 
35. Scrotum         : 
(dimensions of genitalia) Elephantoid, hydrocele, testes enlarged. 
Labia: Hymen: presence or absence or torn fresh or old carunculae; 
Vagina: Discharge of blood, mucus, pus; ulcers; Fistula. 
Marks of violence; loose hairs (preserve stained hair and foreign bodies); 
EXTREMITIES 
36. Upper and Lower limbs       : 
Hands clenched, empty; contain straw, mud; extra digits – numbers; 
fingers flexed; marks of wedding ring on finger; stains; signs of work; 
stain, fracture, dislocation of nails or broken nails; blue or pale nails; sand, 
mud, foreign body under nails; over grown or pared nails; cholera fingers. 
Feet: Flat, inverted, oedematous, nodes, fracture dislocation, deformity, 
stains on soles, foreign bodies under nails. 
CENTERS OF OSSIFICATION 
(Casper & Tidy) 
37. New born  (Inferior epiphysis of femur is three lines in diameter)   : 
 Mention others if necessary 
INTERNAL EXAMINATION 
OPENING OF ABDOMEN (N.B.: Don’t tear through adhesions but out them) 
38. Abdomen        : 
Size, uniform, prominent or unequal; fat, Depth (cm); Colour; 
Retracted, distended, site of umbilicus; Muscles, Colour; 
Extravasation of blood in omentum spread etc. 

147 
 
39. Level of diaphragm         : 
 Right and Left domes, position of organs. Normal, adhesions, 
 enlargements, local inflammation, tumours. 
40. Peritoneal cavity       : 
 Fluid in ml, nature of fluid, turbid, blood stained, purulent, lymph, 
 flakes of fibrin. Peritoneum: adherent; Tubercles; Smears from 
 147ntussus in peritoneum 
 biology(Note: Organs to be merely examined this stage). 
OPENING OF THORAX 
41. Position and colour of organs: normal or abnormal  : 
 Fracture of ribs, pleura injected, surface roughened, flakes of fibrin, 
 effusion of blood fluid (ml), Lymph, old or recent adhesion, wound, spots 
 of haemorrhage on visceral or parietal surfaces (Tardieu’s spots), 
 Mediastinal haemorrhages etc. 
 Lungs borders meet or overlap or overlap on heart. 
42. Thymus         : 
 Size (length, breadth and thickness), weight; 
 section (Haemorrhage, Tubercle, Tumour) 
43. Pericardium          :  
Staining, inflamed, distended, fluid, amount (ml), 
character of inner surface (dark, rough, wounded, milk spots, 147ntussus- 
smear, spot of haemorrhage on visceral or parietal surface adhesions  
44. The Heart Weight 150-360 g        :  
Wound, rupture 
Right auricle and appendages (fluid blood-Light or dark, 
mixed clot, uniform clot, thrombus) 
Right ventricle (Fluid, clot, embolus, thrombus) 
Pulmonary artery (Clot, embolus, thrombus) 
Left auricle (fluid blood, clot, thrombus) 
Left ventricle (fluid blood, clot, thrombus, chambers dilated)        
Valvular rings, dilated or contracted. 
45. Valves and endocardium      : 
 Rigid, contracted, thickened, adherent, valves perforated, torn, vegetation, 
 puckered, atheromatous, 147ntussus tendinae, opaque, thickened, shortened, 
 broken. 
46. Coronary vessels       : 
Atheroma, emboli, thrombosis, brown hypertrophied, fatty Infiltration, 
fatty degeneration, abnormality other diseases. 
47. The great vessels       : 
Aorta, vena-cava, pulmonary artery, pulmonary veins, iliac vessels, etc 
thrombosis, embolism, atheroma calcification, and aneurysm rupture. 
48. Blood (take blood smear for bacteriological Test)       : 
 General character – Dark cherry coloured, coagulated clot soft or firm, 
 layered, of uniform colour. Abnormally fluid 
49. Lungs (Normal lung 240 – 660 g, Average 540 to 480 g)    : 
 Colour, distended (marked by ribs & don’t collapse); dry, crepitant, soft 
 oedematous, congested, friable. Inelastic, emphysematous, collapsed 
 (atelectasis); lobules (swollen and shrunken), dark red, grey, firm, fragile, 
 soft, dry 147ntussus, frothy serum. 
 Pigmented adhesions, haemorrhage, infarction, pleurisy, patches if any, 
 shape – scars or tubercles on surface. 
 Section – dry granular, moist, on pressure extrudes blood (amount), 
 watery fluid, mucus, pus, secretion, blood, tenacious. 
 Air tubes reddened, thickened, dilated, narrow; grey yellow tubercle 
 or chalky mass.  
 Cavities, pigment, fibroid change, red or grey hepatisation, purulent material, 
 diffuse or circumscribed abscess gangrene, tumours, wound rupture, oedema, 
 haemorrhage, cut piece sink or float in water. 

148 
 
50. Larynx, Glottis, Trachea, bronchi     : 
Contain water, mud, vegetation (nature); 
mucosa: injected, swollen, stained, discoloured, oedematous, covered  
with froth, corrugated, leathery new growth, foreign body, loose or 
impacted, natural colour of mucosa. 
51. Hyoid bone (broken – describe fracture etc.)     : 
52. Thoracic duct (inflamed, obstructed, rupture etc.)      :  
53. Thyroid & parathyroid (Enlarged, firm, fibrous etc.)     : 
54. Stomach         : 
 Size, dilated, shrunken, distended with food or gas. 
 Outer surface: Vascular, fresh lymph, adherent, wound, rupture. 
 Contents: odour, colour, consistency, foreign particles, food 
 particles (nature and stage or digestion). 
 Inner surface – colour, injected, dilated and tortuous vessels, walls 
 oedematous & firm, hard; extravasation, effusion, embedded foreign 
 particles, atrophied ulcer (character of edge base, perforation) tumours etc. 
 Mucosa – anaemic, injected, inflamed, thick, soft, hard, eroded, 
 corrugated, leathery. 
55. Oesophagus – Length (25cms Grey)     : 
 Mucosa: Partly detached, easily stripped, soft, brittle, sodden, white, 
 brown, yellowish, charred structure, ulcer, new growth, impacted mass, 
 wound rupture, diverticula. 
56. Pancreas (Average weight – 60 to 180 g)       : 
 Weight, colour, consistency,  inflammation, abscess, tumour, fat necrosis. 
57. Liver (Weight – 1200 to 1800 g)        : 
Relations, adhesions, rupture, weight, enlarged, diminished, atrophied   
Capsule – thin, loose, wrinkled, adherent. 
Edges – Thick, thin, rounded, firm. 
Surface – smooth, shining, dull, nodulated, bands or red depressions. 
Colour – red, yellow, mottled, nutmeg, pigmented, brown pale chocolate, slaty. 
Consistency – soft, firm, flabby, tough, fleshy, greasy, friable, waxy, translucent. 
58. Gall Bladder          : 
 Full, empty, stones, inflamed, mucosa, thickened wall, contracted; 
 adherent, lymphatic glands under liver enlarged, malignant etc. 
 Section – colour, hyperaemic, nutmeg, granular, distended ducts, 
 embolism, hydatid, abscess, cuts with creaking noise on knife. 
 (Prussian blue reaction, amyloid reaction can be sent)  
59. Spleen (Size 13 x 9 x 4 cms, weight: 90 to 210 gm)   : 
Weight, colour, size, shape, large, small, notch (portion). 
Capsule – wrinkled, thick, adherent, perisplenitis (Iced spleen), rupture, wound. 
Consistency – firm, soft, wax, friable, abscess, infarcts, tubercle. 
Section – Trabeculae and vessels not easily seen, markedly visible, 
increased. Colour of cut surface – dry, moist, concave, convex. 
Outline of Malpighian bodies visible, enlarged. 
Consistency of section of pulp: easily, scraped with difficulty. 
Accessory spleen. 
60. Mesentery – cm long (Grey: 202 cms long)    :  
 Relations, fat, adhesions, injections, hypostasis, hernia, glands. 
 Swollen, caseous ulcerating tubercle, effusion of lymph, oedema. 
61. Kidneys (Weight 90 -180 gms in Female; 120-165 gms in Male)    :  
Size: 10 x 6 x 3 cm 
Weight:  Right     Left 
Larger, smaller, heavier, colour – red, pale mottled, translucent, purple 
pale, yellowish. Consistency – firm, flabby, position of ureter, abnormalities. 
Section – soft, firm, anaemic, hyperaemic, colour difference between 
cortex & medulla increased or diminished; narrow or dilated pelvis, 
peripelvis pyramids, calyxes, infarction, embolism in vessels. 
Capsule strips easily, partially adherent, very adherent, thick, and thin. 

149 
 
Surface of kidney – congested, pale, stellate veins markedly visible, 
cysts on surface, smooth, rough, granular, lobulated. 
62. Supra renal capsules        :  
 Size: 10 x 6 x 3 cm 
 Length 
 Breadth 
 Thickness 
 Weight 
 Accessory suprarenal 
 Abscess, cyst, rupture, wound, enlarged; irregular; firm, adherent; 
 Section: yellow, grey white cheesy, calcified. 
The Intestines 
63. Pylorus to ileo caecal valve (610 cms to 1057 cms (Grey))     :  
 Duodenum      2.5 cms 
 Jejunum   244 cms 
  Ileum    366 cms 
 Caecum   06 cms 
 Colon     56 cms – 152 cms 
 Ascending colon   13 cms 
 Transverse colon  51 cms 
 Descending colon  25 cms 
 Sigmoid colon    41 cms 
 Rectum    11 cms  - 12 cms 
64. Small intestine         : 
Outer surface injected, hypostasis, lymph, fibrin, adhesion, tubercle, tumour 
Contents – colour, quantity, consistency, food particles, foreign particles, 
parasites, bacteriological examination, if needed. 
Mucosa – injected, pale, atrophied, swollen pulpy, gangrenous, ulcerated 
(direction of ulcers), lymph follicles. 
Peyer’s patches, lymphatics, sloughing (size and shape of slough 
and ulcers), character margins of ulcers, impacted masses. 
Twisting 149ntussusceptions, contracted, strangulation, hernia, growth, 
diverticula. 
65. Appendix Length 2.5cms to 20 cms (Average 10 cms)    : 
 Position, length, thickness, inflammation abscess, atrophy. 
 Mucosa: inflamed, ulcerated, atrophied, tumour. 
 Contents: Faeces, colour, consistency, parasites, pus, foreign bodies, 
 stones. 
66. Large Intestine         : 
 Ileo caecal valve, 149ntussusceptions etc. 
 Caecum – position, mobility, thickened, inflamed, tubercle, tumour, stenosis, 
 dilatation, adhesions, pericoecal abscesses, mucosa: atrophied, inflamed; 
 tumour. Colon: sagging, dilation, flexures – normal in position, linking 
 sacculation, stenosis, injected, adhesion, fistulae; 
 Contents, colour, consistence, foreign particles, food particles, parasites; 
 mucosa: injected, inflamed, ulcers, slough, colour, extent, location (Describe) 
67. Bladder          : 
Contents (g), Urine – reaction; sugar, albumin, calculus, new growth, 
mucosa: inflamed, ulcers; muscle hypertrophied; 
prostate: enlarged tumour; seminal vesicle – tubercle etc. 
68. Uterus (Length: 6 cm, breadth: 5cm, Thickness: 2.5 cm Weight: 60 g (Grey),):  
 Menstruation, pregnancy, abortion, violence, wound, rupture, 
 foreign body, growth or other disease. 
69. Ovaries (Right and Left)         : 
 Size, adhesions, inflammation, enlargement, cyst, tumour, 
 corpus luteum. 
70. Pelvis           : 
 Fracture disarticulation, deformity. 

150 
 
71. OPENING OF THE HEAD         : 
 Soft parts: present, injury or inflammation. 
 Scalp – extravasation of blood beneath, caput succedaneum, 
 caul present. 
72. Bones          : 
Thick, thin, caries, depression, injury. 
N.B: Strip dura, examine for basal fracture, injury include separation of 
sutures, indentations, fracture. 
73. The Membranes        : 
 Sinuses full, empty, thrombosed, clotted; duramater, adherent, anaemic, 
 vascular; hypostasis, congested, inflamed; extravasation of blood 
 external or internal to dura or pia (amount, situation and extent); 
 adhesions (describe and sketch); 
 Arachnoid: dry, sticky, tubercular; 
 Cerebro spinal fluid volume, clearness, turbidity, blood staining; adhesions; 
 Air, haemorrhage etc. Lymph or pus present. 
74. Brain (Average M – 1440 gms; F – 1320 gms)    : 
 Convolutions, flattened; ventricles: full, empty, ventricular fluid (clear, turbid, 
 blood stained); Choroid plexus inflamed. 
 Substance: soft (reddish, yellow), firm, inflamed, abscess, softening, 
 tumour (site), haemorrhage (site), injury (site). 
 Brain vessels – Thickened atheroma (site), embolism (site), 
 thrombosis (site), rupture (site). 
75. Air cavities of skull – note findings     :  
76. Spinal Column          :  
Soft part: present, injury; 
Bones – injury, disease. 
Duramater – adherent, anaemic, vascular, hypostasis, tumour.  
Arachnoid – dry, sticky, tubercular  
Piamater – injected 
77. Atlas / Axis(Fracture subluxation)     :  
78. Spinal cord:Length   (M 43; F 41 cm); Weight (45 gms) 
 Soft, firm, vascular; injected, atrophied, semi translucent, narrow in parts 
 (where); nerve roots 
 
 
 
 
 
 
 
 
 
 

151 
 
 
 
 
 
 
 
 
 

152 
 
Tissues preserved for microscopic section. 
 
 
Materials sent for Bacteriological investigation. 
 
 
Following numbered and sealed as under and each labelled with a signed note of reference to this 
report are sent together with a sample of preservative in which they are preserved for chemical 
analysis – 
 
1. Stomach and contents 
2. Intestines and contents 
3. Sample of liver (not less than 500 gms)  
4. Kidney (half of each kidney) 
5. Sample of urine (100 ml at least)  
6. Brain  
7. Blood (10 ml) 
8. Preservative (nature and quantity not less than 100 ml) 
 
 
Post-mortem examination conducted at                           A.M / P.M                   on                       20 
   
Summary of opinion: 
The deceased would appear to have died of  
 
 
 
Dated      day       of     20 
 
   
        Signature with designation. 
 
Results of Bacteriological, Chemical examinations, Microscopic examinations etc 
 
 
Final opinion (in case it is reserved) 
 
Signature with designation. 
 
 
 

153 
 
Post-mortem certificate handed over to  
 
                                                  on                                                                  at (time) 
 
 
 
Inquest when held                                       Date                                              Time 
 
 
Summary of evidence at inquest: 
 
 
 
Question put by Police and answers given to them regarding the post-mortem examination – 
 
  
Magistrate inquiry (Chief points of evidence to be noted) 
 
 
Sessions – (Chief points of examination and cross examination) 
 
 
 
Judgement 
 
 
 
 
 
Others: 
 
 
 
 
 
 
 

154 
 
Forensic Science Laboratories: 
FSL Units Districts 
Attached 
Chennai 
Forensic Science Forensic House, 30-A, Kamarajar 
Salai, Mylapore, Chennai – 600004. 
044-28447771-5 
Toxicology, Biology, Serology 
DNA, Anthropology, Ballistics,  
Explosives, Excise, Narcotics, 
Prohibition, Physics, 
Chemistry, Documents, 
Photography, Computer 
forensics 
Chennai 
Chengalpet 
Kancheepuram 
Thiruvallur 
Coimbatore  
Regional Forensic Science Lab., 219, Race Course 
Road,  
Coimbatore - 641 018. 
0422-2220695 
Toxicology, Biology, Serology 
Excise, Narcotics, Prohibition,  
Computer forensics 
 
 
Coimbatore City / 
Dt. 
Erode 
Nilgiris 
Tiruppur City / 
Dt. 
Dharmapuri 
Old PDJ Court Building Opposite to Revenue 
Divisional Office, Dharmapuri-636701. 04342-263018 
Toxicology, Biology 
Narcotics, Prohibition 
 
Dharmapuri 
Krishnagiri 
Madurai  
Regional Forensic Science Lab., 
Madurai Medical College Campus, Collector‘s Office 
Road,  
Madurai – 625020. 
 0452-2531966 
Toxicology, Biology, Serology, 
DNA,  
Documents, Narcotics, 
Prohibition 
 
Dindigul  
Madurai City / 
Dt. 
Theni 
 
Ramanathapuram  
Regional Forensic Science Lab., 
Near Coast Guard Office, Master Plan Complex, 
Sethupathy Nagar, Ramanathapuram-623503. 04567-
230646 
Toxicology, Biology,  
Prohibition 
Ramanathpuram  
Sivagangai 
Virudhunagar 
Salem  
Regional Forensic Science Lab., 7 
Avvai Nagar, First Street, Jagiramma palayam, Salem-
636302.  
0427-2900457 
Toxicology, Biology 
Narcotics, Prohibition 
 
Namakkal 
Salem City / Dt. 
Thanjavur  
Regional Forensic Science Lab., 
Vallam Main Road,Pilliyarpatti,Thanjavur-613403. 
04362-264776 
Toxicology, Biology 
Narcotics, Prohibition 
Mayiladuthurai  
Nagapattinam 
Thanjavur 
Thiruvarur 
 
Trichy 
Regional Forensic Science Lab.,  
165/90 Thiru.Vi.Ka. Nagar (Behind GH), Puttur, Trichy 
– 620 017.  
0431-2423977 
Toxicology, Biology, Serology 
Narcotics, Prohibition 
 
Ariyalur  
Karur 
Perambalur 
Pudukkottai 
Trichy City / Dt. 
Tirunelveli 
Regional Forensic Science Lab., Court Building (Back 
Side), 
Tirunelveli-672011. 
0462-2572675 
Toxicology, Biology 
Narcotics, Prohibition 
 
Kanyakumari 
Tenkasi 
Thoothukudi 
Tirunelveli City / 
Dt. 
Vellore 
Regional Forensic Science Lab., 
Phase-3, Sathuvachary [Adjacent to TNHB Government 
Servant Rental Quarters], Vellore - 632 009. 
 0416-2253255 
Toxicology, Biology 
Narcotics, Prohibition 
Thiruvannamalai 
Tirupattur 
Ranipet 
Vellore 
Villupuram 
Regional Forensic Science Lab., 
Master Plan Complex, Behind Collectorate, Villupuram-
605602. 04146-224680 
Toxicology, Biology 
Narcotics, Prohibition 
Cuddalore 
Kallakurichi 
Villupuram 
 

155 
 
Serology Sample receiving RFSLs (Zone wise): 
(Lr. No. FSD / LQMS / 12 / 2024; 18.01.2024 – FSD, Chennai) 
 
FSL Zone Districts Attached 
Chennai 
Forensic Science Forensic House, 30-A, Kamarajar 
Salai, Mylapore,  
Chennai – 600004. 044-28447771-5 
fsddirector@gmail.com 
NORTH Chennai, Chengalpet, Cuddalore 
Kallakurichi, Kancheepuram,  
Thiruvallur, Thiruvannamalai, 
Tirupattur 
Ranipet, Vellore, Villupuram 
Coimbatore  
Regional Forensic Science Lab., 219, Race Course 
Road,  
Coimbatore - 641 018. 0422-2220695 
adrfslcbe@gmail.com 
WEST 
 
Coimbatore City / Dt. 
Dharmapuri, Erode 
Krishnagiri, Namakkal, Nilgiris 
Salem City / Dt, Tiruppur City / 
Dt. 
Madurai  
Regional Forensic Science Lab., 
Madurai Medical College Campus, Collector‘s Office 
Road,  
Madurai – 625020. 
 0452-2531966 adrfslmduAyahoo.co.in 
SOUTH 
 
Dindigul, Kanyakumari,  
Madurai City / Dt., Ramanathpuram, 
Sivagangai, Tenkasi, Theni, 
Thoothukudi, Tirunelveli City / Dt. 
Virudhunagar  
Trichy 
Regional Forensic Science Lab.,  
165/90 Thiru.Vi.Ka. Nagar (Behind GH), Puttur, Trichy 
– 620 017.  
0431-2423977 rfsltrichy@gmail.com 
EAST 
 
Ariyalur, Karur, Mayiladuthurai  
Nagapattinam, Perambalur, 
Pudukottai,  
Trichy City / Dt., Thanjavur, 
Thiruvarur 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 

156 
 
VISCERA IN POISONING CASES:  
Saturated Sodium Chloride solution is most commonly used preservative for chemical 
analysis; 
except in Heavy metals, Aconite, Vegetable poisons, Corrosive acids.  
Rectified Spirit (90%) is the ideal preservative of choice in all conditions, except 
Carbolic Acid, Carbon tetrachloride, Paraldehyde, Alcohol, Acetic Acid, Phosphorus, 
Kerosene.  
Preservative used should only come from Medical Stores, through Head of the 
Institution.  
It is advisable to rinse the inside of the glass vessels to be used for the viscera 
with preservative and then bottle and seal the sample. Avoid the possibility of 
contamination of dishes, gloves, etc., which might be carried over to the next case. 
Poisoning Viscera to be preserved 
All cases of poisoning 
 
Entire stomach & its contents / particles from 
mucus membrane  
Small intestine (30cm) and its contents 
Entire intestine in infants 
Liver (500g) 
Kidney(half of each kidney)  
Sample of preservative 
Alkaloids & Barbiturates  Urine 
Aconite & Digitalis / 
Cardiac  
Heart 
Alcohol Blood: 10 ml in 100 mg of Na F+ 20 mg of 
Potassium oxalate; 
CSF: 5 ml; Vitreous: 2 ml;  
Viscera can be preserved in saturated salt 
solution  
Barbiturates / inhaled 
poisons  
100 g of brain; Bile 
Cyanide 
 
Spleen,  
Blood in liquid paraffin 
One lung in air tight container 
Gaseous poisons  (CO, 
H
2
S) 
Lungs & Blood  
Heavy metals Long bones (Femur – 10 cm) 
Scalp hair with roots (15 to 20) 
Nail clippings (Spencer Wells forceps) 
Organo-phosphorus 
compound  
100 mg of cerebrum, 
Perinephric fat  
 
 
 
 
 

157 
 
Suspected Skin - 2.5 cm
2
 (with control skin) is preserved in injected poisons / 
venomous snake bite; 
Vitreous for chloroform, Lungs with Trachea ligated in nylon bag in inhaled poisons; 
Maggots in Barbiturates, cocaine (using isopropyl alcohol or 70% alcohol); 
Uterus and vagina for abortifacients can also be preserved; 
Preservative container is preferably glass bottle, never store in polyethylene / plastics.  
Collection methods: 
Blood from femoral and subclavian veins for alcohol estimation is more accurate; 
Urine – through supra pubic puncture; CSF – through Cisternal puncture. 
Hair, Bones, Nails, Earth (in exhumation) do not require preservative.  
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 

158 
 
P.M. No.                           Medl. I -30 (Civil medical form no 68) 
FORM TO REPORT POST-MORTEM EXAMINATIONS, 
TO BE USED WHEN FORWARDING VISCERA TO THE CHEMICAL EXAMINER 
From 
  
 
To 
 The Director / Deputy Director  
 Forensic Science Laboratory, 
       .......................................................       
       Dated .................................... 
.............................................................................................................................................................................................................................. 
Description of viscera forwarded for examination 
1. Stomach & its contents 
2. Intestine & its contents 
3. Liver & kidney 
4. Sample of preservative used 
.............................................................................................................................................................................................................................. 
Mode of packing      Copy of label attached to each article 
SEALED CARD BOARD BOX    YES 
 
Weight of parcel      Impression of seal 
.............................................................................................................................................................................................................................. 
Mode of dispatch   Date of dispatch   Date of receipt in 
Through P.C.      chemical examiner’s office 
 
Name:        
Station: 
............................................................................................................................................................................................................................... 
INFORMATION FURNISHED BY POLICE OR PRECIS OF CASE 
Name: ........................................................................................................................ 
Age:.............................. Sex: ............ 
Thana or Village .............................................................................................................. 
 
 

159 
 
History of case – Duplicate attached 
 
.............................................................................................................................................................................................................................. 
Date and hour of dispatch of body: 
Date & hour of autopsy:  
Name of Medical Officer by whom examination was actually done:  
 
Date of receipt: 
.............................................................................................................................................................................................................................. 
Appearance of the body: 
 Muscularity 
 Stout / Emaciated 
.............................................................................................................................................................................................................................. 
Special marks: 
 Scars / Tattooing 
 Amount of hair, etc. 
 
.............................................................................................................................................................................................................................. 
Signs of decomposition 
 
.............................................................................................................................................................................................................................. 
Wounds & bruises: 
Position, Character and Size 
........................................................................................................................................................................................................................... 
.............................................................................................................................................................................................................................. 
.............................................................................................................................................................................................................................. 
.............................................................................................................................................................................................................................. 
.............................................................................................................................................................................................................................. 
State of natural orifices: 
 Eye 
 Ears 
 Nostrils 
 Mouth 
 Vagina 

160 
 
 Anus 
 Urethra 
.............................................................................................................................................................................................................................. 
State of limbs: 
 Rigor mortis 
 Position 
 Contents in hands, if clenched 
Other: Relaxed or Contracted limbs 
Eyelids  
Pupils 
Contents of mouth 
Position of tongue 
State of teeth 
.............................................................................................................................................................................................................................. 
Thorax: 
 Ribs    Cartilage 
 Pleura      Pericardium 
Heart:        Shape and appearance 
    Cavities 
    Clots – Ante or Post Mortem 
    Muscular structure 
Vessels:      Clots; Aneurysm; Atheroma 
Lungs:       Appearance  Colour 
    Consistency 
    Adhesions 
Larynx, trachea and bronchi for foreign bodies of diseases 
Hyoid bone 
.............................................................................................................................................................................................................................. 
Abdomen: 
 Peritoneum Peritoneal cavity & its contents 
 Liver & gall bladder – form, size, any disease or injury 
 Pancreas & Spleen: disease or injury   
Kidney: 
Stomach:     Size and general appearance 
    Coat appearance & Mucosa 
    General appearance & Contents  
Intestines:  General appearance 
Mucosa & Coat; Contents 
.............................................................................................................................................................................................................................. 

161 
 
Generative organs: Bladder & its contents: 
Uterus: appearance, size & its contents 
Vagina: 
.............................................................................................................................................................................................................................. 
Head:  
Scalp 
Bones (disease or injury) 
Membranes & Brain substance & ventricles 
Base of skull: fractures, caries, extravasations, etc. 
.............................................................................................................................................................................................................................. 
SPINAL CANAL 
(need not be examined, unless any indication of disease or injury exists) 
 
.............................................................................................................................................................................................................................. 
Fractures & dislocations 
 
..............................................................................................................................................................................................................................
...More detailed description of injuries or disease 
 
 
.............................................................................................................................................................................................................................. 
OPINION AS TO CAUSE OF DEATH: 
 
 
 
 
Station & Date:       
(Signature with designation) 
 
 
 
 
 

162 
 
Medl. I-30(a) 
DEPARTMENT OF FORENSIC MEDICINE & TOXICOLOGY 
I. P.M. No.   Dated: 
Stomach and contents in 400 ml of rectified spirit / saturated saline / ................................. 
Station & Crime no: 
Age & Name of alleged: 
Date:         (Signature with designation) 
.............................................................................................................................................................................................................................. 
 
DEPARTMENT OF FORENSIC MEDICINE & TOXICOLOGY 
II. P.M. No.   Dated: 
Intestine& its contents in 400 ml of rectified spirit / saturated saline / ................................. 
Station & Crime no: 
Age & Name of alleged: 
Date:         (Signature with designation) 
................................................................................................................................................................................................................................. 
 
DEPARTMENT OF FORENSIC MEDICINE & TOXICOLOGY 
III. P.M. No.   Dated: 
Liver & Kidneys in 400 ml of rectified spirit / saturated saline / ................................. 
Station & Crime no: 
Age & Name of alleged: 
Date:         (Signature with designation) 
................................................................................................................................................................................................................................. 
 
DEPARTMENT OF FORENSIC MEDICINE & TOXICOLOGY 
IV. P.M. No.  Dated: 
Sample of preservative – rectified spirit / saturated saline / ................................. 
Station & Crime no: 
Age & Name of alleged: 
Date:         (Signature with designation) 
..............................................................................................................................................................................................................................
... 

163 
 
Medl. I-30(d) 
FSL SAMPLE FORWARDING FORM 
 
From 
Police Surgeon and Professor of Forensic Medicine, 
......................................Medical College, 
.................................................................. 
 
To 
Director and Chemical examiner to the Government of Tamilnadu /  
Deputy Director and Assistant Chemical examiner to the Govt of Tamilnadu, 
Forensic Science Laboratory ................. 
 
Sir / Madam, 
 I have the honour to forward herewith, a sealed packet, containing the 
following for favour of examination for the presence of Semen, or Spermatozoa and 
Gonococci or Ducrev’s Bacillus from a case of alleged.  
 
P.M. No   :            Date   :   
 
Name  :               Alleged Age   :     Sex   :  
 
Station & Crime number : 
 
Nature of samples      :         Nos   :  
 
 
 
 
 
Test required  :  
 
Sample seal impression  :  
                                                                                                                             
Yours faithfully, 
 
                                                               
Police Surgeon and Professor of Forensic Medicine 
      ....................................... Medical College............................... 
           ....................................... 
 
Copy forwarded to the Deputy Commissioner / Superintendent of Police;  
Crime / ............. Branch of Police, for favour of providing the Chemical Examiner 
with the necessary requisites. Requisition for examination in this case was received 
from the Sub inspector of Police,                   Station, Chennai, with 
his Letter No.       Dated          20        his station crime No:  
Sent though P.C. No:  

164 
 
Medl. I-30(b) 
HISTOPATHOLOGY SAMPLE FORWARDING FORM 
 
From 
Police Surgeon and Professor of Forensic Medicine, 
......................................Medical College, 
.................................................................. 
 
To 
Professor of Pathology, 
 ......................................Medical College, 
.................................................................. 
 
 
Sir / Madam, 
 I request you kindly to do histopathological examination on the following bits 
of tissues removed from one of our autopsies.  
 
P.M. No   :          Date   :   
 
Name  :                          Alleged Age :     Sex:  
 
Station & Crime number : 
 
Nature of samples      :      Nos:  
 
 
 
 
 
Autopsy findings: 
 
 
 
 
 
 
Yours faithfully, 
 
                                                               
Police Surgeon and Professor of Forensic Medicine 
      ....................................... Medical College............................... 
           ....................................... 
 
History of the case & F.I.R. sent through P.C. No:  
 
 

165 
 
MODEL POST MORTEM REPORT FORM 
(Death in Police custody / during Police action / jail) 
 
Name of Institution ---------------------------------------------------------  
  
Post Mortem Report No ------------------------------------- Date---------  
 
Conducted by     Dr------------------------------------------------------------  
 
Date & Time of receipt of body & Inquest papers for Autopsy ----------------------------- 
(Requisition time) 
 
Date and Time of Commencement of Autopsy ------------------------------------------------------- 
 
Time of Completion of Autopsy ---------------------------------------------  
 
Date and Time of examination of the dead body at Inquest (as per Inquest 
Report) -------------------------  
 
Name and address of the person video recording the Autopsy---------------------------------
------------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------------ 
Note:The tape should be duly sealed, signed and dated and sent to the National 
Human Rights Commission, Sardar Patel Bhawan, Sansad Marg, New Delhi.  
-------------------------------------------------------------------------------  
 
Case Particulars  
1. (a) Name of deceased as entered in the Jail or Police record 
     
    ------------------------------------------------  
(b) S/O, D/O, W/O  -----------------------------------------------  
(c) Address    ---------------------------------------------------------------------------------------- 
    ---------------------------------------------------------------------------------------- 
 
2. Age (Approx.): ----------------- Years; Sex: Male / Female / Others 
 
3. Body brought by (Name and rank of Police Officials)  
(i) ---------------------------------------------------  
(ii) ---------------------------------------------------  
of Police Station -----------------------------------------  
 
4. Identified by (Names and Addresses of relatives/persons acquainted)  
(i) ------------------------------------------------------  
(ii) ------------------------------------------------------  
 
 
 
 

166 
 
HOSPITAL DEAD BODIES – (Particulars as per hospital records)  
Date and time of Admission in Hospital    ------------------------------------  
Date and time of Death in Hospital   ------------------------------------  
Central Registration No. Of Hospital   ------------------------------------  
SCHEDULE OF OBSERVATIONS: 
A. General  
(1) Height ------------------- Cms  
 
(2) Weight ---------------------Kgs  
 
(3) Physique – (a) Lean / Medium / Obese   
                     (b) Well-built / Average built / Poor–built / Emaciated  
 
(4) Identification features (if body is unidentified) 
 
(i) -------------------------------------------------------  
(ii) ---------------------------------------------------  
(iii) Finger prints be taken on separate sheet and attached by the Doctor  
 
(5) Description of clothes worn – important features.  
 
 
 
 
(6) Post-mortem changes:  
(a) As seen during inquest:  
- Whether rigor mortis present --------------------------------  
- Temperature (Rectal)    --------------------------------  
- Others       --------------------------------  
 
(b) As seen at Autopsy-  
 
(7) 
(a) External general appearance 
(b) State of eyes  
(c) Natural orifices  
 
B. External Injuries:  
Instructions:-  
(i) Injuries be given serial number and mark similarly on the body diagrams 
attached.  
(ii) In stab injuries, mention state angles, margins direction inside body  
(iii) In fire arm injuries, mention about effects of fire also  
(Mention Type, Shape, Length X Breadth & Depth of each injury and its relation 
to important body landmark. Indicate which injuries are fresh and which are old 
and their duration).  
-------------------------------------------------------------------------------  
 

167 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 

168 
 
                       
 
 
 
 
 
 
 
 
 

169 
 
Internal Examination  
1. HEAD  
(a) Scalp Findings  
 
 
(b) Skull (Describe fractures here & show them on body diagram enclosed)  
 
 
 
 
(c) Meninges, meningeal spaces & Cerebral Vessels  
(Haemorrhage & its locations, abnormal smell etc. Be noted)  
 
 
(d) Brain findings & Weight (Weight ------------ gms)  
 
 
 
 
(e) Orbital, nasal & aural cavities –findings 
 
2. NECK  
- Mouth, Tongue & Pharynx  
- Larynx & Vocal cords  
- Condition of neck tissues  
-Thyroid & other cartilage conditions  
-Trachea  
 
3. CHEST  
- Ribs and Chest wall  
- Oesophagus  
- Trachea & Bronchial Tree  
- Pleural Cavities     -R-      -L-  
 Lungs findings & Weight      - Right -------------- gms  Left ------------gms.  
 
- Pericardial Sac  
- Heart findings & Weight  
- Large blood vessels  
 
4. ABDOMEN  
- Condition of abdominal wall  
- Peritoneum and Peritoneal cavity  
 
- Stomach (wall condition, contents & smell) (Weight ---------- gms)  
 
 
- Small intestines including appendix  
 

170 
 
- Large intestines & Mesenteric vessels  
 
- Liver including gall bladder (Weight ------------- gms)  
 
- Spleen (Weight ------------- gms)  
 
- Pancreas  
 
- Kidneys finding & Weight Right ------------ gms & Left ------ gms   
 
- Bladder & Urethra  
 
- Pelvic cavity tissues  
 
- Pelvic Bones   
 
- Genital organs (Note the condition of vagina, scrotum, presence of foreign body, 
presence of foetus, semen or any other fluid, and contusion, abrasion in and 
around genital organs) 
 
 
SPINAL COLUMN & SPINAL CORD (TO BE OPENED WHERE INDICATED)  
 
 
 
 
 
 
 
OPINION  
(i) Probable time since death (keep all factors including observations at inquest) 
 
 
(ii) Cause and manner of death – 
The cause of death to the best of my knowledge and belief is:-  
Immediate cause –  
(b) Due to-  
(c) Which of the injuries are ante mortem/post-mortem and duration if ante 
mortem?  
(d) Manner of causation of injuries.  
(e) Whether injuries (individually or collectively) are sufficient to  
cause death in ordinary course of nature or not?  
 
(iii) Any other 

171 
 
SPECIMENS COLLECTED & HANDED OVER (PLEASE TICK)  
Viscera (Stomach with contents, small intestine with contents, sample liver, kidney 
(one half of each), spleen, sample of blood on gauze piece (dried),  
any other viscera, Preservative used)  
 
(b) Clothes  
 
(c) Photographs (video cassettes in case of custody deaths, Finger print etc.)  
 
(d) Foreign body (like bullet, ligature etc.)  
 
(e) Sample of preservative in cases of poisoning.  
 
(f) Sample of seal  
 
(g) Inquest papers (mention total numbers & initial them)  
 
(h) Slides from vagina, semen or any other material.  
 
 
Dead body, clothing and other articles (mention there)  
 
Duly sealed (Nos.-------) handed over to Police official  
 
No   ----------------------- of PS  ----------------------------------------  
 
whose signatures are herewith ---------------------------------------------  
 
PM report in original (number of pages) 
 
Duly sealed (Nos.-------) handed over to 
 
 
 
 
Signature     -------------------------------  
 
Name of Medical Officer -------------------------------  
(in block letters)  
 
Designation    -------------------------------  
 
 
 
  

172 
 
APPENDIX – ‘A’  
INSTRUCTIONS TO BE FOLLOWED CAREFULLY FOR DETENTION OF TORTURE 
 
Sl. No.  Torture Technique  Physical Findings  
Beating  
1  General  Scars, Bruises, Lacerations, 
Multiple fractures at different 
stages of healing, especially in 
unusual locations, which have 
not been medically treated  
2  To the soles of the feet, or 
fractures of the bones of the feet 
Haemorrhage in the soft tissues 
of the soles of the feet in 
ankles Aseptic necrosis.  
3  With the palms on both ears 
simultaneously  
Ruptured or Scarred tympanic 
membranes, injuries to external 
ear  
4  On the abdomen, while lying on 
a table with the upper half of 
the body unsupported  
(“operating table”)  
Bruises on the abdomen. 
Back injuries. 
Ruptured abdominal viscera  
5  On the head  
Haematomas.  
Cerebral cortical atrophy. Scars, 
skull fractures. Bruises.  
Suspension 
6  By the wrists  Bruises scars about the wrists. 
Joint injuries. 
7  By the arms or neck  Bruises or Scars at the site of 
binding. Prominent Lividity in 
the lower extremities.  
8  By the ankles  Bruises or scars about the 
ankles. Joint injuries. 
9  Head down, from a horizontal 
pole placed under the knees with 
the wrists bound to the ‘Jack’  
Bruises or scars on the 
anterior aspect of forearms and 
backs of the knees. Marks on 
the wrists and ankles . 
Near Suffocation 
 
10.  
Forced immersion of head in 
often contaminated “wet 
submarine”.  
Faecal material or other debris 
in the mouth pharynx, trachea, 
oesophagus, Lungs, Intro-
thoracic petechiae.  
11  Tying of a plastic bag over the 
head ( “dry submarine”)  
Intro – thoracic petechiae  
Sexual abuse  
12  Sexual abuse  Sexually Transmitted Diseases. 
Pregnancy. Injuries to breasts 
external genitalia, vagina, anus 

173 
 
or rectum. 
Forced posture 
13  Prolonged standing  Dependent oedema, Petechiae 
in low extremities  
14  Forced straddling of a bar (“Saw 
horse”)  
Perineal or Scrotal haematomas 
Electric shock  
15  Cattle prod  Burns, appearance depends on 
the age of the injury. 
Immediately: spots, vesicles, 
and /or black exudates. 
Within a few weeks: circular, 
reddish macular scars. 
After several months: small, 
white, reddish or brown spots 
resembling telangiectasia.  
16  Wires connected to a source of 
electricity  
 
17  Heated metal skewer inserted into 
the anus  
Peri-anal or rectal burns  
Miscellaneous  
18  Dehydration  Vitreous humour electrolyte 
abnormalities.  
19 Animal bites (spiders, insects, rats, mice, 
dogs). 
Bite marks 
 
 
 
 
 
 
 
 
 

174 
 
CERTIFICATE of production of ELECTRONIC EVIDENCE


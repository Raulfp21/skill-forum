# part since the incident of sexual violence

## Introduction

part since the incident of sexual violence   
16. General Physical Examination:  
Is this the first examination   
Pulse     BP     Temp   
Resp. Rate     Pupils       
Any observation in terms of general physical wellbeing of the survivor   
 
17. Systemic examination: 
Central Nervous System   :       
Cardio Vascular System    :       
Respiratory System   :        
Chest      :          
Abdomen    :        
18. Examination for injuries on the body, if any: 
The pattern of injuries sustained during an incident of sexual violence may show considerable 
variation. This may range from complete absence of injuries (more frequently) to grievous 
injuries (very rare). 
(Look for bruises, physical torture injuries, nail abrasions, teeth bite marks, cuts, lacerations, 
fracture, tenderness, any other injury, boils, lesions, discharge specially on the scalp, face, 
neck, shoulders, breast, wrists, forearms, medial aspect of upper arms, thighs and buttocks). 
Note the Injury type, site, size, shape, colour, swelling signs of healing simple/grievous, 
dimensions.) 
 
Scalp examination for areas of tenderness 
(hair pulled out / dragged by hair) / 
Extraneous matter  
 
Facial bone injury, orbital blackening, 
tenderness 
 
 
Petechial haemorrhage in eyes and other 
places 
 
 
Lips and buccal mucosa / gums  
 

198 
 
 
 
19. Sample Collection of Forensic Science Laboratory: Clothing evidence, where available – (to 
be packed in separate paper bags after air drying -in envelope labelled step 3A and 3B) 
 
Behind the ears, ear drum   
 
Neck, shoulders and breast   
 
Upper limb   
 
Inner aspect of upper arms   
 
Inner aspect of thighs 
 
 
Lower limb and buttocks  
 

199 
 
 
 
20. Collection of Debris / Stains / Nails / swabs (In envelope labelled step 4A, 4B, 4C, 4D, 4E and 
4F) 
Steps  Evidence Material   Collected (Y) /Not 
Collected (N) 
Reason for not 
collecting 
4A  Head hair combing (debris)    
4B  In between fingers (debris)    
4C  Swabs from stains on body 
(blood, semen, foreign material, others) 
  
4D Nail scrapings (both hands separately)     
4E Nail clippings (both hands separately)    
4F Scalp hair (10 to15 strands)   
 
 

200 
 
21. Breast examination: (In envelope labelled step 5) 
Steps  Evidence Material   Collected (Y) /Not 
Collected (N) 
Reason for not 
collecting 
5 Swab from each breast (two swabs)    
 
22. Local examination of genital parts / other orifices: External genitalia: Record findings and state 
NA where no applicable:  
Body part to be examined  Findings 
Urethral meatus & vestibule   
Labia majora    
Labia minora  
Fourchette & Introitus   
Hymen & Perineum   
External urethral meatus  
 
23. Genital evidence (In envelope labelled step 6A, 6B and 6C) 
Steps  Evidence Material   Collected (Y) /Not 
Collected (N) 
Reason for not 
collecting 
6A Pubic hair combing (mention if shaved)    
6B  Cut strands of pubic hair (mention if shaved)    
6C  Cut strands of matted pubic hair     
 
24. Cervical, Vaginal and Urethral swabs (In envelope labelled step 7A, 7B, 7C and 7D) 
Per-vaginum, per-speculum examination should not be done unless required for detection of 
injuries or for medical treatment.   
Steps  Evidence Material   Collected (Y) /Not 
Collected (N) 
Reason for not 
collecting 
7A Two Cervical swabs and two slides  
(for semen examination and DNA testing) 
  
7B  Two Vaginal swabs and two slides  
(for semen examination and DNA testing) 
  
7C      Two Urethral swabs and two slides  
(for semen examination and DNA testing) 
  
7D Any other (tampon / sanitary napkin / condom /object)   
 
pv findings, if performed    
ps findings, if performed   
Reason if pv / ps examination not performed     
 
25. Cervical Swab - Culture for infection (In envelope labelledstep8) 
26. Washings from vagina (In envelope labelled step 9) 
  Collected (Y) /Not Collected (N) Reason for not collecting 
9 Vaginal washing    
 
27. Anus and Rectum (In envelope labelled step 10A and 10B) 
Bleeding / tear / discharge / oedema / tenderness (Encircle the relevant)  
Steps  Evidence Material   Collected (Y) /Not 
Collected (N) 
Reason for not 
collecting 
10A Two Anal swabs and two slides  
(for semen examination and DNA testing) 
  
10B Two Rectal swabs and two slides  
(for semen examination and DNA testing) 
  
 

201 
 
28. Oral cavity (In envelope labelled step 11A and 11B)Bleeding / tear / discharge / oedema / 
tenderness (Encircle the relevant)  
Steps  Evidence Material   Collected (Y) /Not 
Collected (N) 
Reason for not 
collecting 
11A Two Oral swabs and two slides  
(for semen examination and DNA testing) 
  
11B One dental floss    
 
29. Blood collection (In envelope labelled step 12A, 12B, 12C and 12D) 
Steps  Evidence Material   Collected (Y) /Not 
Collected (N) 
Reason for not 
collecting 
12A Blood grouping, testing for drug / alcohol intoxication  
(plain vial) 
  
12B Blood for alcohol levels (Sodium fluoride vial)   
12C Blood for DNA analysis (DNA card and gauze cloth)   
12D Blood for HIV, VDRL, HbsAg (EDTA vial)   
 
30. Urine collection (In envelope labelled step 13A, and 13B) 
Steps  Evidence Material   Collected (Y) /Not 
Collected (N) 
Reason for not 
collecting 
13A Urine test for pregnancy    
13B Urine (drug testing)    
 
31. Other relevant tests ordered (indicate the relevant option) 
a) Ultrasound for pregnancy/internal injury – Yes/No; b) X-ray for Injury – Yes/No 
*Samples to be preserved as directed till handed over to Police along with duly attested 
sample seal. 
 
32. Treatment prescribed: 
Treatment Yes No Comments 
STI prevention     
Emergency contraception     
Wound treatment     
Tetanus prophylaxis    
Hepatitis B vaccination    
Post exposure prophylaxis for HIV    
Counselling    
Other    
 
 
33. Date and time of completion of examination:  
Report contains     number of sheets and    number of envelopes.  
 
OPINION:  
 
Station         Signature 
Date       Name 
Time          Reg. No 
Designation      Office seal  

202 
 
FINAL OPINION (After receiving lab reports):  
 
 
 
 
Station         Signature 
Date       Name 
Time          Reg. No 
Designation      Office seal 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 

203 
 
GOVERNMENT ......................................................................... HOSPITAL, 
............................................................................................. 
CERTIFICATE OF SEXUAL ASSAULT – ACCUSED PERSON EXAMINATION 
(S.O. Case No: ..................................................) 
Regarding examination of accused of sexual offence with reference to      P.S. Cr. 
No:  u / s       
Requisition for examination was received from     
at     A.M. / P.M. on     at           College / Hospital, 
  
Person was first seen by the undersigned at     A.M. / P.M. on   
Medical examination was commenced at      A.M. / P.M. on   
One Tr.          of alleged age   
accompanied by    
  
With identification marks:   
 
Consent: 
 
Following were found during examination: 
 
 
OPINION:  
Possibility of performance of sexual intercourse i.e., of vaginal/anal/urethral/oral penetration 
by the male sex organ cannot be excluded. 
No definite opinion can be given as to whether the alleged accused had performed any 
recent sexual intercourse in the ordinary way and there is nothing to suspect about his 
potency. 
Incapable of performing sexual intercourse in the ordinary way due to ................................. 
(temporary / permanent cause). 
 
Signature with Name & Designation 
Station & Date     :      
Original      :  
Duplicate    :         (Office seal)  

204 
 
O/o THE POLICE SURGEON & DEPARTMENT OF FORENSIC MEDICINE. 
GOVERNMENT ............................... COLLEGE, ................................................ 
TOXICITY CERTIFICATE No:                   ; dt.                  . 
Certificate regarding toxicity of substances seized with respect to    P.S, Cr. 
No:    u/s    
vide Forensic Science Lab Report  
Requisition for opinion as to toxicity of the substances was received from the Inspector of 
Police,       P.S, at     AM / PM on      
Opinion of the undersigned is as follows: 
Substance       is a        compound. 
Effects of it on human body are:  
 
 
 
 
 
 
 
 
 
 
 
 
 
 
        Signature with Name & Designation 
Station  :  
Date   : 
Office seal  :  

205 
 
PROFORMA FOR HEALTH SCREENING OF PRISONERS ON ADMISSION TO PRISON 
Case No. .............................................................................................................................................................................................................  
Name .................................. Age .............. Sex ............. Thumb impression  
Father’s / Husband’s Name .............................................................................. Occupation ..............................................  
Date & Time of admission in the prison ............................................................................................................................  
Identification marks ...................................................................................................................................................................................... 
........................................................................................................................................................................................................................................... 
 
Previous History of illness: 
Are you suffering from any disease?      Yes / No 
If so, the name of the disease:  
Are you now taking medicines for the same?  
Are you suffering from cough that has lasted for 3 weeks or more  Yes / No 
History of drug abuse, if any:  
Any information the prisoner may volunteer:  
 
Physical examination: 
Height ....... cms. Weight ........ kg   Last menstruation period ......................  
 
1. Paller:    Yes / No   2. Lymph Node enlargement:  Yes / No 
 
3. Clubbing:      Yes / No   4. Cyanosis: Yes / No 
 
5. Icterus:   Yes / No    6. Injury, if any .................................................................................... 
 
 
Blood test for Hepatitis / STD including HIV, (with the informed consent of the prisoner 
whenever required by law) 
Any other ........................................................................................  
Systemic Examination: 
1. Nervous System  
2. Cardio Vascular System 
3. Respiratory System  
4. Eye, ENT 
5. Gastro Intestinal system abdomen 
6. Teeth & Gum 
7. Urinal System  
 
The medical examination and investigations were conducted with the consent of the 
prisoner after explaining to him/her that it was necessary for diagnosis and treatment of 
the disease from which he/she may be suffering.  
 
Date of commencement of medical investigation  
Date of completion of medical investigation  
            
Signature with Designation of Medical Officer /  
       CHIEF MEDICAL OFFICER 

206 
 
INSTRUCTIONS FOR THE RECORDING OF MARKS, SCARS AND OTHER MEANS OF IDENTIFYING INDIVIDUALS 
(See 211 of Tamilnadu Prison Rules) 
1. In order to give a description of any person sufficient to distinguish him, and make it evident to any other 
person that he is the individual described, it is usually necessary to note several points. The more uncommon 
any peculiarity is to mankind in general, the more characteristic it becomes of the individual. and therefore, the 
more valuable as a means line of identification. If a man for instance is said to have his face pitted with the 
small pox marks, it is clear that he must be one of a limited number of people, as the majority are not so 
marked, but this is not enough to identify him, so long as many persons disfigured by smallpox are to be 
seen. If it is added that he is blind in one eye, the number of people who combine the two peculiarities 
would be small, and if it were said that he ware blind in the left eye, it would be rendered still smaller, 
while if he was further described as having a scar the size of a rupee on the back of his right hand or 
had lost the last joint of his left-thumb and was 178 cm. high, it is clear that the individual would be so 
well defined that any person found to combine all these peculiarities would without much doubt be the 
individual described. Therefore, the larger the number of peculiarities noted, the more accurate the description, 
and the more uncommon they are to men in general, the smaller the chance of making mistakes in 
identification. 
2. The cut, shape or material of clothing the colour of the hair or skin and similar attributes, though helpful 
in certain cases, are ordinarily not of much value, as they are too general and can be stimulated, and it is 
better to depend on attributers that less common and cannot be copied.  
3. It is not necessary to measure every mark and scar on the person. It will suffice if three or more of the 
most prominent and permanent are recorded. Provided that their positions are accurately given. Care must be 
taken that the marks selected are permanent, at least so far as it is possible to judge.  
4. The following brief instructions as to the manner of recording marks of identification are laid down for 
general guidance, namely:  
(1) Marks and scars- These to be of value must be permanent. Their size, shape, locality and probable cause 
(if known) should be stated, together with their direction and distance in inches from a fixed point.  
(2) The fixed points usually taken are -- (a) For the head and face—the corners of the eyes or mouth, the 
ears or nostrils which ever may be most convenient for purposes of measurement. (b) For the neck---the 
seventh or prominent vertebra at the back or Adam’s apple at the front. (c) For the arms---the point of the 
elbow. (d) For the hands---the tip of the middle finger. (e) For the front of the body---the navel and middle 
line. (f) For the back ---the seventh vertebra and middle line. (g) For the legs---the middle of the bend of the 
knee; (3) In measuring marks on the front as well as on the back of the body, an imaginary line is drawn 
down the centre of body. Scars will be denoted as being either to the right or left of this line, above or 
below the navel (and below the seventh vertebra on the back); (4) To measure the distance of a scar on 
the trunk of the body from the given point, it will first be necessary to ascertain its distance from a horizontal 
direction to the right or left of the imaginary line. The next step will be to measure the distance from the 
point where these imaginary vertical and horizontal lines intersect to the navel. If the scar anywhere on the 
imaginary line, it will only be necessary to give the distance above or below the navel to localize it; 
(5) It should invariably be stated whether the mark is on the right or left limb and, If so, whether it is on 
its interior, exterior, anterior or posterior surface. Examples: -- (a) Burn circular in shape, 31 mm in diameter, 
127 mm from navel and 76 mm to left median line. (b) Longitudinal scar on back 76 mm long, 13 mm 
broad in the middle, pointed at both ends direction up and out 178 mm from seventh vertebra and 64 mm to 
right of median line. (c) Burn irregular in shape exterior right thigh, 127 mm from bend of knee at its nearest 
point. During the examination, a person should be made to stand up right, with hands down and palms turned 
forwards. The entries about the marks can be considerably abbreviated without becoming unintelligible and 
should not be unnecessarily lengthy; (6) Deformities of any kind should always be recorded. The following are 
the principal, -- (a) Head---Hair, lip, loss of or injury to an eye, squint, misshapen ears, nose or skull, loss of 
teeth. (b) Body—Loss of or supernumerary fingers or toes, webbed fingers, or toes, webbed fingers, loss of a 
limb or part of a limb, immovable joints, wasted muscles; (7) In addition to marks, scars and deformities, any 
peculiarity which may specially distinguish the individual under examination may prove, useful, such as unusual 
height, a stammer in speech, peculiar gait or attitude and the like; (8) To give a complete list of all the 
points that may possibly prove of value as means of identification would be impracticable. The examiner must 
use his common sense, and note such points as are likely to be most useful. 
 
 
 
 

207 
 
Form A 
INFORMATION TO POLICE ASSENT / DISSENT 
(MEDICAL TERMINATION OF PREGNANCY IN A SURVIVOR) 
 
Name of the Institution                                   Date:  
 
I ..............................................................., have been informed about the provisions regarding the 
identification of minor girl, explained in POCSO Act related to MTP act 2021 and 
hereby provide my assent / dissent for disclosing information regarding my 
treatment at this institution to the concerned Public Authorities.  
 
 
 
Date:  
Place: 
                                   Minor girl / Parent / Guardian Signature  
  
 
 
Form B 
COMMUNICATION MADE TO POLICE REGARDING  
MEDICAL TERMINATION OF PREGNANCY  
WITHOUT PROVIDING ANY IDENTIFICATION OF THE GIRL (VICTIM)  
 
 
TO WHOMSOEVER CONCERNED  
 
This is to inform that a girl aged .................................................... years, brought my her 
mother / father / Child Welfare Committee Member on ....................................AM / PM 
Was examined and found to be pregnant with gestation of .................................weeks. 
 
Necessary counselling is given and admitted for MTP on ......................................................... at  
................................................................................................................... MCH ................................................................... / 
Government Hospital ................................................................... of .............................................. District.  
 
 
 
                                             Signature of Medical Officer 
Date:  
Place: 
  
Received by:  
(Name, Designation / Police Number & Station, Date & Time).  

208 
 
CONSENT FORM – Medical Termination of Pregnancy 
Form C (MTP Rules, Rule 8) 
 
I ...................................................................................................... daughter / wife of ..................................................... 
aged about ........................ years of age, from ............................................................................... 
.................................................................................................... (state the permanent address) at 
present residing at ............................ do hereby give my consent of the termination of my 
pregnancy at ......................................................................................................................... (State the 
name of a place where the pregnancy is to be terminated).  
 
 
Signature 
Place:  
Date:  
 
 
 
 
 
 
 
 
 
 
 
 
CONSENT FORM – Medical Termination of Pregnancy 
Form C (Rule 8) 
(To be filled by guardian where the woman is lunatic or minor) 
 
I ...................................................................................................... daughter / wife of ..................................................... 
aged about ........................ years of age, from ............................................................................... 
.................................................................................................... (state the permanent address) at 
present residing at ............................ do hereby give my consent of the termination of the 
pregnancy of my ward ........................................................................................................................ 
who is a minor / lunatic at .................................... .......................................................... (State 
the name of a place where the pregnancy is to be terminated).  
 
 
Signature 
Place:  
Date:  
 
 
 
 
 

209 
 
FORM I  
(MTP Rules, Regulation 3) 
I ................................................................................................................................................................ 
.................................................................................................................................................................... 
Name and qualification of the Registered Medical Practitioner in block letters) 
.................................................................................................................................................................... 
....................................................................................................................................................................  
(Full address of the Registered Medical Practitioner) hereby certify that 
 
I ................................................................................................................................................................ 
.................................................................................................................................................................... 
Name and qualification of the Registered Medical Practitioner in block letters) 
.................................................................................................................................................................... 
....................................................................................................................................................................  
(Full address of the Registered Medical Practitioner) hereby certify that 
 
*I / We / am / are of opinion, formed in good faith, that it is necessary to terminate the 
pregnancy of ............................................................................................................................................ 
(Full name of pregnant woman in block letters) resident of ........................................................ 
...................................................................................................................................................................... 
for the reason given below**,  
 
*I / We hereby give intimation that *I / we terminated the pregnancy of the woman 
referred to above who bears the serial No ........................ in the Admission Register of the 
Hospital / approved place. 
 
Place       Signature of Registered Medical Practitioner. 
 
 
Date        Signature of Registered Medical Practitioner. 
 
 
* Strike out whichever is not applicable the one which is appropriate.  
** Of the reasons specified items (i) to (v) write.  
(i) In order to save the life of the pregnant woman.  
(ii) In order to prevent grave injury to the physical or mental health of pregnant woman. 
(iii) In view of the substantial risk that if the child was born it would suffer from such physical or mental 
abnormalities as to be seriously handicapped  
(iv) As the pregnancy is alleged by pregnant woman to have been caused by rape.  
(v) As the pregnancy has occurred as a result of failure of any contraceptive device or method used by the 
woman or her partner for the purpose of limiting the number of children / avoiding pregnancy. 
NOTE.- Account may be taken of the pregnant women's actual or reasonably foreseeable environment in 
determining whether the continuance of a pregnancy would involved a grave injury to her physical or mental 
health.  
 
 
Place       Signature of Registered Medical Practitioner. 
 
 
Date        Signature of Registered Medical Practitioner. 

210 
 
Medical Board for MTP Cases – District wise: 
(G.O.Ms. No.223, Health and Family Welfare (R2), 11th July 2023, Aani 26, Sobakiruthu, Thiruvalluvar Aandu-2054.) 
 
Government Medical College Hospital District 
Chennai Rajiv Gandhi Hospital 
Chennai 
Madurai Rajaji Hospital 
Madurai  
Government Coimbatore Medical College and Hospital, Coimbatore 
Coimbatore 
Government Dharmapuri Medical College and Hospital, Dharmapuri 
Dharmapuri 
Government Chengalpattu Medical College and Hospital, Chgengalpattu 
Chengalpattu 
Government Kanyakumari Medical College and Hospital, Kanyakumari 
Kanyakumari 
Government Karur Medical College and Hospital, Karur 
Karur 
Government Pudukottai Medical College and Hospital, Pudukottai 
Pudukottai 
Government Mohan Kumaramangalam Medical College and Hospital, Salem 
Salem 
Government Sivaganagai Medical College and Hospital, Sivagangai 
Sivagangai 
Government Thanjavur Medical College and Hospital, Thanjavur 
Thanjavur 
Government Theni Medical College and Hospital, Theni 
Theni 
KAPV Vishwanathan Government Medical College and Hospital, Tiruchirapalli 
Tiruchirapalli 
Government Tiruvannamalai Medical College and Hospital, Tiruvannamalai 
Tiruvannamalai 
Government Thiruvaraur Medical College and Hospital, Thiruvarur 
Thiruvarur 
Government Thirunelveli Medical College and Hospital, Thirunelveli 
Thirunelveli 
Tenkasi 
Government Thoothukudi Medical College and Hospital, Thoothukudi 
Thoothukudi 
Government Vellore Medical College and Hospital, Vellore 
Vellore, 
Tiruppathur and 
Rani 
Government Villupuram Medical College and Hospital, Villupuram 
Villupuram 
Government Namakkal Medical College and Hospital, Namakkal 
Namakkal 
Government Tiruppur Medical College and Hospital, Tiruppur 
Tiruppur 
Government Tiruvallur Medical College and Hospital, Tiruvallur 
Tiruvallur 
Government Ramanathapuram Medical College and Hospital, Ramanathapuram 
Ramanathapuram 
Government Nagapattinam Medical College and Hospital, Nagapattinam Nagapattinam 
and 
Mayiladuthurai 
Government Dindigul Medical College and Hospital, Dindigul Dindigul 
Government Kallakurichi Medical College and Hospital, Kallakurichi Kallakurichi 
Government Virudhunagar Medical College and Hospital, Virudhunagar Virudhunagar 
Government Krishnagiri Medical College and Hospital, Krishnagiri Krishnagiri 
Government The Nilgiris Medical College and Hospital, The Nilgiris  The Nilgiris 
Government Ariyalur Medical College and Hospital, Ariyalur Ariyalur & 
Perambalur 
Government Erode Medical College and Hospital, Perundurai Erode 
Government Cuddalore Medical College and Hospital, Chidambaram Cuddalore 
 
 
 
 

211 
 
FORM F - FORM FOR MAINTENANCE OF RECORD  
IN CASE OF PRENATAL DIAGNOSTIC TEST / PROCEDURE  
BY GENETIC CLINIC/ULTRASOUND CLINIC/IMAGING CENTRE  
(Proviso to Section 4(3), rule 9(4) and rule 10(1A) of PCPNDT Act)


# Section B: To be filled in for performing non-invasive diagnostic Procedures/ Tests only

## Introduction

Section B: To be filled in for performing non-invasive diagnostic Procedures/ Tests only 
 
9. Name of the doctor performing the procedure/s : ___________________________  
 
 
10. Indication/s for diagnosis procedure ____________________________________________ 
(specify with reference to the request made in the referral slip or in a self-referral note) 

212 
 
(Ultrasonography prenatal diagnosis during pregnancy should only be performed when 
indicated. The following is the representative list of indications for ultrasound during 
pregnancy. (Put a “Tick” against the appropriate indication/s for ultrasound) 
i) To diagnose intra-uterine and/or ectopic pregnancy and confirm viability.  
ii) Estimation of gestational age (dating).  
iii) Detection of number of foetuses and their chorionicity.  
iv) Suspected pregnancy with IUCD in-situ or suspected pregnancy following contraceptive 
failure/MTP failure.  
v) Vaginal bleeding/leaking.  
vi) Follow-up of cases of abortion.  
vii) Assessment of cervical canal and diameter of internal os.  
viii) Discrepancy between uterine size and period of amenorrhea.  
ix) Any suspected adenexal or uterine pathology/abnormality.  
x) Detection of chromosomal abnormalities, foetal structural defects and other abnormalities 
and their follow-up.  
xi) To evaluate fetal presentation and position.  
xii) Assessment of liquor amnii.  
xiii) Preterm labor / preterm premature rupture of membranes.  
xiv) Evaluation of placental position, thickness, grading and abnormalities (placenta praevia, 
retro placental hemorrhage, abnormal adherence etc.).  
xv) Evaluation of umbilical cord – presentation, insertion, nuchal encirclement, number of 
vessels and presence of true knot.  
xvi) Evaluation of previous Caesarean Section scars.  
xvii) Evaluation of fetal growth parameters, fetal weight and fetal well being.  
xviii) Color flow mapping and duplex Doppler studies.  
xix) Ultrasound guided procedures such as medical termination of pregnancy, external 
cephalic version etc. and their follow-up.  
xx) Adjunct to diagnostic and therapeutic invasive interventions such as chorionic villus 
sampling (CVS), amniocenteses, fetal blood sampling, fetal skin biopsy, amnio-infusion, 
intrauterine infusion, placement of shunts etc.  
xxi) Observation of intra-partum events.  
xxii) Medical/surgical conditions complicating pregnancy.  
xxiii) Research/scientific studies in recognized institutions.  
 
11. Procedures carried out (Non-Invasive) (Put a “Tick” on the appropriate procedure)  
i. Ultrasound  
(Important Note: Ultrasound is not indicated/advised/performed to determine the sex of fetus 
except for diagnosis of sex-linked diseases such as Duchene Muscular Dystrophy, 
Hemophilia A & B etc.)  
 
ii. Any other (specify) __________  
 
12. Date on which declaration of pregnant woman/ person was obtained:  
 
13. Date on which procedures carried out:  
 

213 
 
14. Result of the non-invasive procedure carried out (report in brief of the test including 
ultrasound carried out): 
 
15. The result of pre-natal diagnostic procedures was conveyed to    on    
 
16. Any indication for MTP as per the abnormality detected in the diagnostic procedures/ 
tests 
 
Date:      Name, Signature and Registration Number with Seal of the 
         Gynaecologist/Radiologist/Registered Medical Practitioner 
Place:         performing Diagnostic Procedure/s


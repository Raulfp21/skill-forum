# PART A (To be filled by the Party)

## Introduction

PART A (To be filled by the Party) 
 
I, _____________________ (Name), Son/daughter/spouse of ___________________ 
residing/employed at __________________________ do hereby solemnly affirm and sincerely 
state and submit as follows: — 
 
I have produced electronic record/output of the digital record taken from the following 
device/digital record source (tick mark): — 
 
Computer / Storage Media     DVR   Mobile     Flash Drive 
 
CD/DVD    Server       Cloud      Other 
 
Other: ________________________________________ 
 
Make & Model: _______________ Color: _______________ 
Serial Number: _______________ 
IMEI/UIN/UID/MAC/Cloud ID_____________________ (as applicable) 
and any other relevant information, if any, about the device/digital record____(specify). 
 
The digital device or the digital record source was under the lawful control for regularly 
creating, storing or processing information for the purposes of carrying out regular 
activities and during this period, the computer or the communication device was working 
properly and the relevant information was regularly fed into the computer during the 
ordinary course of business. If the computer/digital device at any point of time was not 
working properly or out of operation, then it has not affected the electronic/digital 
record or its accuracy. The digital device or the source of the digital record is:  
 
Owned     Maintained   Managed    Operated by me (select as applicable). 
 
I state that the HASH value/s of the electronic/digital record/s is _________________, 
obtained through the following algorithm:  
SHA1  : 
SHA256    : 
MD5   : 
Other  __________________ (Legally acceptable standard) 
(Hash report to be enclosed with the certificate) 
 
Date (DD/MM/YYYY): _____ 
Time (IST): ________hours (In 24 hours format) 
Place: ____________ 
 
 
 

175 
 
Autopsy in Organ Transplant cases: 
Form - III 
Organ Retrieval Authorization Form 
I / We, Dr. ------------------------------------------------------------------------------------------------------------- 
hereby authorize, as per Section 6 of the Transplantation of Human Organs Act, 1994, 
(Central Act 42 of 1994)the retrieval, of the under mentioned organs, for the purpose of 
transplantation from the Brain Dead Cadaver of 
Thiru / Tmt ------------------------------------------------------------------------------------------------------------- 
s/o / d/o -----------------------------------------------------------------------------------------------------------------whose 
Brain Death was certified as per the said Act and the functioning status of the organs 
intended to be retrieved for transplantation purpose have been certified by the doctors, 
who treated him / her. 
Organ(s) authorized for retrieval: 
(1) 
(2) 
(3) 
(4) 
(5) 
(Signature of the doctor, who will conduct post mortem examination) 
Name   :  
Medical council no :  
Designation   :  
 
 
 
 
 

176 
 
(Medl. I-29) 
GOVERNMENT ............................ COLLEGE / HOSPITAL, ................................... 
POST MORTEM EXAMINATION CERTIFICATE. 
(P. M. No: ...................................................). 
Regarding body of a male / female, ............................... aged ........... years with reference to 
.................................................................. Police Station, Crime No: .................................., U/s: ..................................... 
Requisition for post mortem examination was received from the ......................................................... 
................................................................................... at ................... AM / PM on .............................. at .............................. 
Body was in charge of constable, ........................................................................................................................................ 
Body was first seen by the undersigned at ................... AM / PM on .............................. 
Its condition then was rigor mortis present .................................................... / decomposition .............. 
...................................................................................................................................................................................................................................... 
Identification & Caste Marks: 
1.          2.  
 
 
Appearance found at post mortem examination:  
 
 
Following ante mortem wounds were seen on the body: 
 
 
 
 
 
 
 
 
 
 
 
OPINION as to the cause of death:  
The deceased would appear to have died of ..................................................... 
 
 
 
Signature  
Name in block letters & Designation 
 
Station & Date     :      
Original      :  
Duplicate    : 
Triplicate     :         (Office seal)  

177 
 
            (Medl. I-29) 
GOVERNMENT ............................ COLLEGE / HOSPITAL, ................................... 
POST MORTEM EXAMINATION CERTIFICATE. 
(P. M. No: ...................................................). 
PROVISIONAL / FINAL OPINION 
Regarding body of a male / female, ............................... aged ........... years with reference to 
.................................................................. Police Station, Crime No: .................................., U/s: ..................................... 
 
I / We, the undersigned, hereby send you the Final opinion / Provisional Opinion as to 
the case mentioned above.  
 
FSL Report / Histopathology Report / .......................................................: 
 
Ref. No: ..............................................................................................................; received on ..................................................... 
 
Details of the report: 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
PROVISIONAL / FINAL OPINION:  
The deceased would appear to have died of .................................................... 
 
 
 
Signature with Name & Designation 
 
Station & Date     :      
Original      :  
Duplicate    : 
Triplicate     :         (Office seal)  

178 
 
FORM NO. 4 
MEDICAL CERTIFICATE OF CAUSE OF DEATH 
(Hospital in-patients. Not to be used for stillbirths) 
To be sent to Registrar along with Form No. 2 (Death Report) 
 
Name of the Hospital .................................................................................  
I hereby certify that person whose particulars are given below died in the hospital in Ward no. ........... on .........  at ......A.M./P.M.
        
Name and signature of the Medical Attendant certifying the cause of death 
................................................................................................................................................................................................................................................................................ 
  (To be detached and handed over to the relative of the deceased) 
Certified that Shri/Smt./Kum   .......................................S/W/D/ of Sri................................................ R/o..................................................................... 
was admitted to this hospital in Ward ............ on ........................ and expired on..................... 
Doctor’s Signature 
(Medical Supdt. Name of the Hospital) 
Name of Deceased ..................................................................................................................... S/W/D/ of ............................................ 
Address   ..................................................................................................................................................................................................................... 
For use of     
Statistical 
Office 
 
 
Sex 
                                        Age at Death  
If 1 year or more, 
age in years 
If less than 1 year, 
age in months 
If less than 1 month, 
age in days 
If less than 1 day 
age in hours 
1. Male 
2.Female 
3. Others 
     
 
 
 
 
 
 
 
 
Cause of Death Interval between onset 
& death approx. 
 
I. Immediate cause 
      (State the disease, injury or complication which 
caused death, not the mode of dying, such as heart 
failure, asthenia, etc.) 
Antecedent cause  
      (Morbid conditions, if any, giving rise to the above 
cause, stating underlying conditions last) 
 
II. Other significant condition contributing to the 
death but not related to the disease or conditions 
causing it. 
 
(a).................................................... 
due to (or as a 
consequences of) 
 
(b)................................................... 
due to (or as a 
consequences of) 
(c) .................................................. 
 
    ................................................... 
 
 
 
Manner of Death: 
(1) Natural. (2) Accident. (3) Suicide.  (4)Homicide  
(5)Pending investigation 
 
How did the injury occur? 
If deceased was a female, was pregnancy associated with the death?  
If yes, was there a delivery? 
(1) Yes  (2)  No 
(1)  Yes (2)  No   

179 
 
Directions for filling the form: 
NAME OF DECEASED: To be given in full. Do not use initials. If deceased is an infant, not yet named at the 
time of death, write ‘Son of (S/o) or Daughter of (D/o)’ followed by names of mother and father. 
AGE: If the deceased is above one year of age, give age in completed years. If the deceased is below I year 
of age, give age in months and if below one month, give age in completed number of days, and if below one 
day, in hours. 
CAUSE OF DEATH: This part of the form should always be completed by the attending physician personally. 
The certificate of cause of death is divided into two parts, I and II. Part I is again divided into three parts, lines 
(a) (b) & (c). If a single morbid condition completely explains the cause of death, then this will be written on line 
(a) of part I, and nothing more is needed to be written in the rest of Part I or Part II. For example, smallpox, 
lobar pneumonia, cardiac beriberi are sufficient cause of death and usually nothing more is needed. 
Often, however, a number of morbid conditions will be present during death, and the doctor must then complete 
the certificate in the proper manner so that he enters in Part I (a) the Immediate cause of death. This does not 
a mean the mode of dying, e.g., heart failure, respiratory failure, etc. These terms should not appear in the 
certificate at all, since they are modes of dying and not causes of death. Next consider whether the immediate 
cause is a complication or delayed result of some other cause. If so, enter the antecedent cause in Part I, line 
(b). Sometimes there will be three stages in the course of events leading to death. If so, line (c) has to be 
completed. The underlying cause to be tabulated is always written last in Para I. 
Morbid conditions or injuries may be present which were not directly related to the train of events causing death, 
but which contributed in some way to the fatal outcome. Sometimes, the doctor finds it difficult to decide, 
especially for infant deaths, which of the several independent conditions was the primary cause of death. But only 
one cause can be tabulated, so the doctor must decide regarding that. If the other diseases are not the effects of 
the underlying cause, they are entered in Part II. 
Do not write two or more conditions in a single line. Please write the names of the diseases (in full) in the 
certificate as legibly as possible to avoid the risk of their being misread. 
ONSET: Complete the column for interval between onset and death whenever possible, even if very approximately, 
e.g., from birth to several years.  
ACCIDENTAL OR VIOLENT DEATHS: Both the external cause and the nature of the injury are needed and should 
be stated. The doctor or the hospital should always be able to describe the injury, stating the part of the body 
injured, and should give the external cause in full when this is shown. Example: (a) Hypostatic pneumonia: (b) 
Fracture neck of femur; (c) Fall from ladder at home. 
MATERNAL DEATHS: Be sure to answer the questions on pregnancy and delivery. This information is needed 
regarding all women of child-bearing age, even though the pregnancy may have had nothing to do with the death. 
OLD AGE OR SENILITY: Old age (or senility) should not be given as a cause of death if a more specific cause 
is known. If old age was a contributory factor, it should be entered in Part II. Example (a) Chronic bronchitis, II 
old age. 
COMPLETENESS OF INFORMATION: A complete case history is not wanted, but if the information is available, 
enough details should be given to enable the underlying cause to be properly clarified. 
EXAMPLE: Anaemia – mention the type of anaemia, if known. Neoplasm – Indicate whether benign or malignant 
and site, with site of primary neoplasm, whenever possible. Heart disease – Describe the condition specifically; if 
congestive heart failure, cor pulmonale, etc. and give the antecedent conditions. Tetanus – Describe the antecedent 
injury, if known. Operation – State the condition for which the operation was performed. Dysentery – Specify whether 
bacillary, amoebic, etc., if known. Complications of pregnancy or delivery – Describe the complication specifically. 
Tuberculosis – Mention the organs affected. 
SYMPTOMATIC STATEMENT: Convulsions, diarrhoea, fever, ascites, jaundice, debility, etc., are symptoms which may 
be due to any one of different conditions. Sometimes nothing more is known, but whenever possible, mention the 
disease which caused the symptom. 
MANNER OF DEATH: Deaths not due to external cause should be identified as ‘Natural ‘. If the cause of death 
is known, but it is not known whether it was the result of an accident, suicide or homicide and is subject to 
further investigation, the cause of death should invariably be filled in and the manner of death should be shown 
as ‘PendingInvestigation ‘ 

180 
 
FORM NO. 4A 
MEDICAL CERTIFICATE OF CAUSE OF DEATH 
(Non Hospital deaths, Not to be used for stillbirths) 
To be sent to Registrar along with Form No. 2 (Death Report) 
 
I hereby certify that the Tr. .......................................................................................S/W/D/ of Tr................................. 
R/o..................................................................... was under treatment from .............. to ........... and she / he died on 
............ at ............. AM / PM  
 
                      
 
 
Name and signature of the Medical Attendant certifying the cause of death 
 
............................................................................................................................................................................ 
 
(To be detached and handed over to the relative of the deceased) 
Certified that Tr. .......................................................................................S/W/D/ of Tr................................................. 
R/o.....................................................................  was under treatment from .............. to ........... and she / he died on 
............ at ............. AM / PM 
 
 
 
 
           Name and signature of the Medical Attendant certifying the cause of death 
 
........................................................................................................................................................................... 
 
 
 
 
Name of Deceased ........................................................................ S/W/D/ of ............................................ 
Address................................................................................................................................................ 
............................................................................................................................................................ 
For use of     
Statistical 
Office 
 
 
Sex 
                                        Age at Death  
If 1 year or more, 
age in years 
If less than 1 year, 
age in months 
If less than 1 month, 
age in days 
If less than 1 day 
age in hours 
1. Male 
2.Female 
3. Others 
     
 
 
 
 
 
 
 
 
 
Cause of Death 
Interval between onset 
& death approx. 
 
I. Immediate cause 
(State the disease, injury or complication which caused 
death, not the mode of dying, such as heart failure, 
asthenia, etc.) 
 
Antecedent cause  
(Morbid conditions, if any, giving rise to the above 
cause, stating underlying conditions last) 
 
 
 
 
 
II. Other significant condition contributing to the death 
but not related to the disease or conditions causing it. 
(a).................................
..................................... 
due to (or as a 
consequences of) 
 
(b).................................
..................................... 
due to (or as a 
consequences of) 
 
(c) 
.................................. 
 
 
 
 
Manner of Death: 
(1) Natural. (2) Accident. (3) Suicide.  (4)Homicide  
(5)Pending investigation 
 
How did the injury occur? 
If deceased was a female, was pregnancy associated with the death?  
If yes, was there a delivery? 
(2)  Yes  (2)  No 
(2)  Yes (2)  No   

181 
 
Directions for filling the form: 
NAME OF DECEASED: To be given in full. Do not use initials. If deceased is an infant, not yet named at the 
time of death, write ‘Son of (S/o) or Daughter of (D/o)’ followed by names of mother and father. 
AGE: If the deceased is above one year of age, give age in completed years. If the deceased is below I year 
of age, give age in months and if below one month, give age in completed number of days, and if below one 
day, in hours. 
CAUSE OF DEATH: This part of the form should always be completed by the attending physician personally. 
The certificate of cause of death is divided into two parts, I and II. Part I is again divided into three parts, lines 
(a) (b) & (c). If a single morbid condition completely explains the cause of death, then this will be written on line 
(a) of part I, and nothing more is needed to be written in the rest of Part I or Part II. For example, smallpox, 
lobar pneumonia, cardiac beriberi are sufficient cause of death and usually nothing more is needed. 
Often, however, a number of morbid conditions will be present during death, and the doctor must then complete 
the certificate in the proper manner so that he enters in Part I (a) the Immediate cause of death. This does not 
a mean the mode of dying, e.g., heart failure, respiratory failure, etc. These terms should not appear in the 
certificate at all, since they are modes of dying and not causes of death. Next consider whether the immediate 
cause is a complication or delayed result of some other cause. If so, enter the antecedent cause in Part I, line 
(b). Sometimes there will be three stages in the course of events leading to death. If so, line (c) has to be 
completed. The underlying cause to be tabulated is always written last in Para I. 
Morbid conditions or injuries may be present which were not directly related to the train of events causing death, 
but which contributed in some way to the fatal outcome. Sometimes, the doctor finds it difficult to decide, 
especially for infant deaths, which of the several independent conditions was the primary cause of death. But only 
one cause can be tabulated, so the doctor must decide regarding that. If the other diseases are not the effects of 
the underlying cause, they are entered in Part II. 
Do not write two or more conditions in a single line. Please write the names of the diseases (in full) in the 
certificate as legibly as possible to avoid the risk of their being misread. 
ONSET: Complete the column for interval between onset and death whenever possible, even if very approximately, 
e.g., from birth to several years.  
ACCIDENTAL OR VIOLENT DEATHS: Both the external cause and the nature of the injury are needed and should 
be stated. The doctor or the hospital should always be able to describe the injury, stating the part of the body 
injured, and should give the external cause in full when this is shown. Example: (a) Hypostatic pneumonia: (b) 
Fracture neck of femur; (c) Fall from ladder at home. 
MATERNAL DEATHS: Be sure to answer the questions on pregnancy and delivery. This information is needed 
regarding all women of child-bearing age, even though the pregnancy may have had nothing to do with the death. 
OLD AGE OR SENILITY: Old age (or senility) should not be given as a cause of death if a more specific cause 
is known. If old age was a contributory factor, it should be entered in Part II. Example (a) Chronic bronchitis, II 
old age. 
COMPLETENESS OF INFORMATION: A complete case history is not wanted, but if the information is available, 
enough details should be given to enable the underlying cause to be properly clarified. 
EXAMPLE: Anemia – mention the type of anemia, if known. Neoplasm – Indicate whether benign or malignant and 
site, with site of primary neoplasm, whenever possible. Heart disease – Describe the condition specifically; if 
congestive heart failure, cor pulmonale, etc. and give the antecedent conditions. Tetanus – Describe the antecedent 
injury, if known. Operation – State the condition for which the operation was performed. Dysentery – Specify whether 
bacillary, amoebic, etc., if known. Complications of pregnancy or delivery – Describe the complication specifically. 
Tuberculosis – Mention the organs affected. 
SYMPTOMATIC STATEMENT: Convulsions, diarrhea, fever, ascites, jaundice, debility, etc., are symptoms which may 
be due to any one of different conditions. Sometimes nothing more is known, but whenever possible, mention the 
disease which caused the symptom. 
MANNER OF DEATH: Deaths not due to external cause should be identified as ‘Natural ‘. If the cause of death 
is known, but it is not known whether it was the result of an accident, suicide or homicide and is subject to 
further investigation, the cause of death should invariably be filled in and the manner of death should be shown 
as ‘Pending Investigation ‘ 

182 
 
DNA Sampling (Form - I) 
Certificate for drawal of examplar from Accused / Victim / Third party 
This is to certify that at the request of ..........................................................................(Name of the 
Investigative Agency / Police station) in Crime Number .............................................................................. 
(Blood, Saliva, Nail, Hair, Tooth, Semen, Pubic Hair, Vaginal swabs, skin scrapping 
etc)....................................... 
examplar was taken from ........................................................................ (Name of the person from whom 
the examplar is drawn, son of, daughter of, wife of ........................................... whose photograph is 
affixed below  
on .................... (date) at ........................ (time).  
The person was brought by .................................................................... (Name and number of the 
policeman / name of the official who brought the person) who identified him.  
 
Videograph taken: Yes / No.  
 
 
 
 
Photograph 
 
 
 
 
 
 
Enclosure: Sealed cover containing the examplar with rubber stamp of this Office. 
 
 
To  
......................... (Name of the Court) 
 
Signature & thumb 
impression of the person 
from whom the examplar 
was taken 
 
Signature of the Medical 
Officer 
(Medical Officers seal)  
 

183 
 
GOVERNMENT ......................................................................... HOSPITAL, 
............................................................................................. 
PROFORMA FOR EXAMINATION OF A CASE OF DRUNKENNESS 
 
Requisition from:         Dated: 
 
1. Name of the individual       : 
2. Sex          :      
3. Parent’s or Guardian’s Name   : 
4. Address and Residence      :  
 
5. Occupation         :      
6. Caste & Identification mark    :  
 
7. Married or Single       : 
8. Age as alleged by      :  
9. Persons accompanying or brought by    :  
 
10. Time & Place of Examination     :  
 
11. Consent of the individual for examination:  
 
12. Signature of the individual   : 
 
13. In case of minor, signature of Guardian : 
14. Name of the nurse present at the time of  
      examination        : 
 
 
PHYSICALEXAMINATION 
1. Height        : 
2. Weight        :  

184 
 
3. Breadth       : 
4. Chest girth at the level of nipples  : 
5. Abdominal girth at the level of Navel   : 
6. General build & appearance   : 
7. History        : 
8. Voice         : 
9. Teeth         :     
10. Hair -  Scalp :      Beard :      Moustache :       
  Axilla :      Pubic : 
11. General appearance and demeanour   : 
  State of clothing 
  Deposition 
  Speech 
  Gait 
12. Memory      : 
13. Mouth       : 
  Smell of alcohol 
  Dribbling of saliva 
  Lip 
  Tongue      
14. Systems      : 
 
15. Eyes        : 
  Visual acuity 
  Lateral gaze nystagmus 
  Conjunctiva  
  State of Pupil 
  Light reflex 
15. Reflexes      : 
16. Co ordination      :   
 
Date   :          Casualty Medical Officer / EMO, 
        (Name with Signature) 
Station  :          Government ............................... Hospital, 
            

185 
 
Medl I – 76 
GOVERNMENT ......................................................................... HOSPITAL, 
............................................................................................. 
CERTIFICATE OF DRUNKENNESS 
(DRUNKENNESS No..............................) 
Signs of intake of alcohol found on a male / female / third sex  
aged  years, an inhabitant of  
who was sent with letter /memo no.        dated 
from  
and accompanied by   
for report as to the result of examination of person for certain appearances due to 
alleged drunkenness 
Identification and caste marks – 
1) 
2) 
The person was first seen by the undersigned at      on    
and the examination was commenced at     on    and the following were 
found.  
Findings:  
 
 
Blood & Urine were collected, preserved & handed over to the Investigating 
Officer for Qualitative & Quantitative estimation of Alcohol. 
Blood & Urine were not collected because 
OPINION: I am of the opinion that the above person has 
 
Consumed alcohol and is under its influence as proved by 
Consumed alcohol but not under its influence. 
Not consumed alcohol. 
(Medical Officer to rule out whichever is not applicable) 
 
Date   :          Casualty Medical Officer, 
        (Name with Signature) 
Station  :          
Original     :          
Duplicate   :          (Office seal)      

186 
 
GOVERNMENT ......................................................................... HOSPITAL, 
............................................................................................. 
PROFORMA FOR EXAMINATION OF ACCUSED OF SEXUAL VIOLENCE 
1. Case Particulars:  
Requisition from        vide letter. No      
 dated  
for examination of     brought and identified by        
2. Particulars of the alleged accused:  
i. Name     
S/o    
ii. Address   
 
iii. Age as stated    iv. Occupation     v. Religion:       
vi. Consent given in writing     
 
 
3. Examined in presence of   
Place of examination     
Date and Time of examination  
 
CLEAR LTI    CLEAR RTI     PHOTO 
  
 
4. Marks of Identification:  
(1)    
 (2)    
 
Brief History:  
i. As given by Police    
 
 

187 
 
ii. As given by alleged accused:  
a. If he admits or denies the incidence (Account of incidence as per his 
statement)  
 
 
 
b. Did he know the victim before:  
c. If any injury is present on the body of the accused, then to see, if it could 
be due to struggle and resistance by the victim    
 
 
 
d. If his clothing’s show any evidence of lipstick, stains of blood, foreign hair, 
mud, grass, vaginal stains, if so, his explanation about the same:  
 
 
 
e. If his clothing show evidence of recent tear, loss of button, any loose foreign 
pubic hair, his explanation about it:  
 
 
f. Any history of S.T.D before  
 
g. Did he take bath, wash etc. after the alleged incidence  
 
h. Has he changed clothes after the incidence:  
 
 
 

188 
 
5. Physical examination  
i. Clothing: If same was worn during the incidence look for presence of blood 
stains, semen, vaginal stain, female pubis hair, mud, grass, lipstick, any tear etc. 
And describe  
 
ii. Marks of violence if any (Tick mark if present and describe): 
Bite marks :  
Abrasions:  
 
Contusions:  
Any other:  
 
 
iii. General Configuration:    Height          Weight         Body Built   
Blood Pressure             Pulse         Mental status      
iv. Axillary hair       v. Beard &Moustache    
vi. Pubic hair(including tanner staging)   
(If matted preserve clipping for Forensic examination) 
 
 
vii. Dentition: (Encircle the teeth not 
erupted)  
Total no    
 
Permanent      Temporary   
Spacing behind 2nd permanent molar       Artificial, if any   
 
 
8 7 6 5 4 3 2 1    1 2 3 4 5 6 7 8  
8 7 6 5 4 3 2 1    1 2 3 4 5 6 7 8  

189 
 
viii. Genital Examination:  
a. (Indicate as Y = Yes, N = No, DNK = Do Not Know)  
 Pubic region  Thigh and adjoining parts 
Matted hair    
Seminal stain   
Blood    
Loose foreign hair   
Injuries    
b. Penis:  
Development (Tanner Stage)   
Any defect / Deformity  
Length and Girth of penis in flaccid condition   
Length and Girth of penis in erect condition   
Glans penis and frenulum   
Whether foreskin can be freely rolled up or is circumcised   
Any injury on the frenulum   
Any injury elsewhere on the organ   
Evidence of any disease e.g. STD   
Presence of smegma under the foreskin   
Hair under prepuce   
 
Any Other Remark      
c. Scrotum and testes 
Development (Tanner Stage)   
Enlargement   
Both testes descended or not   
Any disease   
Any injury   
Cremasteric Reflex   
Any Other Remark      

190 
 
d. Details regarding any Disease/Injury: 
(Indicate as Y = Yes, N = No, DNK = Do Not Know, EO = Emission Occurred)  
Vas deference   
Epididymis   
Prostate   
On the genital   
Anywhere on the body   
 
Any Other Remark  
 

191 
 
                                                               
 
 
 
 
 
 
 
LEGEND: TYPES OF FINDINGS in the diagram. 
AB Abrasion; ER Erythema (redness); ALS Alternate Light Source F/H Fibre/Hair; 
PE Petechiae; BI Bite; FB Foreign Body; PS Potential Saliva; BU Burn; IN Induration; 
SHX Sample Per History; DE Debris; IW Incised Wound; SI Suction Injury; DF Deformity; 
LA Laceration; SW Swelling; DS Dry Secretion; MS Moist Secretion; 
TB Toluidine Blue; EC Ecchymosis (bruise); TE Tenderness; V/S Vegetation/Soil; 
OI Other Injury (describe): 
OF Other Foreign Material (describe):  
 
 
 
 
 
 
 
 

192 
 
Collection of Samples for Forensic Analysis:  
a. Clothing, where available – (Each garment to be wrapped separately and packed in 
paper bags after air drying – in envelope labelled step 1A and 1B) 
 
b. Collection of Hair Sample (In envelope labelled step 2A, 2B and 2C) 
Steps  Evidence Material   Collected (Y) /Not 
Collected (N) 
Reason for not 
collecting 
2A  Pubic hair combing (mention if shaved)    
2B  Cut strands of pubic hair (mention if shaved)    
2C  Cut strands of Matted pubic hair    
 
c. Collection of Loose foreign pubic hair or fibre of clothing, if present on the body or 
under the clothing of accused (In envelope labelled Step 3)  
 
Steps  Evidence Material   Collected (Y) /Not 
Collected (N) 
Reason for not 
collecting 
3A  Loose foreign pubic hair    
3B  Loose fibre of clothing    
 
d. Collection of Swabs for semen, blood, mud, grass etc. on body (In envelope labelled 
Step 4) 
 
Steps  Evidence Material   Collected (Y) /Not 
Collected (N) 
Reason for not 
collecting 
4A  Two swabs and two slides from stains on body    
4B  Two swabs and two slides for semen   
4C Two swabs and two slides for blood    
4D Two swabs for muddy stains, grass etc.    
 
e. Collection of urethral swabs and scrotal swabs and smears (In envelope labelled Step5 
for detection of seminal content, gonococci etc. DNA testing, STD etc.) 
Steps  Evidence Material   Collected (Y) /Not 
Collected (N) 
Reason for not 
collecting 
5A One urethral swab and two slides 
(for semen examination and DNA testing)   
  
5B  One urethral swab (for STD)    
5C Two scrotal swabs and two slides   
 
f. Collection of penile swabs and smears and penile washings for vaginal epithelia  
(In envelope labelled Step6) 
Steps  Evidence Material   Collected (Y) /Not 
Collected (N) 
Reason for not 
collecting 
6A Two penile swabs and two slides     
6B  Penile washings    
 
g. Collection of nail cuttings and scrapings (In envelope labelled Step7) 
Steps  Evidence Material   Collected (Y) /Not 
Collected (N) 
Reason for not 
collecting 
7A Nail scrapings      
7B  Nail cuttings   

193 
 
h. Collection of swabs from buccal mucosa (In envelope labelled Step8) 
Steps  Evidence Material   Collected (Y) /Not 
Collected (N) 
Reason for not 
collecting 
8 Two buccal swabs and two slides     
 
 
 
i. Blood Collection (In envelope labelled Step 9) 
Steps  Evidence Material   Collected (Y) /Not 
Collected (N) 
Reason for not 
collecting 
9A Blood for grouping (gauze cloth)   
9B Blood for DNA analysis on FTA card   
 
7. X rays for age estimation (if requested in the letter)  
8. Tests advised for potency / impotency (wherever required) 
1. Blood for – GTT, Serum electrolytes, Serum Creatinine, Liver function tests, 
     Full blood count, Serum prolactin level, Thyroid function test, 
     Serum testosterone, Sex Hormone binding globulin. 
2. Special investigations (if required) – Nocturnal Penile tumescence, 
     Cavernosography, Pharmacologically Induced Penile Erection test, 
     Doppler studies, Pudendal Arteriography, Pharmacocavernosometry.  
 
 
 
OPINION:  
 
 
Station         Signature 
Date       Name 
Time          Reg. No 
Designation      Office seal  
Original     : 
Duplicate   : 
Triplicate    :  
 
 
 
 
 
 

194 
 
GOVERNMENT ......................................................................... HOSPITAL, 
............................................................................................. 
PROFORMA FOR EXAMINATION OF SEXUAL OFFENCE SUVIVOR 
1. Name of the Hospital No.      OPD No    Inpatient No   
2. Name          D/o or S/o (Where Known)     
3. Address      
4. Age (as reported)         Date of Birth (if Known)       
5. Sex (M/F/Others)   
6. Date and Time of arrival in the hospital   
7. Date and Time of commencement of examination  
8. Brought by (Name & signatures)  
9. MLC No.       Police Station      
10. Whether conscious, oriented to time and place and person    
11. Any physical/intellectual/psycho-social disability      
(Interpreters of special educators will be needed where the survivor has special needs such 
as hearing/speech disability, language barriers, intellectual or psycho-social disability.)  
12. Informed Consent/refusal  
I         D/o or S/o   
hereby give my consent for:  
a) Medical Examination for Treatment     Yes/No  
b) This Medico Legal Examination    Yes/No  
c) Sample Collection for Clinical & Forensic Examination  Yes/No  
I also understand that as per law the hospital is required to inform Police and this has 
been explained to me. I want the information to be revealed to the Police   
 Yes/No  
I have understood the purpose and the procedure of the examination including the risk and 
benefit, explained to me by the examining doctor. My right to refuse the examination at any 
stage and the consequence of such refusal, including that my medical treatment will not be 
affected by my refusal, has also been explained and may be recorded. Contents of the 
above have been explained to me in     language with the help of a 
special educator/interpreter/support person (circle as appropriate)    
If special educator/interpreter/support person has helped, then his/her name and signature   
Name & signature of survivor or parent/Guardian/person in whom the child reposes trust in 
case of child (<12yrs)  
With Date, Time &Place    
Name & signature/thumb impression of Witness  
With Date, Time and Place  
 

195 
 
13. Marks of identification (Any scar/mole)  
(1)                              (2) 
 
 
14. Relevant Medical/Surgical history: 
Onset of menarche (in case of girls)       Yes / No  Age of onset   
Menstrual history - Cycle length and duration      Last Menstrual period    
Menstruation at the time of incident - Yes/ No   Menstruation at the time of 
examination- Yes/ No  
Was the survivor pregnant during incident - Yes/No If yes, duration of pregnancy 
  weeks  
Contraception use   : Yes / No               If yes-method used:  
Vaccination Status  : Tetanus Yes / No        Hepatitis B: Yes / No 
 
15A. History of Sexual Violence: 
Date of incident/s being reported     Time of incident/s   
Location/s      
Estimated duration:      days /      weeks /    months /  years 
Episode: One    Multiple      Chronic (>6 months)     Unknown    
Number of Assailant (s) and name/s    
 
 
 
Sex of assailant(s)  
 
Approx. Age of assailant (s)  
 
If known to the survivor - relationship with the Survivor  
 
Description of incident in the words of the narrator: Narrator of the incident: Survivor/Informant  
(indicate and specify name and relation to survivor) 
 
 
 
 
 
 
15B. Type of physical violence used if any (Tick mark the relevant and describe wherever 
required): 
Hit with (Hand/ Fist/ Blunt Object/ Sharp Object)     
Burned with     Biting   
Kicking     Pinching     
Pulling Hair     Violent shaking 
Banging head    Dragging     
Any others     

196 
 
15C. 
i. Emotional abuse of violence if any (insulting/ cursing/belittling/terrorizing) 
ii. Use of restraints, if any  
iii. Used or threatened the use of weapon(s) or objects if any  
iv. Verbal threats (For Example: Threats of killing or hurting survivor or any other person in 
whom the survivor Is interested; Use of photographs for blackmailing, etc.) if any:   
 
v. Luring (Sweets/Chocolates/Money/Job) if any  
vi. Any other   
 
15D. 
i. Any H/O drug/alcohol intoxication   
ii. Whether sleeping or unconscious at the time of the incident  
 
15E. If survivor has left any marks of injury on assailant/s, enter details   
 
15F. Details regarding sexual violence: 
Was penetration by penis, fingers or object or other body parts (Indicate as Y = Yes, N = 
No, DNK = Do Not Know, EO = Emission Occurred) 
 
Mention and describe body part/s and/or object/s used for penetration. 
    Accused 
Victim  
Penis Object / other 
body part 
Manipulation of 
woman 
Mouth 
Vaginal     
Urethral     
Anus     
Mouth     
 
 Yes   No Don’t 
know 
Emission 
occurred 
Oral sex performed by assailant on survivor     
Forced masturbation of self by survivor      
Masturbation of assailant by survivor     
Forced manipulation of assailants genital by survivor     
Exhibitionism (perpetrator displaying genitals)     
Did ejaculation occur outside of body orifice      
Where on the body ejaculation occurred      
Kissing, licking or sucking any part of survivor's body     
Touching / Fondling     
Condom used     
Status of condom     
Lubricant used     
What kind of lubricant used     
Object used     
What kind of object used     
Any other forms of sexual violence      

197 
 
Post incident, has the survivor  Yes / No / Do not know  Remarks  
Changed clothes   
Changed undergarments   
Cleaned / washed clothes    
Bathed   
Douched   
Passed urine    
Passed stools    
Rinsing of mouth / brushing / vomit   
 
Time since incident   
H/o vaginal / anal / oral bleeding / discharge prior to the incident of sexual violence   
H/o vaginal / anal / oral bleeding / discharge since the incident of sexual violence   
H/o painful urination/ painful defecation/fissures/ abdominal pain/ pain in genitals or any other


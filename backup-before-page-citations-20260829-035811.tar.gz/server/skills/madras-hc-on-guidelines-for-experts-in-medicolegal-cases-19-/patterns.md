# Patterns & Rules of Thumb

- [Section 6 r/w 5(m) and 5(1) of POCSO Act, 2012, for sexually abusing] evidence tendered by an expert must be relevant, reliable, clear, honest
- [Section 6 r/w 5(m) and 5(1) of POCSO Act, 2012, for sexually abusing] and impartial. As far as possible, they should provide a definite opinion
- [Section 6 r/w 5(m) and 5(1) of POCSO Act, 2012, for sexually abusing] with reasons and should avoid sitting on the fence.
- [Section 6 r/w 5(m) and 5(1) of POCSO Act, 2012, for sexually abusing] professionals who appear before Courts as expert witnesses must
- [Section 6 r/w 5(m) and 5(1) of POCSO Act, 2012, for sexually abusing] the medical witness must go through the medico legal reports etc,
- [Section 6 r/w 5(m) and 5(1) of POCSO Act, 2012, for sexually abusing] required, the medical witness must refresh his memory by perusing the
- [Section 6 r/w 5(m) and 5(1) of POCSO Act, 2012, for sexually abusing] professionals  must,  therefore,  recognise  that  their  professional
- [Section 6 r/w 5(m) and 5(1) of POCSO Act, 2012, for sexually abusing] never have arisen in this case. The manner in which the evidence was
- [Section 6 r/w 5(m) and 5(1) of POCSO Act, 2012, for sexually abusing] in the preparation of such documents, which must record both the facts
- [Section 6 r/w 5(m) and 5(1) of POCSO Act, 2012, for sexually abusing] documents, such as the Would Certificate and Accident Registers should
- [Section 6 r/w 5(m) and 5(1) of POCSO Act, 2012, for sexually abusing] by the Ministry  of Health and  Family Welfare should  be made
- [Section 6 r/w 5(m) and 5(1) of POCSO Act, 2012, for sexually abusing] POCSO Act and the same must form a part of the Accident Register and
- [Section 6 r/w 5(m) and 5(1) of POCSO Act, 2012, for sexually abusing] should be marked as an exhibit before the trial Court. This would enable

# Madras HC On Guidelines For Experts In Medicolegal Cases 19 08 2026

Section 6 r/w 5(m) and 5(1) of POCSO Act, 2012, for sexually abusing
the victim boy, aged about 8 years, by compelling him to have oral sex
and by inserting their private parts into the child's anal rectum.

## Overview

- **Slug:** `madras-hc-on-guidelines-for-experts-in-medicolegal-cases-19-`
- **Words:** 3429
- **Chapters:** 1
- **Chunks:** 7

## Chapter index (loaded on demand)

- Section 6 r/w 5(m) and 5(1) of POCSO Act, 2012, for sexually abusing ``chapters/ch01-section-6-r-w-5-m-and-5-1-of-pocso-act-2012-for-sexually-abu.md``

## How to use

Ask questions about Madras HC On Guidelines For Experts In Medicolegal Cases 19 08 2026. The agent retrieves the most relevant chapter
and answers from the real content with references — no hallucination.

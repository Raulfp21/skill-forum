# Cheatsheet — key facts

- [Section 6 r/w 5(m) and 5(1) of POCSO Act, 2012, for sexually abusing] 6.While  considering  these  applications  for  suspension  of
sentence, this Court noticed an apparent inconsistency in the evidence of
PW6, the Doctor who examined the victim.
- [Section 6 r/w 5(m) and 5(1) of POCSO Act, 2012, for sexually abusing] 7.Pursuant to the directions issued by this Court, Dr.Feroz
Khan appeared before this Court along with the original medical
records.
- [Section 6 r/w 5(m) and 5(1) of POCSO Act, 2012, for sexually abusing] 8.The matter, however, does not rest there.
- [Section 6 r/w 5(m) and 5(1) of POCSO Act, 2012, for sexually abusing] 9.Accordingly, the Doctor has filed an affidavit placing on
record his explanation.
- [Section 6 r/w 5(m) and 5(1) of POCSO Act, 2012, for sexually abusing] 13.A Division Bench of this Court in RM.Arun Swaminathan v.
- [Section 6 r/w 5(m) and 5(1) of POCSO Act, 2012, for sexually abusing] The relevant portions are extracted
hereunder for reference:
“15.
- [Section 6 r/w 5(m) and 5(1) of POCSO Act, 2012, for sexually abusing] 15.In State of Maharashtra v.
- [Section 6 r/w 5(m) and 5(1) of POCSO Act, 2012, for sexually abusing] 17.An expert witness occupies a position of trust.
- [Section 6 r/w 5(m) and 5(1) of POCSO Act, 2012, for sexually abusing] 18.Equally important is the duty to carefully read and verify the
deposition before affixing their signature so as to ensure that it correctly
records the evidence actually tendered before the Court.
- [Section 6 r/w 5(m) and 5(1) of POCSO Act, 2012, for sexually abusing] 23.As  notedsupra,  the  medical  evidence  serves  as  vital
corroborative evidence, which would help in establishing the guilt or
innocence  of  the  Accused  person.
- [Section 6 r/w 5(m) and 5(1) of POCSO Act, 2012, for sexually abusing] Index   : Yes / No19.08.2026
NCC    : Yes / No
gk
Note:
Mark a copy of this order to
1.
- [Section 6 r/w 5(m) and 5(1) of POCSO Act, 2012, for sexually abusing] 18/20
https://www.mhc.tn.gov.in/judis
( Uploaded on: 19/08/2026 01:17:53 pm )

Crl.MP(MD) Nos.5823 & 6941 of 2025
2.
- [Section 6 r/w 5(m) and 5(1) of POCSO Act, 2012, for sexually abusing] To
1.The Judge,
Fast Track Mahila Court,
Ramanathapuram.
- [Section 6 r/w 5(m) and 5(1) of POCSO Act, 2012, for sexually abusing] 2.The Inspector of Police,
Rameswaram Town Police Station,
Ramanathapuram District.
- [Section 6 r/w 5(m) and 5(1) of POCSO Act, 2012, for sexually abusing] 3.The Additional Public Prosecutor,
Madurai Bench of Madras High Court,
Madurai.

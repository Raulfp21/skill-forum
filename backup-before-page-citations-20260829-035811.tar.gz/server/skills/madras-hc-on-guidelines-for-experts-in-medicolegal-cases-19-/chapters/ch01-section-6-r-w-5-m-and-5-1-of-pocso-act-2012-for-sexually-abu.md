# Section 6 r/w 5(m) and 5(1) of POCSO Act, 2012, for sexually abusing

## Introduction

Section 6 r/w 5(m) and 5(1) of POCSO Act, 2012, for sexually abusing
the victim boy, aged about 8 years, by compelling him to have oral sex
and by inserting their private parts into the child's anal rectum. The
victim boy has given a statement under Section 164 CrPC before the
learned Magistrate as to the manner in which he was subjected to sexual
assault, and has reiterated the same before the trial Court in his
evidence.
6.While  considering  these  applications  for  suspension  of
sentence, this Court noticed an apparent inconsistency in the evidence of
PW6, the Doctor who examined the victim. In his chief examination,
PW6 deposed that the victim had sustained injuries. However, during
cross-examination, he stated that no such injuries were found. The
Wound Certificate [Ex.P6], though recording that "there was evidence
4/20
https://www.mhc.tn.gov.in/judis
( Uploaded on: 19/08/2026 01:17:53 pm )

Crl.MP(MD) Nos.5823 & 6941 of 2025
suggestive of sexual act", did not describe the nature of injuries. Since
this contradiction  was  taken as  a ground  by the petitioners  for
suspending their sentence, this Court found it appropriate to call upon
the  concerned  Doctor,  one  Dr.Feroz  Khan,  Assistant  Surgeon,
Government Medical College Hospital, Ramanathapuram, to appear and
clarify the position before considering the request for suspension of
sentence.
7.Pursuant to the directions issued by this Court, Dr.Feroz
Khan appeared before this Court along with the original medical
records. On examining the case sheet and the Accident Register, this
Court found that the injuries in the anal rectum of the victim had in fact
been noticed at the time of examination and duly recorded. The Doctor
explained that the initial examination had been conducted by another
medical officer, and that all the injuries were entered in the hospital
records. It thus became evident that while the original medical records
reflected the relevant findings, the same had not found a proper place in
the Wound Certificate [Ex.P6], giving rise to the inconsistency noticed by
this Court. In view of this explanation and the medical records
5/20
https://www.mhc.tn.gov.in/judis
( Uploaded on: 19/08/2026 01:17:53 pm )

Crl.MP(MD) Nos.5823 & 6941 of 2025
produced, the grounds canvassed by the petitioners for suspending the
sentence lack merit, and these petitions are accordingly dismissed.
8.The matter, however, does not rest there. Considering the
manner in which the inconsistency had surfaced, this Court afforded the
Doctor an opportunity to explain the circumstances under which such
contradiction had arisen.
9.Accordingly, the Doctor has filed an affidavit placing on
record his explanation. He has stated that on the date of his deposition
before the trial Court, he was required to depose in two other criminal
cases and was attending to an emergency surgery at the hospital.
According to him, during cross-examination, he inadvertently gave an
incorrect answer to a question and, owing to the pressure of his official
duties, failed to notice the error when his deposition was recorded. He
has further stated that the hospital medical records correctly reflect the
injuries noticed during the examination of the victim and that the
inconsistency in his oral evidence was wholly unintentional and has
tendered his unconditional apology to this Court.
6/20
https://www.mhc.tn.gov.in/judis
( Uploaded on: 19/08/2026 01:17:53 pm )

Crl.MP(MD) Nos.5823 & 6941 of 2025
10.In the light of this explanation offered by the Doctor, this
Court finds it appropriate to reiterate the importance of medical
evidence, particularly in offences under the POCSO Act and the vital
role played by medical professionals testifying in such cases as experts.
11.Medical evidence is of two kinds, viz., (1) documentary
evidence, in the form of medical certificates and medico-legal reports,
and (2) oral evidence, in the form of the expert's testimony before the
Court. Such evidence carries great corroborative value in criminal trials
as it shows that the injuries could have been caused in the manner
alleged, so that the prosecution case being consistent with matters
verifiable by medical science, the evidence of the witnesses need not be
disbelieved. It also has great value for the defence, which can make use
of the same to prove that the injuries could not possibly have been
caused in the manner alleged by the prosecution and by doing so, the
case of the prosecution can be discredited. Therefore, it is the key
evidence that could determine the guilt or innocence of the accused
person.
7/20
https://www.mhc.tn.gov.in/judis
( Uploaded on: 19/08/2026 01:17:53 pm )

Crl.MP(MD) Nos.5823 & 6941 of 2025
12.The medical practitioner / Doctor is an expert under Section
45 of the Indian Evidence Act. In Madan Gopal Kakkad v. Naval Dubey
and Another [(1992) SCC (3) 204], the Hon’ble Supreme Court has held
that the expert witness is expected to enlighten the Court on the
technical aspects of the case and that once the expert’s opinion is
accepted, it is not only the opinion of the medical officer but also of the
Court.
13.A Division Bench of this Court in RM.Arun Swaminathan v.
The Principal Secretary to the Government, Health and Family Welfare
Department [WP.(MD)No.78 of 2019, dated 28.09.2020] has observed
that the evidence given by Doctors based on medical documents, such
as, post-mortem reports, plays a vital role in deciding criminal cases as
they are the experts in the field. The relevant portions are extracted
hereunder for reference:
“15. ... ... ... The post-mortem certificate is very
important to decide the cause of death, the injuries found on the
body and whether any poisoning is there or not. It is very
important for criminal justice delivery system. The evidence of
doctors based on post-mortem certificates play a vital role
8/20
https://www.mhc.tn.gov.in/judis
( Uploaded on: 19/08/2026 01:17:53 pm )

Crl.MP(MD) Nos.5823 & 6941 of 2025
in   deciding   criminal   cases,   especially   murder   cases,
suicides  and  assaults.  The  Courts  usually  take  the
Doctors’ opinion / evidence as gospel truth as they are the
best  persons  or  experts  in  the  field  and  based  on  their
evidence only, the cases are decided ...”
14.Insofar as cases under the POCSO Act is concerned, the
medical evidence assumes even greater significance, since child victims
may struggle to report facts accurately or to withstand hostile cross-
examination, and the possibility of tutoring cannot be ruled out.
Considering the importance of medical evidence in such cases, Section 27
of the POCSO Act mandates medical examination of a child, in respect of
whom any offence is alleged to have been committed under the POCSO
Act, irrespective of whether an FIR or complaint has been registered. The
Doctor's opinion thus plays a crucial role in explaining the injuries, if
any, found on the child; whether such injuries are consistent with the
history furnished; whether they are suggestive of sexual assault; the
relevance  of  biological  and  forensic  samples  collected  during
examination and the interpretation of laboratory reports, including DNA
and serological findings. In fact, the testimony provided by the medical
9/20
https://www.mhc.tn.gov.in/judis
( Uploaded on: 19/08/2026 01:17:53 pm )

Crl.MP(MD) Nos.5823 & 6941 of 2025
experts play a significant role in determining the guilt or innocence of
the accused in such cases.
15.In State of Maharashtra v. Maroti [(2023) 4 SCC 298], the
Hon'ble Supreme Court has observed that medical examination of the
victim provides many vital clues in cases under the POCSO Act and that
medical evidence has much corroborative value in cases relating to
sexual offences. The relevant portions are extracted hereunder for
reference:-
“15.Prompt and proper reporting of the commission of
offence under the POCSO Act is of utmost importance and we
have no hesitation to state that its failure on coming to know
about the commission of any offence thereunder would defeat the
very purpose and object of the Act. We say so taking into
account   the   various   provisions   thereunder.    Medical
examination of the victim as also the accused would give
many  important  clues  in  a  case  that  falls  under  the
POCSO Act.... ... ... We refer to the aforesaid provisions only
to stress upon the fact that a prompt reporting of the commission
of an offence under POCSO Act would enable immediate
examination of the victim concerned and at the same time, if it
was committed by an unknown person, it would also enable the
10/20
https://www.mhc.tn.gov.in/judis
( Uploaded on: 19/08/2026 01:17:53 pm )

Crl.MP(MD) Nos.5823 & 6941 of 2025
investigating   agency   to   commence   investigation   without
wasting  time  and  ultimately  to  secure  the  arrest  and  medical
examination of the culprit. There can be no two views that in
relation  to  sexual  offences  medical  evidence  has  much
corroborative value.”
16.As provided in Modi's Textbook on Medical Jurisprudence and
Toxicology, the objective of medical evidence is to assist the Court in
discovering the truth. A medical expert is expected to state the truth, the
whole truth and nothing but the truth, irrespective of whether such
evidence ultimately supports the prosecution or the defence. The
evidence tendered by an expert must be relevant, reliable, clear, honest
and impartial. As far as possible, they should provide a definite opinion
with reasons and should avoid sitting on the fence.
17.An expert witness occupies a position of trust. The privilege
of assisting the Court carries with it a corresponding responsibility to
provide objective, accurate and consistent testimony before the Court.
Even an inadvertent lapse by the medical expert while testifying creates
avoidable confusion, prolong judicial proceedings and also affects the
11/20
https://www.mhc.tn.gov.in/judis
( Uploaded on: 19/08/2026 01:17:53 pm )

Crl.MP(MD) Nos.5823 & 6941 of 2025
rights of either the victim or the accused. Therefore, the medical
professionals who appear before Courts as expert witnesses must
exercise a high degree of care while giving evidence.
18.Equally important is the duty to carefully read and verify the
deposition before affixing their signature so as to ensure that it correctly
records the evidence actually tendered before the Court. In fact, as per
Modi's Textbook on Medical Jurisprudence and Toxicology, before attending
the Court to be subjected to examination-in-chief and cross-examination,
the medical witness must go through the medico legal reports etc,
prepared by him so that he may not commit mistakes during his cross
examination. Even during his examination in chief or cross examination,
the medical expert, as a witness of the Court, has a right to refresh his
memory under Section 159 of the Indian Evidence Act and wherever
required, the medical witness must refresh his memory by perusing the
relevant reports etc. prepared by him.
19.It is relevant to note that, under the provisions of the Indian
Medical Council Act, only the registered medical practitioners are
12/20
https://www.mhc.tn.gov.in/judis
( Uploaded on: 19/08/2026 01:17:53 pm )

Crl.MP(MD) Nos.5823 & 6941 of 2025
entitled to render medical opinion before a Court of law. Medical
professionals  must,  therefore,  recognise  that  their  professional
responsibilities do not end with the treatment of patients or the
performance of medical procedures. The duty to assist the Court is an
integral part of their professional obligations. Such assistance is not a
matter of discretion or favour, but a statutory and professional duty.
20.The criminal justice system functions on the basis that expert
witnesses discharge their responsibility with due care and diligence and
that their testimony faithfully reflects the findings recorded by them.
Had the concerned Doctor exercised the care expected of a medical
expert while giving evidence and verified the correctness  of the
deposition before affirming it, the discrepancy as noted supra would
never have arisen in this case. The manner in which the evidence was
provided and the explanation provided by the concerned Doctor reflects
a lack of diligence and carelessness in the discharge of an important
professional obligation.
13/20
https://www.mhc.tn.gov.in/judis
( Uploaded on: 19/08/2026 01:17:53 pm )

Crl.MP(MD) Nos.5823 & 6941 of 2025
21.This Court also notices that the Wound Certificate in the
present case falls short of what is required. It does not specify the extent
or nature of the injuries, the kind of examination conducted, or the
manner in which the conclusion was arrived at. Clarity emerged only
upon perusal of the Case Sheet and Accident Register, neither of which
had been marked as exhibits before the trial Court. As stated in Modi's
Textbook on Medical Jurisprudence and Toxicology, utmost care is expected
in the preparation of such documents, which must record both the facts
observed and the conclusions drawn therefrom.
22.It is relevant to note that the Ministry of Health and Family
Welfare, as a part of the Guidelines and Protocols for Medico-Legal Care
for Survivors of Sexual Violence, has issued a revised proforma for
Medico-Legal Examination of Survivors / Victims of Sexual Violence in
the year 2014 itself. The same was issued, in order to standardize the
medical examination protocols for the survivors / victims of Sexual
violence.  There is a checklist provided in this  proforma, according to
which, the type of examination carried out and the nature of injuries has
14/20
https://www.mhc.tn.gov.in/judis
( Uploaded on: 19/08/2026 01:17:53 pm )

Crl.MP(MD) Nos.5823 & 6941 of 2025
to be specified by the medical professional, before arriving at a medical
opinion.
23.As  notedsupra,  the  medical  evidence  serves  as  vital
corroborative evidence, which would help in establishing the guilt or
innocence  of  the  Accused  person.  Therefore,  the  medico-legal
documents, such as the Would Certificate and Accident Registers should
be clear, legible and understandable. The possibility of issuing such
documents in typed format can be considered, so that there is no
ambiguity regarding the medical opinion in such documents. Further,
this Court is of the opinion that the usage of the revisedproforma issued
by the Ministry  of Health and  Family Welfare should  be made
mandatory in cases involving sexual violence, including cases under the
POCSO Act and the same must form a part of the Accident Register and
should be marked as an exhibit before the trial Court. This would enable
the trial Courts to fully understand and consider the medical evidence
available in each case.
15/20
https://www.mhc.tn.gov.in/judis
( Uploaded on: 19/08/2026 01:17:53 pm )

Crl.MP(MD) Nos.5823 & 6941 of 2025
24.Accordingly, the Secretary to Government, Health  and
Family Welfare Department, Government of Tamil Nadu; and the
Director of Medical Education are directed to issue a comprehensive
circular / guidelines to all Government Medical Colleges, Government
Hospitals, District Headquarters Hospitals, Primary Health Centres and
other Government health care institutions in the State. The circular shall
comprehensively  deal  with  the  duties  and  responsibilities  of
Government medical professionals while acting as expert witnesses
before Courts and shall include appropriate instructions regarding:
(i)the  ethical  standards  expected  of  every  expert
witness, including the principles stated in  Modi's  Textbook  on
Medical  Jurisprudence  and  Toxicology that medical evidence is
intended to assist the Court in discovering the truth and that
every  medical  witness  is  expected  to  depose  objectively,
honestly and impartially;
(ii)the necessity of ensuring that Accident Registers,
Wound  Certificates,  Medico-Legal  Reports  and  all  other
medico-legal records accurately record the clinical findings and
professional opinion formed at the time of examination;
(iii)the importance of making entries in Accident
Registers, Wound Certificates and all medico-legal records in a
16/20
https://www.mhc.tn.gov.in/judis
( Uploaded on: 19/08/2026 01:17:53 pm )

Crl.MP(MD) Nos.5823 & 6941 of 2025
clear, legible and unambiguous manner, avoiding illegible
handwriting,  unexplained  abbreviations  and  ambiguous
expressions. Wherever the existing infrastructure permits, such
records may be generated in a typed or computer-generated
format so that they are readily comprehensible to investigating
agencies, prosecutors, defence counsel and Courts alike;
(iv)the necessity of preparing the revisedproforma for
Medico-Legal Examination of Survivors/ Victims of Sexual
Violence issued by the Ministry of Health and Family Welfare,
in cases involving sexual violence, including cases under the
POCSO Act;
(v)the necessity of familiarising themselves with the
relevant medical records before entering the witness box and of
deposing strictly in accordance with those records and their
professional opinion;
(vi)the need to carefully understand every question
put during examination and cross-examination and, wherever
any ambiguity exists, to seek appropriate clarification before
answering and
(vii)the importance of carefully reading and verifying
the deposition  before  signing  the same  and  immediately
bringing to the notice of the Court any omission or inadvertent
error noticed therein;
17/20
https://www.mhc.tn.gov.in/judis
( Uploaded on: 19/08/2026 01:17:53 pm )

Crl.MP(MD) Nos.5823 & 6941 of 2025
25.The directions issued herein are intended to strengthen the
quality of medical evidence provided before Courts, reinforce the
confidence reposed by Courts in expert witnesses and minimise the
possibility of recurrence of situations such as the one encountered in the
present case. The efficacy of the justice delivery system depends, to a
considerable extent, upon the credibility of expert evidence. It is,
therefore, imperative that every medical professional entrusted with this
responsibility discharges it with the highest standards of competence,
objectivity and professional integrity.
With  the  above  directions,  these  criminal  miscellaneous
petitions stand dismissed.
Index   : Yes / No19.08.2026
NCC    : Yes / No
gk
Note:
Mark a copy of this order to
1. The Secretary to Government,
Health and Family Welfare Department,
State of Tamil Nadu,
Secretariat, Chennai.
18/20
https://www.mhc.tn.gov.in/judis
( Uploaded on: 19/08/2026 01:17:53 pm )

Crl.MP(MD) Nos.5823 & 6941 of 2025
2. The Director of Medical Education,
Directorate of Medical Education,
Chennai.
To
1.The Judge,
Fast Track Mahila Court,
Ramanathapuram.
2.The Inspector of Police,
Rameswaram Town Police Station,
Ramanathapuram District.
3.The Additional Public Prosecutor,
Madurai Bench of Madras High Court,
Madurai.
19/20
https://www.mhc.tn.gov.in/judis
( Uploaded on: 19/08/2026 01:17:53 pm )

Crl.MP(MD) Nos.5823 & 6941 of 2025
B.PUGALENDHI, J.,
gk
Crl.MP(MD) Nos.5823 & 6941 of 2025
in
Crl.A(MD) No.778 of 2023
19.08.2026
20/20
https://www.mhc.tn.gov.in/judis
( Uploaded on: 19/08/2026 01:17:53 pm )


# Glossary

- **Medical evidence** — of two kinds, viz
- **Doctor** — an expert under Section
- **The relevant portions** — extracted
- **POCSO Act** — concerned, the
- **Equally important** — the duty to carefully read and verify the
- **Such assistance** — not a
- **There** — a checklist provided in this  proforma, according to
- **Court** — of the opinion that the usage of the revisedproforma issued
- **Director of Medical Education** — directed to issue a comprehensive
- **Toxicology that medical evidence** — intended to assist the Court in discovering the truth and that
- **The directions issued herein** — intended to strengthen the
